<?php
// admin/api.php (Handles GET, POST, PUT, DELETE) — JSON-safe
/**
 * This version handles full CRUD operations and always returns JSON.
 * It also includes custom ID generation for new records.
 */

// Force JSON output and disable notices
@ini_set('display_errors', 0);
@ini_set('display_startup_errors', 0);
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
header('Content-Type: application/json; charset=utf-8');

// Utility: JSON error and exit
function json_error($code, $message) {
  http_response_code($code);
  echo json_encode(['status'=>'error','message'=>$message]);
  exit;
}

// Load DB ($pdo)
try {
  require_once __DIR__ . '/db.php';
  if (!isset($pdo)) json_error(500, 'DB not initialized');
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  @$pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
} catch (Throwable $e) {
  json_error(500, 'DB load error: '.$e->getMessage());
}

// ---- entity metadata mapped to your schema ----
function entity_meta($name) {
  $pk = [
    'adoption_terms' => 'term_id',
    'breeds'         => 'breed_id',
    'vaccines'       => 'vaccine_id',
    'personalities'  => 'personality_id',
    'pet_species'    => 'species_id',
    'rehome_reasons' => 'reason_id',
    'housing_types'  => 'housing_id',
    'comments'       => 'id',
    'comment_likes'  => 'id',
    'fhome'          => 'id',
    'fpet'           => 'id',
    'post_matches'   => 'id',
    'users'          => 'id',
  ];

  $like = [
    'adoption_terms' => ['name_th','name_en','description'],
    'breeds'         => ['name_th','name_en'],
    'vaccines'       => ['name_th','name_en','description','dose_recommend'],
    'personalities'  => ['name_th','name_en','description'],
    'pet_species'    => ['code','name_th','name_en'],
    'rehome_reasons' => ['name_th','name_en','description'],
    'housing_types'  => ['name_th','name_en','description'],
    'users'          => ['username','email'],
    'fhome'          => ['title','type','breed','sex','color','vaccine','reason','user'],
    'fpet'           => ['title','type','breed','sex','color','vaccine','environment','user'],
  ];

  if (!isset($pk[$name])) return null;
  return ['pk'=>$pk[$name], 'like'=>($like[$name] ?? [])];
}

// --- Main Request Handling ---
try {
  $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
  // Handle method override for servers that don't support PUT/DELETE
  if ($method === 'POST' && isset($_REQUEST['_method'])) {
    $method = strtoupper($_REQUEST['_method']);
  }

  $entity = $_REQUEST['entity'] ?? '';
  $meta = entity_meta($entity);
  if (!$meta) json_error(400, 'Unknown entity');

  $pk = $meta['pk'];
  $orderBy = null; // Initialize ORDER BY variable

  switch ($method) {
    case 'GET':
      // Handle GET (list + search)
      $likeCols = $meta['like'];
      $page = max(1, (int)($_GET['page'] ?? 1));
      $per  = min(200, max(1, (int)($_GET['per'] ?? 20)));
      $off  = ($page - 1) * $per;
      $q = trim((string)($_GET['q'] ?? ''));
      $params = [];
      $where = [];

      $is_fetching_single_id = isset($_GET['id']) && $_GET['id'] !== '';

      // *** โค้ดที่แก้ไข: แยกเงื่อนไขการดึงข้อมูลเดี่ยว (Single ID) ***
      if ($is_fetching_single_id) {
          // ถ้ามี ID เราจะดึงข้อมูลแค่รายการเดียวด้วย Primary Key
          $where = ["`{$pk}` = :pk_val"];
          $params[':pk_val'] = $_GET['id'];
          // ล้างตัวกรองอื่นๆ ที่ไม่จำเป็นเมื่อดึงข้อมูลเดี่ยว
          $q = '';
          $activeFilterValue = null;
      } else {
          // ถ้าไม่มี ID ให้ใช้ตัวกรองสำหรับการแสดงรายการ (List)
          if ($q !== '' && $likeCols) {
            $w = [];
            foreach ($likeCols as $i => $col) {
              $key = ":q{$i}";
              $w[] = "`{$col}` LIKE {$key}";
              $params[$key] = "%{$q}%";
            }
            if ($w) $where[] = '(' . implode(' OR ', $w) . ')';
          }
      
          // NEW: Add userType filter condition
          if ($entity === 'users' && !empty($_GET['userType'])) {
            $userType = $_GET['userType'];
            if ($userType === 'fhome' || $userType === 'fpet') {
              $where[] = "`userType` = :userType";
              $params[':userType'] = $userType;
            }
          }
      }
      
      // LOGIC FOR SPECIES FILTERING & CUSTOM ORDERING - ทำงานเฉพาะเมื่อไม่ได้ดึงข้อมูลเดี่ยว
      if (!$is_fetching_single_id && (($entity === 'breeds' || $entity === 'personalities' || $entity === 'vaccines') && isset($_GET['species_id']) && $_GET['species_id'] !== '' && $_GET['species_id'] !== '0')) {
        $speciesId = (int)$_GET['species_id'];
        
        if ($speciesId > 0) {
          $where[] = "(`species_id` = :species_id OR `species_id` IS NULL)";
          $params[':species_id'] = $speciesId;
          
          $orderBy = " ORDER BY CASE WHEN `species_id` = {$speciesId} THEN 0 ELSE 1 END, `species_id` ASC, `{$pk}` ASC";
        }
      }

      try {
        $cols = $pdo->query("SHOW COLUMNS FROM `{$entity}`")->fetchAll(PDO::FETCH_COLUMN, 0);
        $hasIsActive = in_array('is_active', $cols, true);
      } catch (Throwable $e) { $hasIsActive = false; }

      // *** แก้ไข Logic การกรอง is_active ให้รับค่า 0 หรือ 1 ที่ส่งมาจาก JavaScript ***
      $activeFilterValue = $_GET['active_filter'] ?? null;
      if (isset($_GET['is_active'])) { 
          $activeFilterValue = $_GET['is_active'];
      }
      
      // ใช้ active_filter ก็ต่อเมื่อไม่มีการดึงข้อมูลเดี่ยวด้วย ID
      if (!$is_fetching_single_id && $hasIsActive && $activeFilterValue !== null && $activeFilterValue !== '') {
        $where[] = "`is_active` = :active_filter";
        $params[':active_filter'] = (int)$activeFilterValue; 
      }
      // *** สิ้นสุดการแก้ไข Logic is_active ***
      
      $whereSql = $where ? (' WHERE ' . implode(' AND ', $where)) : '';
      $defaultOrderBy = " ORDER BY `{$pk}` ASC";
      $finalOrderBy = $orderBy ?? $defaultOrderBy; 
      
      // *** โค้ดที่แก้ไข: ไม่ต้องใช้ LIMIT/OFFSET สำหรับการดึงข้อมูลเดี่ยว ***
      $limitOffsetSql = $is_fetching_single_id ? '' : " LIMIT :lim OFFSET :off";

      $stmtCnt = $pdo->prepare("SELECT COUNT(*) AS c FROM `{$entity}` {$whereSql}");
      // Bind parameters for COUNT query
      foreach ($params as $k=>$v) $stmtCnt->bindValue($k,$v);
      $stmtCnt->execute();
      $total = (int)($stmtCnt->fetch(PDO::FETCH_ASSOC)['c'] ?? 0);

      // Prepare SELECT query with custom ORDER BY
      $stmt = $pdo->prepare("SELECT * FROM `{$entity}` {$whereSql} {$finalOrderBy} {$limitOffsetSql}");
      // Bind parameters for SELECT query
      foreach ($params as $k=>$v) $stmt->bindValue($k,$v);
      // Bind limit/offset only if not fetching single ID
      if (!$is_fetching_single_id) {
          $stmt->bindValue(':lim', $per, PDO::PARAM_INT);
          $stmt->bindValue(':off', $off, PDO::PARAM_INT);
      }
      $stmt->execute();
      $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

      if (isset($_GET['export']) && $_GET['export'] === 'csv') {
        header_remove('Content-Type');
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="'.$entity.'_export.csv"');
        $out = fopen('php://output', 'w');
        if (!empty($rows)) { fputcsv($out, array_keys($rows[0])); foreach ($rows as $r) fputcsv($out, $r); }
        fclose($out);
        exit;
      }

      echo json_encode(['status'=>'success', 'entity'=>$entity, 'page'=>$page, 'per'=>$per, 'total'=>$total, 'data'=>$rows]);
      break;

    case 'POST':
      // Handle POST (Create)
      $data = json_decode(file_get_contents('php://input'), true);
      if (!$data) json_error(400, 'Invalid JSON payload');

      $stmt = $pdo->prepare("SELECT `{$pk}` FROM `{$entity}` ORDER BY `{$pk}` ASC");
      $stmt->execute();
      $ids = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);
      $newId = 1;
      foreach ($ids as $id) {
        $currentId = (int)$id;
        if ($newId < $currentId) { break; }
        $newId = $currentId + 1;
      }
      $data[$pk] = $newId;

      $cols = array_keys($data);
      $placeholders = array_map(fn($c) => ":{$c}", $cols);
      $sql = "INSERT INTO `{$entity}` (`" . implode('`, `', $cols) . "`) VALUES (" . implode(', ', $placeholders) . ")";
      $stmt = $pdo->prepare($sql);
      foreach ($data as $k => $v) $stmt->bindValue(":{$k}", $v);
      $stmt->execute();
      
      echo json_encode(['status'=>'success', 'message'=>'Data created successfully', 'id' => $newId]);
      break;

    case 'PUT':
      // Handle PUT (Update)
      $id = $_GET['id'] ?? null;
      if (!$id) json_error(400, 'Missing ID for update');
      $data = json_decode(file_get_contents('php://input'), true);
      if (!$data) json_error(400, 'Invalid JSON payload');

      $updates = [];
      foreach (array_keys($data) as $col) $updates[] = "`{$col}` = :{$col}";
      $sql = "UPDATE `{$entity}` SET " . implode(', ', $updates) . " WHERE `{$pk}` = :pk_id";
      
      $stmt = $pdo->prepare($sql);
      foreach ($data as $k => $v) $stmt->bindValue(":{$k}", $v);
      $stmt->bindValue(':pk_id', $id);
      $stmt->execute();
      
      echo json_encode(['status'=>'success', 'message'=>'Data updated successfully']);
      break;

    case 'DELETE':
      // Handle DELETE
      $id = $_GET['id'] ?? null;
      if (!$id) json_error(400, 'Missing ID for delete');

      $sql = "DELETE FROM `{$entity}` WHERE `{$pk}` = :pk_id";
      $stmt = $pdo->prepare($sql);
      $stmt->bindValue(':pk_id', $id);
      $stmt->execute();
      
      if ($stmt->rowCount() > 0) {
        echo json_encode(['status'=>'success', 'message'=>'Data deleted successfully']);
      } else {
        json_error(404, 'Data not found or already deleted');
      }
      break;

    default:
      json_error(405, 'Unsupported method');
      break;
  }
} catch (Throwable $e) {
  json_error(500, 'Server error: '.$e->getMessage());
}
?>