<?php
require __DIR__.'/db.php';
if (is_logged_in()) { header('Location: index.php'); exit; }
$err='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  if (csrf_fail($_POST['csrf']??'')) $err='CSRF invalid';
  else {
    $conf=require __DIR__.'/config.php';
    if (($_POST['username']??'')===($conf['auth']['username']??'') && ($_POST['password']??'')===($conf['auth']['password']??'')){
      $_SESSION['uid']=$_POST['username']; header('Location: index.php'); exit;
    } else $err='ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง';
  }
}
?><!doctype html><html lang="th"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>Login</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"/><style>body{background:#eef2ff}.card{border-radius:16px}</style></head><body class="d-flex align-items-center" style="min-height:100vh"><div class="container"><div class="row justify-content-center"><div class="col-md-5"><div class="card shadow-sm"><div class="card-body p-4"><h4 class="mb-3 text-primary fw-bold">FHomePet • Admin</h4><?php if($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?= htmlspecialchars(csrf_token()) ?>"/><div class="mb-3"><label class="form-label">ชื่อผู้ใช้</label><input name="username" class="form-control" required/></div><div class="mb-3"><label class="form-label">รหัสผ่าน</label><input type="password" name="password" class="form-control" required/></div><button class="btn btn-primary w-100">เข้าสู่ระบบ</button></form></div></div></div></div></div></body></html>