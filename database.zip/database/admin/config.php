<?php
// Copy this file to config.php and edit values.
return [
  'db' => [
    'host' => '127.0.0.1',
    'port' => 3306,
    'name' => 'fhomepet',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4',
  ],
  // Simple admin login (session-based)
  'auth' => [
    'username' => 'admin',
    'password' => 'admin123', // change me
  ],
  'app' => [
    'base_path' => '', // e.g. '/admin' if not in web root
  ]
];
