<?php
// api_get_post_details.php
// API สำหรับดึงข้อมูลโพสต์ (FH/FP) ตาม ID เพื่อแสดงใน Modal (ฉบับแก้ไข Path รูปภาพ)

require_once __DIR__ . '/db.php';

// ตั้งค่า Header ให้เป็น JSON
header('Content-Type: application/json');

// รับค่า
$type = $_GET['type'] ?? '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (($type !== 'fh' && $type !== 'fp') || $id <= 0) {
    echo json_encode(['error' => 'Invalid parameters']);
    exit;
}

// เลือกตารางตาม type
$table_name = ($type === 'fh') ? 'fhome' : 'fpet';

// ดึงข้อมูล
$stmt = $db->prepare("SELECT * FROM $table_name WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();
$stmt->close();

if ($post) {
    // ถ้าเป็นโพสต์หาบ้าน (fh) ให้แปลง json string ของรูปภาพเป็น array
    if ($type === 'fh' && !empty($post['image'])) {
        $decoded_images = json_decode($post['image'], true);
        
        // ------------------ จุดที่แก้ไข (แก้ Base URL) ------------------
        if (is_array($decoded_images)) {
            $post['image_urls'] = array_map(function($path) {
                // *** แก้ไข: กำหนด Base URL ให้ชี้ไปที่โฟลเดอร์ uploads/ โดยตรง ***
                $base_url = '/db_fhomepet/post/uploads/'; 
                
                // ทำความสะอาด path ที่อาจมี backslash (\) ปนมา และลบ 'uploads/' ที่อาจมีอยู่แล้ว
                $clean_path = str_replace('\\', '/', $path);
                // ป้องกันการใส่ 'uploads/' ซ้ำซ้อน หากมีการบันทึกไว้ใน DB แล้ว
                $clean_path = str_replace('uploads/', '', $clean_path); 

                // รวม Base URL ที่ถูกต้องกับชื่อไฟล์
                return $base_url . $clean_path;
            }, $decoded_images);
        } else {
             $post['image_urls'] = [];
        }
    }
    echo json_encode($post);
} else {
    echo json_encode(['error' => 'Post not found']);
}
?>