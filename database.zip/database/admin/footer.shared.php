
</div></div>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', ()=>document.body.classList.toggle('show-sidebar'));
(function(){
  const url = new URL(window.location.href);
  const page = url.pathname.split('/').pop();
  const type = url.searchParams.get('type');
  const entity = url.searchParams.get('entity');
  document.querySelectorAll('.sidebar .nav-link').forEach(a=>{
    const href=a.getAttribute('href');
    if(page==='index.php' && href==='index.php') a.classList.add('active');
    if(page==='posts.php' && href.includes('posts.php') && type && href.includes('type='+type)) a.classList.add('active');
    if(page==='entity.php' && entity && href.includes('entity='+entity)) a.classList.add('active');
  });
})();
</script>
