<?php
  $title='Admin • โพสต์';
  $hide_header_title = true;
  include __DIR__.'/layout/header.php';
  require_once __DIR__.'/db.php';
  
  $type = ($_GET['type'] ?? 'fh') === 'fp' ? 'fp' : 'fh';
  
  
  // *** 1. Logic การลบโพสต์ (Action Delete) ***
  $post_id_to_delete = isset($_GET['delete_id']) ? intval($_GET['delete_id']) : 0;
  $token = $_GET['_token'] ?? '';
  $table = $type==='fh' ? 'fhome' : 'fpet';

  if ($post_id_to_delete > 0 && $token === 'YOUR_CSRF_TOKEN_HERE') { // **NOTE: ต้องเปลี่ยน YOUR_CSRF_TOKEN_HERE ด้วยโค้ดจริง**
      try {
          $stmt = $pdo->prepare("DELETE FROM {$table} WHERE id = ?");
          $stmt->execute([$post_id_to_delete]);
          
          // Redirect กลับไปหน้ารายการพร้อมข้อความแจ้งเตือน
          header("Location: posts.php?type={$type}&status=deleted");
          exit;
      } catch (PDOException $e) {
          // หากล้มเหลว (เช่น มีข้อจำกัด Foreign Key)
          header("Location: posts.php?type={$type}&status=delete_failed");
          exit;
      }
  }
  // *** สิ้นสุด Logic การลบโพสต์ ***
  
  include __DIR__.'/nav.inc.php';

  $fields = $type==='fh'
    ? 'id, title, type, breed, user, post_date'
    : 'id, title, type, breed, user, post_date';

  // *** ตัวแปรและตรรกะสำหรับการกรอง ***
  $start_date = $_GET['start_date'] ?? '';
  $end_date = $_GET['end_date'] ?? '';
  $search_q = $_GET['q'] ?? '';
  $filter_type = $_GET['filter_type'] ?? ''; 
  $filter_breed = $_GET['filter_breed'] ?? '';

  $where = [];
  $params = [];

  // --- 1. ดึงข้อมูลชนิดสัตว์ทั้งหมด (เพื่อใช้ใน Dropdown) ---
  $stmt_species = $pdo->query("SELECT species_id, name_th FROM pet_species");
  $species_map = $stmt_species->fetchAll(PDO::FETCH_KEY_PAIR);
  $species_options = array_values($species_map);
  
  // --- 2. ดึงข้อมูลสายพันธุ์ที่เกี่ยวข้อง (Breeds) ---
  $breed_options = [];
  if (!empty($filter_type)) {
      $species_id_to_filter = array_search($filter_type, $species_map);
      
      if ($species_id_to_filter !== false) {
          $stmt_breeds = $pdo->prepare("SELECT name_th FROM breeds WHERE species_id = :species_id AND is_active = 1 ORDER BY name_th");
          $stmt_breeds->execute([':species_id' => $species_id_to_filter]);
          $breed_options = $stmt_breeds->fetchAll(PDO::FETCH_COLUMN);
      }
  }

  // --- 3. สร้าง WHERE Clause สำหรับการดึงโพสต์ ---
  if (!empty($start_date)) {
      $where[] = "post_date >= :start_date";
      $params[':start_date'] = $start_date . ' 00:00:00'; 
  }
  if (!empty($end_date)) {
      $where[] = "post_date <= :end_date";
      $params[':end_date'] = $end_date . ' 23:59:59'; 
  }

  if (!empty($filter_type)) {
      $where[] = "type = :filter_type";
      $params[':filter_type'] = $filter_type;
  }
  
  if (!empty($filter_breed)) {
      $where[] = "breed = :filter_breed";
      $params[':filter_breed'] = $filter_breed;
  }

  if (!empty($search_q)) {
      $where[] = "title LIKE :search_q";
      $params[':search_q'] = '%' . $search_q . '%';
  }
  
  $where_sql = count($where) > 0 ? ' WHERE ' . implode(' AND ', $where) : '';
  
  $sql = "SELECT {$fields} FROM {$table} {$where_sql} ORDER BY post_date DESC LIMIT 100";
  
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // ตรวจสอบสถานะแจ้งเตือน
  $alert_msg = '';
  if (isset($_GET['status'])) {
      if ($_GET['status'] === 'deleted') {
          $alert_msg = '<div class="alert alert-success">✅ ลบโพสต์สำเร็จแล้ว</div>';
      } elseif ($_GET['status'] === 'delete_failed') {
          $alert_msg = '<div class="alert alert-danger">❌ การลบโพสต์ล้มเหลว (อาจมีข้อมูลอ้างอิงอยู่)</div>';
      }
  }
?>
<div class="card table-card p-3 shadow-sm">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="mb-0">รายการโพสต์: <?= htmlspecialchars($pageTitle) ?></h3>
    <div class="text-muted small">ตาราง: <?= htmlspecialchars($table) ?></div>
  </div>
  
  <?= $alert_msg ?>

  <form method="get" class="d-flex flex-wrap align-items-end gap-3 p-3 border rounded mb-4 bg-light" id="filterForm">
    <input type="hidden" name="type" value="<?= htmlspecialchars($type) ?>">

    <div>
      <label class="form-label small text-muted mb-0">ค้นหาชื่อโพสต์</label>
      <input type="text" name="q" value="<?= htmlspecialchars($search_q) ?>" class="form-control form-control-sm" placeholder="ค้นหา..." style="width: 150px;">
    </div>
    
    <div>
      <label class="form-label small text-muted mb-0">ชนิดสัตว์</label>
      <select name="filter_type" id="filter_type_select" class="form-select form-select-sm" onchange="this.form.submit()" style="width: 120px;">
        <option value="">— ทั้งหมด —</option>
        <?php foreach ($species_options as $sp): ?>
          <option value="<?= htmlspecialchars($sp) ?>" <?= ($filter_type == $sp) ? 'selected' : '' ?>><?= htmlspecialchars($sp) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-label small text-muted mb-0">สายพันธุ์</label>
      <select name="filter_breed" id="filter_breed_select" class="form-select form-select-sm" style="width: 120px;">
        <option value="">— ทั้งหมด —</option>
        <?php foreach ($breed_options as $br): ?>
          <option value="<?= htmlspecialchars($br) ?>" <?= ($filter_breed == $br) ? 'selected' : '' ?>><?= htmlspecialchars($br) ?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <div>
      <label class="form-label small text-muted mb-0">วันที่โพสต์ (เริ่มต้น | ป/ด/ว)</label>
      <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" class="form-control form-control-sm" style="width: 150px;">
    </div>
    
    <div>
      <label class="form-label small text-muted mb-0">ถึงวันที่ (สิ้นสุด | ป/ด/ว)</label>
      <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>" class="form-control form-control-sm" style="width: 150px;">
    </div>
    
    
    <div class="d-flex gap-2">
      <button class="btn btn-sm btn-dark" type="submit" style="white-space: nowrap;">
          <i class="bi bi-funnel"></i> กรอง
      </button>
      <a class="btn btn-sm btn-outline-secondary" href="posts.php?type=<?= htmlspecialchars($type) ?>" style="white-space: nowrap;">
          <i class="bi bi-x"></i> ล้างค่า
      </a>
    </div>

  </form>
  <div class="table-responsive">
    <table class="table table-striped table-hover align-middle">
      <thead style="background-color: #E9ECEF; color: black !important; border-bottom: 2px solid #dee2e6;">
        <tr>
          <th style="width: 25%;">ชื่อโพสต์</th> 
          <th style="width: 10%;">ชนิด</th>
          <th style="width: 15%;">สายพันธุ์</th>
          <th style="width: 15%;">ผู้ใช้</th>
          <th style="width: 15%; white-space: nowrap;">วันที่โพสต์</th>
          <th style="width: 10%;">จัดการ</th> 
        </tr>
      </thead>
      <tbody>
        <?php foreach($rows as $r): ?>
          <?php 
            $post_date_mmddyyyy = date('m/d/Y', strtotime($r['post_date']));
          ?>
          <tr>
            <td style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
              <?= htmlspecialchars($r['title']) ?>
              
            </td>
            <td><?= htmlspecialchars($r['type']) ?></td>
            <td><?= htmlspecialchars($r['breed']) ?></td>
            <td><?= htmlspecialchars($r['user']) ?></td>
            <td style="white-space: nowrap;"><?= $post_date_mmddyyyy ?></td> 
            <td style="white-space: nowrap;">
                <div class="btn-group d-flex flex-nowrap" role="group" aria-label="Post Actions">
                    <button class="btn btn-sm text-white" 
                            style="background-color: #00bcd4; font-size: 0.85rem;" 
                            onclick="showPostDetails('<?= htmlspecialchars($type) ?>', <?= (int)$r['id'] ?>)"
                            title="ดูรายละเอียด/แก้ไข">
                        <i class="bi bi-eye"></i> รายละเอียด
                    </button>
                    <a href="posts.php?type=<?= htmlspecialchars($type) ?>&delete_id=<?= (int)$r['id'] ?>&_token=YOUR_CSRF_TOKEN_HERE" 
                       onclick="return confirm('คุณต้องการลบโพสต์ ID: <?= (int)$r['id'] ?>? \nการกระทำนี้ไม่สามารถย้อนกลับได้')"
                       class="btn btn-sm btn-danger"
                       title="ลบโพสต์">
                        <i class="bi bi-trash"></i> ลบ
                    </a>
                </div>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if(empty($rows)): ?>
          <tr><td colspan="6" class="text-center text-muted py-4">ไม่พบข้อมูลโพสต์</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="modal fade" id="postDetailModal" tabindex="-1" aria-labelledby="postDetailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="postDetailModalLabel">รายละเอียดโพสต์</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="modal-content-area">
          <p class="text-center">กำลังโหลดข้อมูล...</p>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button>
      </div>
    </div>
  </div>
</div>


<?php include __DIR__.'/layout/footer.php'; ?>

</div></div>
<script>
// *** JavaScript Function: showPostDetails (ปรับปรุงการแสดงรูปภาพ/วิดีโอ) ***
const postDetailModal = new bootstrap.Modal(document.getElementById('postDetailModal'));

// *** แก้ไข: ปรับ Base URL ให้ชี้ไปที่ /db_fhomepet/post/uploads/ (เพิ่ม uploads/ เพื่อแก้ 404) ***
const IMAGE_BASE_URL = '/db_fhomepet/post/uploads/'; 

async function showPostDetails(type, id) {
  const modalContent = document.getElementById('modal-content-area');
  
  modalContent.innerHTML = '<p class="text-center">กำลังโหลดข้อมูล...</p>';
  postDetailModal.show();

  try {
    // NOTE: ต้องมีไฟล์ api_get_post_details.php เพื่อดึงข้อมูลโพสต์
    const response = await fetch(`api_get_post_details.php?type=${type}&id=${id}`);
    const data = await response.json();

    if (data.error) {
      modalContent.innerHTML = `<p class="text-center text-danger">เกิดข้อผิดพลาด: ${data.error}</p>`;
      return;
    }

    // 3. สร้าง HTML เพื่อแสดงผล
    let html = `<h4>${data.title}</h4>`;
    html += `<p><strong>โดย:</strong> ${data.user}</p><hr>`;
    
    if (type === 'fh') { // Finding Home
      html += `
        <div class="row">
            <div class="col-md-6">
                <p><strong>ประเภท:</strong> ${data.type}</p>
                <p><strong>สายพันธุ์:</strong> ${data.breed}</p>
                <p><strong>เพศ:</strong> ${data.sex}</p>
                <p><strong>อายุ:</strong> ${data.age}</p>
                <p><strong>สี:</strong> ${data.color}</p>
                <p><strong>ทำหมัน:</strong> ${data.steriliz}</p>
            </div>
            <div class="col-md-6">
                <p><strong>วัคซีน:</strong> ${data.vaccine}</p>
                <p><strong>นิสัย:</strong> ${data.personality}</p>
                <p><strong>เหตุผลหาบ้าน:</strong> ${data.reason}</p>
                <p><strong>เงื่อนไข:</strong> ${data.adoptionTerms}</p>
            </div>
        </div>
      `;
      // *** Logic แสดงรูปภาพ/วิดีโอ: ใช้ IMAGE_BASE_URL ที่แก้ไขแล้ว ***
      if (data.image_urls && data.image_urls.length > 0) {
        html += '<hr><p><strong>รูปภาพและวิดีโอ:</strong></p><div class="d-flex flex-wrap gap-2">';
        data.image_urls.forEach(url => {
          // ต่อ Base URL เพื่อให้รูปภาพแสดงผลได้
          const imageUrl = url.startsWith('/') ? url : (IMAGE_BASE_URL + url); 
          
          if (imageUrl.toLowerCase().endsWith('.mp4') || imageUrl.toLowerCase().endsWith('.mov')) {
               html += `<video controls class="img-fluid rounded mb-2" style="max-height: 150px; width: auto; background: #000;">
                           <source src="${imageUrl}" type="video/mp4">
                           Your browser does not support the video tag.
                       </video>`;
          } else {
               html += `<img src="${imageUrl}" class="img-fluid rounded mb-2" style="max-height: 150px; width: auto;">`;
          }
        });
        html += '</div>';
      } else {
        html += '<p class="text-muted small">ไม่พบรูปภาพประกอบ</p>';
      }
    } else { // Finding Pet
       html += `
        <div class="row">
            <div class="col-md-6">
                <p><strong>ประเภท:</strong> ${data.type}</p>
                <p><strong>สายพันธุ์:</strong> ${data.breed}</p>
                <p><strong>เพศ:</strong> ${data.sex}</p>
                <p><strong>ช่วงอายุ:</strong> ${data.min_age} - ${data.max_age}</p>
            </div>
            <div class="col-md-6">
                <p><strong>สีที่มองหา:</strong> ${data.color}</p>
                <p><strong>ทำหมัน:</strong> ${data.steriliz}</p>
                <p><strong>วัคซีนที่ต้องการ:</strong> ${data.vaccine}</p>
                <p><strong>สภาพแวดล้อม:</strong> ${data.environment}</p>
            </div>
        </div>
      `;
    }

    document.getElementById('postDetailModalLabel').textContent = `รายละเอียดโพสต์ ID: ${id}`;
    modalContent.innerHTML = html;

  } catch (error) {
    modalContent.innerHTML = `<p class="text-center text-danger">ไม่สามารถโหลดข้อมูลได้ (ตรวจสอบ api_get_post_details.php)</p>`;
    console.error('Fetch error:', error);
  }
}
// โค้ดสำหรับ Sidebar (เหมือนเดิม)
document.getElementById('sidebarToggle')?.addEventListener('click', ()=>document.body.classList.toggle('show-sidebar'));
// Active menu highlight by page + params
(function(){
  const url = new URL(window.location.href);
  const page = url.pathname.split('/').pop();
  const type = url.searchParams.get('type');
  const entity = url.searchParams.get('entity');
  document.querySelectorAll('.sidebar .nav-link').forEach(a=>{
    const href=a.getAttribute('href');
    if(page==='index.php' && href==='index.php') a.classList.add('active');
    if(page==='posts.php' && href.includes('posts.php') && href.includes('type='+type)) a.classList.add('active');
    if(page==='entity.php' && entity && href.includes('entity='+entity)) a.classList.add('active');
  });
})();
</script>