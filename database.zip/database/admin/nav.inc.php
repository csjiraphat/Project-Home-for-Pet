<?php
// nav.inc.php — include this on every admin page after header.php

function is_active_nav($nav_href) {
    $current_file = basename($_SERVER['PHP_SELF']);
    $nav_file = basename(parse_url($nav_href, PHP_URL_PATH));
    
    if ($current_file !== $nav_file) {
        return false;
    }

    $current_query = $_SERVER['QUERY_STRING'] ?? '';
    $nav_query = parse_url($nav_href, PHP_URL_QUERY) ?? '';
    
    if (empty($nav_query) || empty($current_query)) {
        return $current_file === $nav_file && empty($nav_query) === empty($current_query);
    }
    
    parse_str($current_query, $current_params);
    parse_str($nav_query, $nav_params);

    foreach ($nav_params as $key => $value) {
        if (!isset($current_params[$key]) || $current_params[$key] !== $value) {
            return false;
        }
    }

    return true;
}

$modules = [
  ['title' => 'Admin', 'href' => 'index.php', 'icon' => 'bi-speedometer2'],
  ['title' => 'ผู้ใช้', 'href' => 'entity.php?entity=users', 'icon' => 'bi-people'],
  ['title' => 'โพสต์ หาบ้าน', 'href' => 'posts.php?type=fh', 'icon' => 'bi-house-heart'],
  ['title' => 'โพสต์ รับเลี้ยง', 'href' => 'posts.php?type=fp', 'icon' => 'bi-search'],
  ['title' => 'ความรู้สัตว์เลี้ยง', 'href' => 'article.php', 'icon' => 'bi-journal-text'],
  ['title' => 'โพสต์ที่ถูกรายงาน', 'href' => 'reports.php', 'icon' => 'bi-flag'],
  ['title' => 'ชนิดสัตว์', 'href' => 'entity.php?entity=pet_species', 'icon' => 'bi-collection'],
  ['title' => 'สายพันธุ์', 'href' => 'entity.php?entity=breeds', 'icon' => 'bi-diagram-3'],
  ['title' => 'วัคซีน', 'href' => 'entity.php?entity=vaccines', 'icon' => 'bi-capsule'],
  ['title' => 'ประเภทที่อยู่อาศัย', 'href' => 'entity.php?entity=housing_types', 'icon' => 'bi-buildings'],
  ['title' => 'นิสัยของสัตว์เลี้ยง', 'href' => 'entity.php?entity=personalities', 'icon' => 'bi-emoji-smile'],
  ['title' => 'เหตุผลหาบ้าน', 'href' => 'entity.php?entity=rehome_reasons', 'icon' => 'bi-question-circle'],
  ['title' => 'เงื่อนไขการรับเลี้ยง', 'href' => 'entity.php?entity=adoption_terms', 'icon' => 'bi-list-check'],
];

$active_module_title = '';
foreach ($modules as $m) {
    if (is_active_nav($m['href'])) {
        $active_module_title = $m['title'];
        break;
    }
}
if (!isset($pageTitle)) {
    $pageTitle = $active_module_title;
}
?><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<style>/* v5.3 Inline Premium Sidebar + Layout (shared include) */
:root{ --sidebar-width:260px; --brand-h:64px; --bg:#f4f6fb; --panel:#ffffff; --shadow:0 10px 30px rgba(16,24,40,.08); }
html,body{height:100%} body{background:var(--bg)!important}
.navbar .navbar-brand, header .navbar-brand{display:none!important}
.sidebar{position:fixed;inset:0 auto 0 0;width:var(--sidebar-width);background:#0b1021;color:#e5e7eb;z-index:1030;box-shadow:2px 0 16px rgba(0,0,0,.2);display:flex;flex-direction:column}
.sidebar .brand{height:var(--brand-h);display:flex;align-items:center;gap:10px;padding:0 18px;border-bottom:1px solid rgba(255,255,255,.06)}
.sidebar .brand .logo{width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,#6366f1,#22d3ee);box-shadow:0 6px 16px rgba(34,211,238,.35)}
.sidebar .brand .title{font-weight:700;letter-spacing:.3px;color:#fff}
.sidebar nav{overflow:auto;padding:12px}
.sidebar .section-title{font-size:.75rem;text-transform:uppercase;color:#94a3b8;padding:10px 12px 6px;letter-spacing:.06em}
.sidebar a.nav-link{color:#cbd5e1!important;padding:.6rem .85rem;border-radius:12px;display:flex;align-items:center;gap:10px;transition:all .15s ease}
.sidebar a.nav-link:hover{background:rgba(255,255,255,.08)!important;color:#fff!important;transform:translateX(2px)}
.sidebar a.nav-link.active{background:linear-gradient(135deg, rgba(99,102,241,.2), rgba(34,211,238,.2))!important;color:#fff!important;border:1px solid rgba(99,102,241,.35)}
.main{margin-left:var(--sidebar-width)!important;min-height:100vh;display:flex;flex-direction:column}
.topbar{height:var(--brand-h);display:flex;align-items:center;justify-content:space-between;padding:0 20px;background:var(--panel)!important;border-bottom:1px solid #eef0f4!important;position:sticky;top:0;z-index:1029;box-shadow:var(--shadow)!important}
.topbar .toggle-btn{border:none;background:transparent;font-size:24px}
.container-stretch{width:100%;max-width:1440px;margin:0 auto;padding:18px 22px}
@media (max-width:992px){.main{margin-left:0!important}.sidebar{transform:translateX(-100%);transition:transform .25s ease}body.show-sidebar .sidebar{transform:translateX(0)}}
</style>
<aside class="sidebar">
  <div class="brand">
    <div class="logo"></div>
    <div class="title">FHomePet • Admin</div>
  </div>
  <nav>
    <div class="section-title">GENERAL</div>
    <?php foreach($modules as $m): ?>
      <a class="nav-link <?= is_active_nav($m['href']) ? 'active' : '' ?>" href="<?= htmlspecialchars($m['href']) ?>">
        <i class="bi <?= htmlspecialchars($m['icon']) ?>"></i>
        <span class="ms-1"><?= htmlspecialchars($m['title']) ?></span>
      </a>
    <?php endforeach; ?>
  </nav>
</aside>
<div class="main">
  <div class="topbar">
    <div class="d-flex align-items-center gap-2">
      <button class="toggle-btn d-lg-none" id="sidebarToggle" title="Toggle sidebar"><i class="bi bi-list"></i></button>
      
      <?php // ========= ส่วนที่แก้ไข ========= ?>
      <?php // นำเงื่อนไข if ออก เพื่อให้แสดงหัวข้อในทุกหน้า ?>
      <h5 class="mb-0"><?= htmlspecialchars($pageTitle ?? 'Admin Panel') ?></h5>
      <?php // ============================= ?>

    </div>
    <div></div>
  </div>
  <div class="container-stretch">