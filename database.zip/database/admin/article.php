<?php
// C:\xampp\htdocs\admin\article.php - ระบบจัดการความรู้สัตว์เลี้ยง (ฉบับสมบูรณ์, ภาษาไทย, ใช้งานง่าย)

// 1. นำเข้าไฟล์จำเป็น
require_once __DIR__ . '/db.php';
// require_login(); 

// 2. กำหนดตัวแปรหลัก
$action = $_GET['action'] ?? 'list';
$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
$article_id = isset($_REQUEST['article_id']) ? intval($_REQUEST['article_id']) : 0;
$status_msg = ''; // สำหรับเก็บข้อความแจ้งเตือน

// กำหนด TinyMCE API Key
$tinymce_api_key = 'qsbqopkvbkjjj12ythhpnfcwtbvbv1uoiowx4lm97obvo4a5';

// =========================================================================
// ******************* โค้ดที่เพิ่ม: ฟังก์ชันดึงรูปภาพแรกจากเนื้อหา *******************
// =========================================================================
/**
 * ดึง URL รูปภาพแรกที่ปรากฏในเนื้อหา HTML (เช่น รูปภาพที่ลากวางใน TinyMCE)
 * @param string $html เนื้อหาความรู้สัตว์เลี้ยง
 * @return string|null URL ของรูปภาพแรก หรือ null หากไม่พบ
 */
function get_first_image_url($html) {
    // ใช้ Regular Expression เพื่อค้นหาแท็ก <img ... src="..."> ตัวแรก
    // แพทเทิร์นนี้พยายามจับ src="...", src='...' 
    if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $html, $matches)) {
        // $matches[1] คือ URL ที่ถูกจับคู่
        return $matches[1];
    }
    return null; // ไม่พบรูปภาพ
}
// =========================================================================

// ตรวจสอบ CSRF token สำหรับ action ที่เปลี่ยนแปลงข้อมูล
if (function_exists('csrf_fail')) {
    $token = $_REQUEST['_token'] ?? $_GET['_token'] ?? '';
    $csrf_actions = ['save', 'delete', 'delete_image', 'upload_image_inline']; // เพิ่ม action ใหม่
    if (in_array($action, $csrf_actions) && csrf_fail($token)) {
      die("โทเคนความปลอดภัย (CSRF) ไม่ถูกต้อง กรุณาลองใหม่");
    }
}


// =========================================================================
// 3. PROCESS ACTIONS
// =========================================================================

// --- ACTION: Image Upload Inline (สำหรับ TinyMCE) ---
if ($action === 'upload_image_inline') {
  header('Content-Type: application/json'); // API Response เป็น JSON
  
  if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $up = $_FILES['file'];
    $ext = pathinfo($up['name'], PATHINFO_EXTENSION);
    $filename_only = 'inline_' . time() . '_' . mt_rand(1000, 9999) . '.' . preg_replace('/[^a-z0-9]/i', '', $ext);

    $upload_dir = __DIR__ . '/uploads';
    if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

    $destination = $upload_dir . '/' . $filename_only;
    $db_url = 'uploads/' . $filename_only;
    
    if (move_uploaded_file($up['tmp_name'], $destination)) {
      $location = '/admin/' . $db_url; // สมมติว่าไฟล์นี้อยู่ใน /admin/
      echo json_encode(['location' => $location]);
      exit;
    }
  }
  
  // หากล้มเหลว
  echo json_encode(['error' => 'การอัปโหลดไฟล์ล้มเหลว']);
  http_response_code(400);
  exit;
}
// --- สิ้นสุด ACTION: Image Upload Inline ---


if ($action === 'save') {
  // --- Action: บันทึกข้อมูล ---
  $species = $_POST['species'] ?? 'dog';
  $title = $_POST['title'] ?? '';
  $tags = $_POST['tags'] ?? '';
  $reference_url = $_POST['reference_url'] ?? '';
  $published_at = $_POST['published_at'] ?? date('Y-m-d');
  $content = $_POST['content'] ?? '';
  $is_active = isset($_POST['is_active']) ? 1 : 0;
  $now = date('Y-m-d H:i:s');

  $new_id = $id; 

  if ($id) {
    // VVV --- ส่วนที่แก้ไข --- VVV
    $stmt = $db->prepare("UPDATE articles SET species=?, title=?, tags=?, reference_url=?, content=?, published_at=?, is_active=?, updated_at=? WHERE id=?");
    // แก้ไข type string จาก 'sssssisi' เป็น 'ssssssisi' ให้ครบ 9 ตัว
    $stmt->bind_param('ssssssisi', $species, $title, $tags, $reference_url, $content, $published_at, $is_active, $now, $id);
    // ^^^ --- จบส่วนที่แก้ไข --- ^^^
    $stmt->execute();
    $stmt->close();
  } else {
    $stmt = $db->prepare("INSERT INTO articles (species, title, tags, reference_url, content, published_at, is_active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param('ssssssisi', $species, $title, $tags, $reference_url, $content, $published_at, $is_active, $now, $now);
    $stmt->execute();
    $new_id = $db->insert_id; 
    $stmt->close();
  }

  header('Location: article.php?action=form&id=' . $new_id . '&status=update_saved');
  exit;
}

if ($action === 'delete') {
  // --- Action: ลบข้อมูล ---
  if ($id) {
    $db->query("DELETE FROM article_images WHERE article_id = " . intval($id));
    $db->query("DELETE FROM articles WHERE id = " . intval($id));
  }
  header('Location: article.php?action=list&status=deleted');
  exit;
}

// --- Action: Images (จัดการรูปภาพ - POST/DELETE) ---
if ($action === 'images' && $article_id) {
  // 3a. การอัปโหลดรูปภาพใหม่
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image']) && !isset($_POST['update_image_id'])) {
    $post_token = $_POST['_token'] ?? '';
    if (function_exists('csrf_fail') && csrf_fail($post_token)) {
      header('Location: article.php?action=images&article_id=' . $article_id . '&status=csrf_fail');
      exit;
    }

    $up = $_FILES['image'];
    if ($up['error'] === UPLOAD_ERR_OK) {
      $ext = pathinfo($up['name'], PATHINFO_EXTENSION);
      $filename_only = 'article_' . time() . '_' . mt_rand(1000, 9999) . '.' . preg_replace('/[^a-z0-9]/i', '', $ext);

      $upload_dir = __DIR__ . '/uploads';
      if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

      $destination = $upload_dir . '/' . $filename_only;

      if (move_uploaded_file($up['tmp_name'], $destination)) {
        $pos = $_POST['position'] ?? 'inline';
        $caption = $_POST['caption'] ?? null;
        $sort = intval($_POST['sort_order'] ?? 0);
        $db_url = 'uploads/' . $filename_only;

        $stmt = $db->prepare("INSERT INTO article_images (article_id, url, position, sort_order, caption) VALUES (?,?,?,?,?)");
        $stmt->bind_param('isssi', $article_id, $db_url, $pos, $sort, $caption);
        $stmt->execute();
        $stmt->close();
        header('Location: article.php?action=images&article_id=' . $article_id . '&status=uploaded');
        exit;
      }
    }
    header('Location: article.php?action=images&article_id=' . $article_id . '&status=upload_fail');
    exit;
  }

  // 3b. การแก้ไขรูปภาพที่มีอยู่ (Update)
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_image_id'])) {
    $image_id = intval($_POST['update_image_id']);
    $pos = $_POST['position'] ?? 'inline';
    $caption = $_POST['caption'] ?? null;
    $sort = intval($_POST['sort_order'] ?? 0);
    $new_url = null;
    $status = 'updated_meta';

    if ($image_id > 0) {
      $stmt_old = $db->prepare("SELECT url FROM article_images WHERE id = ?");
      $stmt_old->bind_param('i', $image_id);
      $stmt_old->execute();
      $old_url_res = $stmt_old->get_result();
      $old_url_row = $old_url_res->fetch_assoc();
      $old_url = $old_url_row ? $old_url_row['url'] : null;
      $stmt_old->close();

      if (isset($_FILES['new_image']) && $_FILES['new_image']['error'] === UPLOAD_ERR_OK) {
        $up = $_FILES['new_image'];
        $ext = pathinfo($up['name'], PATHINFO_EXTENSION);
        $filename_only = 'article_' . time() . '_' . mt_rand(1000, 9999) . '.' . preg_replace('/[^a-z0-9]/i', '', $ext);
        $upload_dir = __DIR__ . '/uploads';
        $destination = $upload_dir . '/' . $filename_only;

        if (move_uploaded_file($up['tmp_name'], $destination)) {
          $new_url = 'uploads/' . $filename_only;
          $status = 'updated_file';

          $file_to_delete = __DIR__ . '/' . $old_url;
          if ($old_url && file_exists($file_to_delete)) {
            @unlink($file_to_delete);
          }
        }
      }

      if ($new_url) {
        $stmt = $db->prepare("UPDATE article_images SET url=?, position=?, sort_order=?, caption=? WHERE id=? AND article_id=?");
        $stmt->bind_param('sssisi', $new_url, $pos, $sort, $caption, $image_id, $article_id);
      } else {
        $stmt = $db->prepare("UPDATE article_images SET position=?, sort_order=?, caption=? WHERE id=? AND article_id=?");
        $stmt->bind_param('ssisi', $pos, $sort, $caption, $image_id, $article_id);
      }

      $stmt->execute();
      $stmt->close();
    }

    header('Location: article.php?action=images&article_id=' . $article_id . '&status=' . $status);
    exit;
  }

  // 3c. การลบรูปภาพ
  if (isset($_GET['delete_image'])) {
    $image_id = intval($_GET['delete_image']);
    $stmt_old = $db->prepare("SELECT url FROM article_images WHERE id = ?");
    $stmt_old->bind_param('i', $image_id);
    $stmt_old->execute();
    $old_url_res = $stmt_old->get_result();
    $old_url_row = $old_url_res->fetch_assoc();
    $old_url = $old_url_row ? $old_url_row['url'] : null;
    $stmt_old->close();

    $db->query("DELETE FROM article_images WHERE id = " . intval($image_id) . " AND article_id = " . intval($article_id));

    $file_to_delete = __DIR__ . '/' . $old_url;
    if ($old_url && file_exists($file_to_delete)) {
      @unlink($file_to_delete);
    }

    header('Location: article.php?action=images&article_id=' . $article_id . '&status=deleted_image');
    exit;
  }
}


// =========================================================================
// 4. VIEW RENDERING (นำเข้า Header/Nav)
// =========================================================================

require_once __DIR__ . '/layout/header.php';
require_once __DIR__ . '/nav.inc.php';

// ตรวจสอบสถานะและกำหนดข้อความแจ้งเตือน (แปลเป็นไทย)
$alert_class = '';
$alert_msg = '';
if (isset($_GET['status'])) {
  switch ($_GET['status']) {
    case 'uploaded':
      $alert_class = 'success';
      $alert_msg = '✅ อัปโหลดรูปภาพหลักสำเร็จแล้ว';
      break;
    case 'deleted_image':
      $alert_class = 'success';
      $alert_msg = '✅ ลบรูปภาพสำเร็จแล้ว!';
      break;
    case 'updated_file':
      $alert_class = 'success';
      $alert_msg = '✅ บันทึกรูปภาพใหม่สำเร็จแล้ว! (ไฟล์เก่าถูกลบออกแล้ว)';
      break;
    case 'updated_meta':
      $alert_class = 'warning';
      $alert_msg = '⚠️ บันทึกข้อมูลตำแหน่ง/คำบรรยายสำเร็จแล้ว';
      break;
    case 'upload_fail':
      $alert_class = 'danger';
      $alert_msg = '❌ การอัปโหลดไฟล์ล้มเหลว กรุณาลองใหม่อีกครั้ง';
      break;
    case 'deleted':
      $alert_class = 'success';
      $alert_msg = '✅ ลบความรู้สัตว์เลี้ยงสำเร็จ';
      break;
    case 'saved':
    case 'update_saved':
      $alert_class = 'success';
      $alert_msg = '✅ บันทึกความรู้สัตว์เลี้ยงสำเร็จ';
      break;
  }
}
if ($alert_msg) {
  echo '<div class="container-stretch"><div class="alert alert-' . $alert_class . '">' . $alert_msg . '</div></div>';
}


switch ($action) {
  case 'list':
    // --- View: รายการความรู้สัตว์เลี้ยง (ปรับรูปแบบวันที่แสดงผลเป็น MM/DD/YYYY) ---

    $limit = 20;
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $offset = ($page - 1) * $limit;

    $species = $_GET['species'] ?? '';
    $active = $_GET['active'] ?? '';
    $start_date = $_GET['start_date'] ?? '';
    $end_date = $_GET['end_date'] ?? '';

    $whereParts = [];
    if ($species !== '') {
      $whereParts[] = "species = '" . $db->real_escape_string($species) . "'";
    }
    if ($active !== '') {
      $whereParts[] = "is_active = " . intval($active);
    }
    
    // โค้ดกรองตามช่วงวันที่
    if ($start_date !== '') {
        $whereParts[] = "published_at >= '" . $db->real_escape_string($start_date) . "'";
    }
    if ($end_date !== '') {
        $whereParts[] = "published_at <= '" . $db->real_escape_string($end_date) . "'";
    }
    
    $where_sql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

    $sql = "SELECT * FROM articles $where_sql ORDER BY published_at DESC, created_at DESC LIMIT " . intval($offset) . ", " . intval($limit);
    $res = $db->query($sql);
    if ($res === false) {
      echo '<div class="container-stretch"><p>เกิดข้อผิดพลาดในการดึงข้อมูล: ' . htmlspecialchars($db->error) . '</p></div>';
      break;
    }
?>
    <div class="container-stretch">
      <div class="card p-3 shadow-sm">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">รายการความรู้สัตว์เลี้ยงทั้งหมด</h1>
            <a class="btn btn-primary" href="article.php?action=form">
                <i class="bi bi-plus-circle"></i> เพิ่มเนื้อหาความรู้สัตว์เลี้ยง
            </a>
        </div>

        <form method="get" class="row g-3 align-items-end p-3 border rounded mb-4 bg-light">
          <input type="hidden" name="action" value="list">
          
          <div class="col-auto">
            <label class="form-label small text-muted mb-0">ประเภทสัตว์</label>
            <select name="species" class="form-select form-select-sm">
              <option value="">-- ทั้งหมด --</option>
              <option value="dog" <?= ($species === 'dog') ? 'selected' : '' ?>>สุนัข</option>
              <option value="cat" <?= ($species === 'cat') ? 'selected' : '' ?>>แมว</option>
            </select>
          </div>
          
          <div class="col-auto">
            <label class="form-label small text-muted mb-0">สถานะ</label>
            <select name="active" class="form-select form-select-sm">
              <option value="">-- ทั้งหมด --</option>
              <option value="1" <?= ($active === '1') ? 'selected' : '' ?>>เผยแพร่</option>
              <option value="0" <?= ($active === '0') ? 'selected' : '' ?>>ฉบับร่าง</option>
            </select>
          </div>
          
          <div class="col-auto">
            <label class="form-label small text-muted mb-0">วันที่เผยแพร่ (เริ่มต้น | ป/ด/ว)</label>
            <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" class="form-control form-control-sm">
          </div>
          <div class="col-auto">
            <label class="form-label small text-muted mb-0">ถึงวันที่ (สิ้นสุด | ป/ด/ว)</label>
            <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>" class="form-control form-control-sm">
          </div>
          
          <div class="col-auto">
            <button class="btn btn-sm btn-dark" type="submit">
                <i class="bi bi-funnel"></i> กรองข้อมูล
            </button>
          </div>
          <div class="col-auto">
            <a class="btn btn-sm btn-outline-secondary" href="article.php?action=list">
                <i class="bi bi-x"></i> ล้างค่า
            </a>
          </div>
        </form>

        <div class="table-responsive">
          <table class="table table-striped table-hover align-middle">
            <thead class="table-primary" style="background-color: #007bff; color: white;"> 
              <tr>
                <th style="width: 5%;">รูปปก</th> <th style="width: 5%;" class="text-center">ประเภท</th>
                <th style="width: 30%;">ชื่อหัวข้อ</th>
                <th style="width: 15%;">แท็ก</th>
                <th style="width: 10%; white-space: nowrap;">วันที่เผยแพร่</th>
                <th style="width: 10%;">สถานะ</th>
                <th style="width: 20%;">การดำเนินการ</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($res->num_rows): ?>
                <?php while ($row = $res->fetch_assoc()): ?>
                  <?php 
                    $published_date_mmddyyyy = date('m/d/Y', strtotime($row['published_at']));
                    $cover_image_url = null;

                    $stmt_cover = $db->prepare("SELECT url FROM article_images WHERE article_id = ? ORDER BY sort_order ASC, id ASC LIMIT 1");
                    $stmt_cover->bind_param('i', $row['id']);
                    $stmt_cover->execute();
                    $res_cover = $stmt_cover->get_result();
                    if ($row_cover = $res_cover->fetch_assoc()) {
                        $cover_image_url = '/admin/' . htmlspecialchars($row_cover['url']);
                    }
                    $stmt_cover->close();
                    
                    if (!$cover_image_url) {
                        $first_image_url_from_content = get_first_image_url($row['content']);
                        if ($first_image_url_from_content) {
                            if (strpos($first_image_url_from_content, 'http') === 0 || strpos($first_image_url_from_content, '/') === 0) {
                                $cover_image_url = $first_image_url_from_content;
                            } else {
                                $cover_image_url = '/admin/' . $first_image_url_from_content; 
                            }
                        }
                    }
                  ?>
                  <tr>
                    <td class="text-center">
                        <?php if ($cover_image_url): ?>
                            <img src="<?= $cover_image_url ?>" style="max-height: 50px; max-width: 100%; object-fit: cover; border-radius: 4px;" title="รูปปก: <?= htmlspecialchars($row['title']) ?>">
                        <?php else: ?>
                            <span class="text-muted small">ไม่มีรูป</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?= ($row['species'] == 'dog' ? 'สุนัข' : 'แมว') ?></td>
                    <td>
                        <?= htmlspecialchars($row['title']) ?>
                        
                    </td>
                    <td><?= htmlspecialchars($row['tags']) ?></td>
                    <td style="white-space: nowrap;"><?= $published_date_mmddyyyy ?></td> 
                    <td>
                        <span class="badge bg-<?= $row['is_active'] ? 'success' : 'secondary' ?>">
                            <?= $row['is_active'] ? '✅ เผยแพร่' : '❌ ฉบับร่าง' ?>
                        </span>
                    </td>
                    <td>
                      <div class="btn-group" role="group" aria-label="Article Actions">
                        <a href="article.php?action=form&id=<?= intval($row['id']) ?>" class="btn btn-sm btn-info text-white" title="แก้ไขความรู้สัตว์เลี้ยง">
                            <i class="bi bi-pencil-square"></i> แก้ไข
                        </a>
                        <a href="article.php?action=delete&id=<?= intval($row['id']) ?>&_token=<?= function_exists('csrf_token') ? csrf_token() : '' ?>" onclick="return confirm('ยืนยันการลบความรู้สัตว์เลี้ยง (ID: <?= intval($row['id']) ?>)? การกระทำนี้ไม่สามารถยกเลิกได้')" class="btn btn-sm btn-danger" title="ลบความรู้สัตว์เลี้ยง">
                            <i class="bi bi-trash"></i> ลบ
                        </a>
                      </div>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7" class="text-center text-muted">ไม่พบข้อมูลความรู้สัตว์เลี้ยง</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <?php
        $total_res = $db->query("SELECT COUNT(*) FROM articles $where_sql");
        $total_rows = $total_res->fetch_row()[0];
        $limit = 20; 
        $total_pages = ceil($total_rows / $limit);
        $total_res->close();

        if ($total_pages > 1):
        ?>
          <nav>
            <ul class="pagination justify-content-end">
              <?php for ($i = 1; $i <= $total_pages; $i++):
                $page_link = "article.php?action=list&page=$i";
                if ($species) $page_link .= '&species=' . urlencode($species);
                if ($active !== '') $page_link .= '&active=' . urlencode($active);
                if ($start_date) $page_link .= '&start_date=' . urlencode($start_date);
                if ($end_date) $page_link .= '&end_date=' . urlencode($end_date);
              ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                  <a class="page-link" href="<?= htmlspecialchars($page_link) ?>"><?= $i ?></a>
                </li>
              <?php endfor; ?>
            </ul>
          </nav>
        <?php endif; ?>

      </div>
    </div>
  <?php
    break;

  case 'form':
    $article = ['id' => 0, 'species' => 'dog', 'title' => '', 'content' => '', 'tags' => '', 'reference_url' => '', 'published_at' => date('Y-m-d'), 'is_active' => 1];

    if ($id) {
      $stmt = $db->prepare("SELECT * FROM articles WHERE id = ?");
      $stmt->bind_param('i', $id);
      $stmt->execute();
      $res = $stmt->get_result();
      if ($row = $res->fetch_assoc()) $article = $row;
      $stmt->close();
    }
  ?>
    <div class="container-stretch">
      <div class="card p-4 shadow-sm">
        <h1 class="h3 mb-4"><?php echo $id ? 'แก้ไขความรู้สัตว์เลี้ยง: ' . htmlspecialchars($article['title']) : 'เพิ่มเนื้อหาความรู้สัตว์เลี้ยง'; ?></h1>
        
        <?php if ($id): ?>
            <p class="text-muted small mb-3">
              * การจัดการรูปภาพสำหรับหัวเรื่อง/แบนเนอร์หลัก: 
              <a href="article.php?action=images&article_id=<?= intval($id) ?>" class="text-info">คลิกที่นี่</a>
            </p>
        <?php endif; ?>

        <form action="article.php?action=save" method="post">
          <input type="hidden" name="id" value="<?= intval($article['id']) ?>">
          <input type="hidden" name="_token" value="<?= function_exists('csrf_token') ? csrf_token() : '' ?>">
          
          <div class="row">
            <div class="col-md-8">
                <div class="mb-3">
                    <label class="form-label fw-bold">หัวข้อความรู้สัตว์เลี้ยง <span class="text-danger">*</span></label>
                    <input class="form-control" name="title" value="<?= htmlspecialchars($article['title']) ?>" required placeholder="กรอกชื่อความรู้สัตว์เลี้ยงที่ต้องการ">
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">เนื้อหาความรู้สัตว์เลี้ยง</label>
                    <p class="small text-muted mb-1">สามารถลากและวางรูปภาพลงในช่องนี้ได้ทันที</p>
                    <textarea class="form-control" name="content" rows="18" id="article_content"><?= htmlspecialchars($article['content']) ?></textarea>
                </div>
            </div>

            <div class="col-md-4">
                <div class="p-3 border rounded bg-light mb-4">
                    <h5 class="h6 mb-3 border-bottom pb-2">การตั้งค่าการเผยแพร่</h5>
                    <div class="mb-3">
                        <label class="form-label small text-muted">ประเภทสัตว์</label>
                        <select name="species" class="form-select">
                            <option value="dog" <?= ($article['species'] == 'dog') ? 'selected' : '' ?>>สุนัข (Dog)</option>
                            <option value="cat" <?= ($article['species'] == 'cat') ? 'selected' : '' ?>>แมว (Cat)</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small text-muted">แท็ก (Tags) <span class="fw-normal">(คั่นด้วยจุลภาค)</span></label>
                        <input class="form-control" name="tags" value="<?= htmlspecialchars($article['tags'] ?? '') ?>" placeholder="เช่น: อาหาร, สุขภาพ">
                    </div>

                    <div class="mb-3">
                        <label class="form-label small text-muted">แหล่งอ้างอิง (Reference URL)</label>
                        <textarea class="form-control" name="reference_url" rows="3" placeholder="ใส่ลิงก์ URL หรือข้อความอ้างอิง"><?= htmlspecialchars($article['reference_url'] ?? '') ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label small text-muted">วันที่เผยแพร่</label>
                        <input class="form-control" type="date" name="published_at" value="<?= htmlspecialchars($article['published_at']) ?>">
                    </div>
                    <div class="mb-0 form-check">
                        <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active_check" <?= ($article['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label fw-bold" for="is_active_check"> สถานะ: เผยแพร่ทันที</label>
                        <div class="small text-muted">(หากไม่เลือก จะถูกบันทึกเป็นฉบับร่าง)</div>
                    </div>
                </div>
                
                <div class="d-grid gap-2">
                    <button class="btn btn-lg btn-success shadow-sm" type="submit">
                        <i class="bi bi-save"></i> บันทึกความรู้สัตว์เลี้ยง
                    </button>
                    <a class="btn btn-outline-secondary" href="article.php?action=list">
                        <i class="bi bi-x-circle"></i> ยกเลิก/กลับหน้ารายการ
                    </a>
                </div>
            </div>
          </div>
        </form>
      </div>
    </div>
    
    <script src="https://cdn.tiny.cloud/1/<?= $tinymce_api_key ?>/tinymce/7/tinymce.min.js" referrerpolicy="origin"></script>
    <script>
      tinymce.init({
        selector: '#article_content', 
        height: 500,
        plugins: [
          'advlist', 'autolink', 'lists', 'link', 'image', 'charmap', 'preview',
          'anchor', 'searchreplace', 'visualblocks', 'code', 'fullscreen',
          'insertdatetime', 'media', 'table', 'help', 'wordcount', 'paste'
        ],
        toolbar: 'undo redo | blocks | ' +
          'bold italic backcolor | alignleft aligncenter ' +
          'alignright alignjustify | bullist numlist outdent indent | ' +
          'removeformat | image media link table code | fullscreen help',
        content_style: 'body { font-family:Helvetica,Arial,sans-serif; font-size:16px; line-height: 1.6; }' +
                       'img { max-width: 100%; height: auto; display: block; margin: 10px 0; }',

        image_title: true,
        automatic_uploads: true,
        images_file_types: 'jpeg,jpg,png,gif',
        
        images_upload_url: 'article.php?action=upload_image_inline&_token=<?= function_exists("csrf_token") ? csrf_token() : "" ?>',
        
        images_upload_handler: function (blobInfo, success, failure) {
          var xhr, formData;

          xhr = new XMLHttpRequest();
          xhr.withCredentials = false;
          xhr.open('POST', 'article.php?action=upload_image_inline&_token=<?= function_exists("csrf_token") ? csrf_token() : "" ?>'); 

          xhr.onload = function() {
            var json;

            if (xhr.status === 403) {
              failure('ข้อผิดพลาด: โทเคนความปลอดภัยไม่ถูกต้อง');
              return;
            }

            if (xhr.status < 200 || xhr.status >= 300) {
              failure('ข้อผิดพลาดในการอัปโหลด: รหัส HTTP ' + xhr.status);
              return;
            }

            try {
                json = JSON.parse(xhr.responseText);
            } catch (e) {
                failure('คำตอบจากเซิร์ฟเวอร์ไม่ถูกต้อง: ' + xhr.responseText);
                return;
            }


            if (!json || typeof json.location != 'string') {
              failure('การอัปโหลดล้มเหลว: ' + (json && json.error ? json.error : 'ไม่พบ URL รูปภาพในคำตอบ'));
              return;
            }

            success(json.location);
          };

          xhr.onerror = function () {
            failure('การอัปโหลดล้มเหลวเนื่องจากข้อผิดพลาดเครือข่าย');
          };

          formData = new FormData();
          formData.append('file', blobInfo.blob(), blobInfo.filename());

          xhr.send(formData);
        },
        
        relative_urls: false, 
        remove_script_host: true,
      });
    </script>
    <?php
    break;

  case 'images':
    // --- View: การจัดการรูปภาพหลัก ---
    
    if (!$article_id) {
      echo '<div class="container-stretch"><div class="card p-3"><p>ไม่พบรหัสความรู้สัตว์เลี้ยง (Article ID)</p></div></div>';
      break;
    }
    $article_title = 'รหัส: ' . intval($article_id); 
    $stmt_title = $db->prepare("SELECT title FROM articles WHERE id = ?");
    $stmt_title->bind_param('i', $article_id);
    if ($stmt_title->execute()) {
      $res_title = $stmt_title->get_result();
      if ($row_title = $res_title->fetch_assoc()) {
        $article_title = $row_title['title'];
      }
    }
    $stmt_title->close();

    $sql = "SELECT * FROM article_images WHERE article_id = " . intval($article_id) . " ORDER BY sort_order ASC, id ASC";
    $res = $db->query($sql);
  ?>
    <div class="container-stretch">
      <div class="card p-4 shadow-sm">
        <h1 class="h3 mb-4">จัดการรูปภาพหลัก: <?= htmlspecialchars($article_title) ?></h1>
        <p><a href="article.php?action=form&id=<?= intval($article_id) ?>" class="btn btn-sm btn-secondary">← กลับไปหน้าแก้ไขความรู้สัตว์เลี้ยง</a></p>
        
        <div class="alert alert-info border-info">
            <h6 class="mb-1 fw-bold">💡 หมายเหตุสำคัญ</h6>
            <p class="mb-0 small">
                รูปภาพที่ใช้ **ในเนื้อหาความรู้สัตว์เลี้ยง** สามารถ **ลากและวาง** หรือ **อัปโหลด** ได้โดยตรงจาก Rich Text Editor ในหน้าแก้ไขความรู้สัตว์เลี้ยงแล้ว <br>
                หน้านี้ใช้สำหรับจัดการรูปภาพประกอบหลักของความรู้สัตว์เลี้ยงเท่านั้น
            </p>
        </div>


        <h3 class="h5 mt-4">อัปโหลดรูปภาพหลัก</h3>
        <form method="post" enctype="multipart/form-data" class="row g-3 p-3 border rounded mb-4 bg-light" action="article.php?action=images&article_id=<?= intval($article_id) ?>">
          <input type="hidden" name="_token" value="<?= function_exists('csrf_token') ? csrf_token() : '' ?>">

          <div class="col-md-4">
            <label class="form-label small">ไฟล์รูปภาพ <span class="text-danger">*</span></label>
            <input type="file" name="image" class="form-control form-control-sm" required>
          </div>
          <div class="col-md-4">
            <label class="form-label small">ตำแหน่ง (Position)</label>
            <select name="position" class="form-select form-select-sm">
              <option value="top">Top (รูปหัวเรื่อง)</option>
              <option value="inline" selected>Inline (แทรกในเนื้อหา)</option>
              <option value="bottom">Bottom (รูปปิดท้าย)</option>
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label small">ลำดับ (Sort)</label>
            <input name="sort_order" class="form-control form-control-sm" value="0" type="number">
          </div>
          <div class="col-md-10">
            <label class="form-label small">คำบรรยาย (Caption)</label>
            <input name="caption" class="form-control form-control-sm">
          </div>
          <div class="col-md-2 d-flex align-items-end">
            <button class="btn btn-primary btn-sm w-100" type="submit">อัปโหลด</button>
          </div>
        </form>

        <h3 class="h5 mt-4">รายการรูปภาพที่บันทึกแยก</h3>
        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead class="table-dark">
              <tr>
                <th style="width: 5%;">#ID</th>
                <th style="width: 10%;">ตัวอย่าง</th>
                <th style="width: 30%;">URL ไฟล์</th>
                <th style="width: 15%;">ตำแหน่ง</th>
                <th style="width: 5%;">ลำดับ</th>
                <th style="width: 20%;">คำบรรยาย</th>
                <th style="width: 15%;">ดำเนินการ</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($res && $res->num_rows): ?>
                <?php while ($row = $res->fetch_assoc()): ?>
                  <?php $full_url = '/admin/' . htmlspecialchars($row['url']); ?>
                  <tr>
                    <td><?= intval($row['id']) ?></td>
                    <td><?php if ($row['url']): ?><img src="<?= $full_url ?>" style="max-height:60px; border-radius: 4px;"><?php endif; ?></td>
                    <td><code class="small text-break"><?= $full_url ?></code></td>
                    <td>
                        <span class="badge bg-secondary"><?= htmlspecialchars($row['position']) ?></span>
                    </td>
                    <td><?= intval($row['sort_order']) ?></td>
                    <td><?= htmlspecialchars($row['caption']) ?></td>
                    <td>
                      <button class="btn btn-sm btn-info text-white me-1"
                        onclick="openEditModal(
                            <?= intval($row['id']) ?>, 
                            '<?= htmlspecialchars($row['position']) ?>', 
                            <?= intval($row['sort_order']) ?>, 
                            '<?= htmlspecialchars($row['caption'] ?? '') ?>'
                        )" title="แก้ไขข้อมูลรูปภาพ">
                        <i class="bi bi-pencil"></i>
                      </button>

                      <a href="article.php?action=images&article_id=<?= intval($article_id) ?>&delete_image=<?= intval($row['id']) ?>&_token=<?= function_exists('csrf_token') ? csrf_token() : '' ?>"
                        onclick="return confirm('ยืนยันลบรูปภาพ (ID: <?= intval($row['id']) ?>)? ไฟล์จะถูกลบออกจากเซิร์ฟเวอร์ด้วย')"
                        class="btn btn-sm btn-danger" title="ลบรูปภาพ">
                        <i class="bi bi-trash"></i>
                      </a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7" class="text-center text-muted">ไม่พบรูปภาพ</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    
    <div class="modal fade" id="editImageModal" tabindex="-1" aria-labelledby="editImageModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post" enctype="multipart/form-data" action="article.php?action=images&article_id=<?= intval($article_id) ?>">
            <input type="hidden" name="_token" value="<?= function_exists('csrf_token') ? csrf_token() : '' ?>">
            <input type="hidden" name="update_image_id" id="modal_update_image_id" value="">
            <div class="modal-header">
              <h5 class="modal-title" id="editImageModalLabel">แก้ไขรูปภาพหลัก ID: <span id="modal_image_id_text"></span></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">ตำแหน่ง (Position)</label>
                <select name="position" class="form-select" id="modal_position">
                  <option value="top">Top (รูปหัวเรื่อง)</option>
                  <option value="inline">Inline (แทรกในเนื้อหา)</option>
                  <option value="bottom">Bottom (รูปปิดท้าย)</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">ลำดับ (Sort order)</label>
                <input name="sort_order" class="form-control" type="number" id="modal_sort_order">
              </div>
              <div class="mb-3">
                <label class="form-label">คำบรรยาย (Caption)</label>
                <input name="caption" class="form-control" id="modal_caption">
              </div>
              <div class="mb-3">
                <label class="form-label">เปลี่ยนไฟล์รูปภาพ</label>
                <input type="file" name="new_image" class="form-control">
                <small class="text-muted">หาก <strong>ไม่เลือกไฟล์ใหม่</strong> จะบันทึกเฉพาะข้อมูลอื่นๆ เท่านั้น</small>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
              <button type="submit" class="btn btn-success">บันทึกการแก้ไข</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <script>
      function openEditModal(id, pos, sort, caption) {
        document.getElementById('modal_image_id_text').textContent = id;
        document.getElementById('modal_update_image_id').value = id;
        document.getElementById('modal_position').value = pos;
        document.getElementById('modal_sort_order').value = sort;
        document.getElementById('modal_caption').value = caption;
        const modal = new bootstrap.Modal(document.getElementById('editImageModal'));
        modal.show();
      }
    </script>

<?php
    break;
    
  default:
    // หาก action ไม่ถูกต้อง ให้กลับไปหน้ารายการ
    header('Location: article.php?action=list');
    exit;
}

// 5. นำเข้า Footer
require_once __DIR__ . '/layout/footer.php';
?>