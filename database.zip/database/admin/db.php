<?php
// C:\xampp\htdocs\db_fhomepet\db.php (ฉบับแก้ไข: ทำให้การเชื่อมต่อล้มเหลวอย่างเงียบ ๆ สำหรับ API)

// ใช้ if (!defined(...)) เพื่อป้องกันการเรียกไฟล์และประกาศฟังก์ชันซ้ำซ้อน
if (!defined('DB_INCLUDED')) {
    define('DB_INCLUDED', true);

    // เริ่ม Session หากยังไม่ได้เริ่ม
    if (session_status()===PHP_SESSION_NONE) session_start();
    
    // โหลดไฟล์ config และดึงข้อมูลการเชื่อมต่อ
    $config = require __DIR__.'/config.php';
    $db_config = $config['db'];
    
    // *** 1. การเชื่อมต่อ MySQLi ($db) - ใช้ @ นำหน้าเพื่อป้องกัน Warning/Notice หากเชื่อมต่อไม่ได้ ***
    @$db = new mysqli(
        $db_config['host'], 
        $db_config['user'], 
        $db_config['pass'], 
        $db_config['name'], 
        $db_config['port'] ?? 3306
    );

    // ตรวจสอบข้อผิดพลาดในการเชื่อมต่อ (ไม่ใช้ die() แต่ตั้งค่าเป็น null แทน)
    if ($db->connect_error) {
        error_log("MySQLi Connection failed: " . $db->connect_error);
        $db = null; // ตั้งค่า $db เป็น null หากเชื่อมต่อไม่ได้
    } else {
        // ตั้งค่า charset
        if (isset($db_config['charset'])) {
            $db->set_charset($db_config['charset']);
        }
    }
    
    // *** 2. ส่วน PDO ($pdo) - ใช้ Try/Catch เพื่อป้องกัน Fatal Error และทำให้ $pdo เป็น null ***
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s',
        $db_config['host'],
        $db_config['port'] ?? 3306,
        $db_config['name'],
        $db_config['charset'] ?? 'utf8mb4'
    );
    try {
        $pdo = new PDO($dsn,$db_config['user'],$db_config['pass'],[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false
        ]);
    } catch (PDOException $e) {
        error_log("PDO Connection failed: " . $e->getMessage());
        $pdo = null; // กำหนดให้เป็น null หากเชื่อมต่อไม่ได้
    }

    // 3. การจัดการ CSRF Token และฟังก์ชันช่วย (ไม่เปลี่ยนแปลง)
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    
    function csrf_token(){return $_SESSION['csrf_token']??'';}
    function csrf_fail($t){return !$t||!hash_equals($_SESSION['csrf_token']??'', $t);}
    function is_logged_in(){return !empty($_SESSION['uid']);}
    function require_login(){ if(!is_logged_in()){ header('Location: login.php'); exit; } }

}
