<?php
function entity_meta(){
  return [
    'users' => [
      'pk' => 'id',
      'title' => 'ผู้ใช้งาน',
      'columns' => [
        ['name' => 'username', 'label' => 'ชื่อผู้ใช้งาน', 'type' => 'text'],
        ['name' => 'email', 'label' => 'อีเมล', 'type' => 'text'],
        ['name' => 'userType', 'label' => 'ประเภท', 'type' => 'text', 'help' => 'ระบุ fhome (ผู้หาบ้าน) หรือ fpet (ผู้รับเลี้ยง)'],
        
        // --- โค้ดที่เพิ่มเข้ามา ---
        [
            'name' => 'status', 
            'label' => 'สถานะ', 
            'type' => 'select-custom', // ใช้ type พิเศษเพื่อสร้าง dropdown
            'options' => [
                'active' => 'ใช้งาน (Active)',
                'suspended' => 'ระงับการใช้งาน (Suspended)'
            ],
            'help' => 'เลือก "ระงับการใช้งาน" เพื่อบล็อคผู้ใช้'
        ],
        // --- จบส่วนที่เพิ่ม ---

        ['name' => 'password', 'label' => 'รหัสผ่านใหม่', 'type' => 'text', 'help' => 'เว้นว่างไว้หากไม่ต้องการเปลี่ยนรหัสผ่าน'],
        ['name' => 'profilePicture', 'label' => 'รูปโปรไฟล์', 'type' => 'text', 'help' => 'ระบุชื่อไฟล์รูปภาพ'],
      ]
    ],
    'pet_species' => [
      'pk'=>'species_id','title'=>'ชนิดสัตว์เลี้ยง',
      'columns'=>[
        ['name'=>'code','label'=>'รหัส (เช่น dog/cat)','type'=>'text','required'=>true],
        ['name'=>'name_th','label'=>'ชื่อภาษาไทย','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อภาษาอังกฤษ','type'=>'text','required'=>false],
      ]
    ],
    'breeds' => [
      'pk'=>'breed_id','title'=>'สายพันธุ์สัตว์เลี้ยง',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อภาษาไทย','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อภาษาอังกฤษ','type'=>'text','required'=>false],
        ['name'=>'species_id','label'=>'ชนิดสัตว์','type'=>'select','required'=>true,'source'=>'pet_species'],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1],
      ]
    ],
    'vaccines' => [
      'pk'=>'vaccine_id','title'=>'ข้อมูลวัคซีน',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อวัคซีน (ไทย)','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อวัคซีน (อังกฤษ)','type'=>'text','required'=>false],
        ['name'=>'species_id','label'=>'ชนิดสัตว์ที่เกี่ยวข้อง','type'=>'select-nullable','required'=>false,'source'=>'pet_species'],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1],
      ]
    ],
    'housing_types' => [
      'pk'=>'housing_id','title'=>'ประเภทที่อยู่อาศัย',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อ (TH)','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อ (EN)','type'=>'text','required'=>false],
        ['name'=>'description','label'=>'รายละเอียด','type'=>'textarea','required'=>false],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1],
      ]
    ],
    'personalities' => [
      'pk'=>'personality_id','title'=>'ลักษณะนิสัยโดยรวม',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อ (TH)','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อ (EN)','type'=>'text','required'=>false],
        ['name'=>'description','label'=>'รายละเอียด','type'=>'textarea','required'=>false],
        ['name'=>'species_id','label'=>'ชนิดสัตว์เลี้ยง','type'=>'select-nullable','required'=>false,'source'=>'pet_species'],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1],
      ]
    ],
    'rehome_reasons' => [
      'pk'=>'reason_id','title'=>'เหตุผลในการหาบ้าน',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อ (TH)','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อ (EN)','type'=>'text','required'=>false],
        ['name'=>'description','label'=>'รายละเอียด','type'=>'textarea','required'=>false],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1],
      ]
    ],
    'adoption_terms' => [
      'pk'=>'term_id','title'=>'เงื่อนไขการรับเลี้ยง',
      'columns'=>[
        ['name'=>'name_th','label'=>'ชื่อ (TH)','type'=>'text','required'=>true],
        ['name'=>'name_en','label'=>'ชื่อ (EN)','type'=>'text','required'=>false],
        ['name'=>'description','label'=>'รายละเอียด','type'=>'textarea','required'=>false, 'help' => 'ข้อความอธิบายเพิ่มเติมของเงื่อนไข'],
        ['name'=>'is_active','label'=>'สถานะ (เปิดใช้งาน)','type'=>'bool','required'=>true,'default'=>1, 'help' => 'เมื่อเปิดใช้งาน เงื่อนไขนี้จะแสดงให้ผู้ใช้เลือกในหน้าแอป'],
      ]
    ],
  ];
}

function get_species_map($pdo) {
    try {
        $stmt = $pdo->query("SELECT species_id, name_th, code FROM pet_species");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ($data as $row) {
            $map[$row['species_id']] = ['th' => $row['name_th'], 'code' => $row['code']];
        }
        if (empty($map) || !isset($map[1]) || !isset($map[2])) {
             $map[1] = ['th' => 'หมา', 'code' => 'dog'];
             $map[2] = ['th' => 'แมว', 'code' => 'cat'];
        }
        return $map;
    } catch (\PDOException $e) {
        return [
            1 => ['th' => 'หมา', 'code' => 'dog'],
            2 => ['th' => 'แมว', 'code' => 'cat']
        ];
    }
}

function ensure_entity($e){ 
    $m=entity_meta(); 
    if(!isset($m[$e])){
        http_response_code(400); 
        echo json_encode(['status'=>'error','message'=>'Unknown entity']); 
        exit;
    } 
    return $m[$e]; 
}
?>