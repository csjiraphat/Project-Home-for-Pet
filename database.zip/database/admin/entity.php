<?php
require __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php'; 
global $pdo;

$entity = $_GET['entity'] ?? 'vaccines';
$meta = entity_meta();
if (!isset($meta[$entity])) { http_response_code(404); echo "ไม่พบเอนทิตี้นี้"; exit; }
$def = $meta[$entity];
$title = 'จัดการ: ' . $def['title'];

$species_map_data = get_species_map($pdo); 
$current_species_filter = $_GET['species_filter'] ?? ''; 
$current_search_q = $_GET['q'] ?? ''; 
$current_active_filter = $_GET['active_filter'] ?? ''; 


include __DIR__ . '/layout/header.php';
include __DIR__ . '/nav.inc.php';
?>
<div class="card p-3 shadow-sm">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h1 class="h3 mb-0">จัดการข้อมูล: <?= htmlspecialchars($def['title']) ?></h1>
    <div class="d-flex gap-2">
      <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#editModal" onclick="openCreate()">
        <i class="bi bi-plus-circle"></i> เพิ่มข้อมูลใหม่
      </button>
    </div>
  </div>

  <form id="filterForm" class="row g-3 align-items-end p-3 border rounded mb-4 bg-light">
    <input type="hidden" name="entity" value="<?= htmlspecialchars($entity) ?>">

    <?php 
    $is_active_column_exists = in_array('is_active', array_column($def['columns'], 'name'));
    if ($entity === 'breeds' || $entity === 'personalities' || $entity === 'vaccines'): 
    ?>
    <div class="col-auto">
      <label class="form-label small text-muted mb-0">กรองตามชนิดสัตว์</label>
      <select name="species_filter" id="speciesFilter" class="form-select form-select-sm" onchange="document.getElementById('filterForm').submit()">
        <option value="">— ทุกชนิด —</option>
        <?php foreach ($species_map_data as $id => $data): ?>
            <option value="<?= htmlspecialchars($id) ?>" <?= (string)$current_species_filter === (string)$id ? 'selected' : '' ?>>
                <?= htmlspecialchars($data['th']) ?>
            </option>
        <?php endforeach; ?>
      </select>
    </div>
    <?php endif; ?>
    
    <?php if ($is_active_column_exists): ?>
    <div class="col-auto">
      <label class="form-label small text-muted mb-0">สถานะ</label>
      <select name="active_filter" id="activeFilter" class="form-select form-select-sm" onchange="document.getElementById('filterForm').submit()">
        <option value="">— ทั้งหมด —</option>
        <option value="1" <?= $current_active_filter === '1' ? 'selected' : '' ?>>ใช้งาน (Active)</option>
        <option value="0" <?= $current_active_filter === '0' ? 'selected' : '' ?>>ปิดใช้งาน (Inactive)</option>
      </select>
    </div>
    <?php endif; ?>
    
    <div class="col-auto">
      <label class="form-label small text-muted mb-0">ค้นหา</label>
      <input id="q" name="q" class="form-control form-control-sm" placeholder="ค้นหาข้อมูล..." style="width: 200px;" value="<?= htmlspecialchars($current_search_q) ?>"/>
    </div>
    
    <div class="col-auto">
      <button class="btn btn-sm btn-dark" type="submit">
        <i class="bi bi-search"></i> ค้นหา
      </button>
    </div>
    <div class="col-auto">
      <a class="btn btn-sm btn-outline-secondary" href="entity.php?entity=<?= htmlspecialchars($entity) ?>">
        <i class="bi bi-x"></i> ล้างค่า
      </a>
    </div>
    <div class="col-auto">
      <a class="btn btn-sm btn-outline-secondary" id="exportBtn" target="_blank">
        <i class="bi bi-download"></i> Export CSV
      </a>
    </div>
  </form>

  <div class="table-responsive">
    <table class="table table-striped table-hover align-middle" id="dataTable">
      <thead style="background-color: #E9ECEF; color: black !important; border-bottom: 2px solid #dee2e6;"><tr id="theadRow"></tr></thead>
      <tbody id="tbody"></tbody>
    </table>
  </div>
  <nav><ul class="pagination justify-content-end" id="pager"></ul></nav>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalTitle">เพิ่ม/แก้ไข</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="formError" class="alert alert-danger d-none"></div>
        <form id="editForm" class="row g-3"></form>
        <input type="hidden" id="csrf" value="<?= htmlspecialchars(function_exists('csrf_token') ? csrf_token() : '') ?>"/>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
        <button type="button" class="btn btn-success" onclick="submitForm()">บันทึกข้อมูล</button>
      </div>
    </div>
  </div>
</div>

<script>
const ENTITY = <?= json_encode($entity) ?>;
const DEF = <?= json_encode($def, JSON_UNESCAPED_UNICODE) ?>;
const PK = DEF.pk;
const SPECIES_MAP = <?= json_encode($species_map_data, JSON_UNESCAPED_UNICODE) ?>;
const CURRENT_SPECIES_FILTER = "<?= htmlspecialchars($current_species_filter) ?>";
const CURRENT_ACTIVE_FILTER = "<?= htmlspecialchars($current_active_filter) ?>"; 


function $(s){ return document.querySelector(s); }
function el(tag, attrs={}, children=[]){
  const e = document.createElement(tag);
  for (const [k,v] of Object.entries(attrs)) {
    if (k==='class') e.className = v;
    else if (k==='for') e.htmlFor = v;
    else if (k==='checked') e.checked = !!v;
    else if (k.startsWith('on')) e[k] = v;
    else e.setAttribute(k, v);
  }
  (Array.isArray(children)?children:[children]).forEach(c => {
    if (c==null) return;
    if (typeof c === 'string') e.appendChild(document.createTextNode(c));
    else e.appendChild(c);
  });
  return e;
}

async function http(url, opts={}){
  const base = Object.assign({credentials:'same-origin'}, opts);
  try{
    return await fetch(url, base);
  }catch(e){
    if (base.method==='PUT' || base.method==='DELETE'){
      const override = base.method;
      const u = url + (url.includes('?')?'&':'?') + '_method=' + override;
      return await fetch(u, Object.assign({}, base, {method:'POST'}));
    }
    throw e;
  }
}
let CUR_PAGE = 1, CUR_PER = 20, CUR_Q = '';


function buildHeader(){
  const thead = document.getElementById('theadRow'); thead.innerHTML = '';
  (DEF.columns||[]).forEach(c => {
      const th = el('th', {style: 'white-space: nowrap;'}, c.label||c.name);
      thead.appendChild(th);
  });
  thead.appendChild(el('th',{},'จัดการ'));
  const theadElement = document.getElementById('dataTable').querySelector('thead');
  if (theadElement) {
      theadElement.style.color = 'black';
      theadElement.style.backgroundColor = '#E9ECEF'; 
  }
}
buildHeader();

async function fetchList(page=1){
  CUR_PAGE = page;
  CUR_Q = (document.getElementById('q')?.value || '').trim();
  
  let url = `api.php?entity=${encodeURIComponent(ENTITY)}&page=${page}&per=${CUR_PER}&q=${encodeURIComponent(CUR_Q)}`;
  
  if (CURRENT_SPECIES_FILTER) {
      url += `&species_id=${encodeURIComponent(CURRENT_SPECIES_FILTER)}`;
  }
  if (CURRENT_ACTIVE_FILTER !== '') {
      url += `&is_active=${encodeURIComponent(CURRENT_ACTIVE_FILTER)}`;
  }

  const exportBtn = document.getElementById('exportBtn');
  if (exportBtn) exportBtn.href = url + '&export=csv';

  try{
    const res = await fetch(url);
    const json = await res.json();
    renderTable(json.data||[]);
    renderPager(json.total||0, json.page||1, json.per||20);
  }catch(e){
    console.warn('fetch list error', e);
  }
}

// --- ฟังก์ชันที่แก้ไข ---
function renderTable(rows){
  const tb = document.getElementById('tbody'); tb.innerHTML = '';
  rows.forEach((r,idx)=>{
    const isSuspended = ENTITY === 'users' && r.status === 'suspended';
    const tr = el('tr', { style: isSuspended ? 'background-color: #f8d7da; text-decoration: line-through;' : '' });
    
    (DEF.columns||[]).forEach(c => {
      let txt = r?.[c.name];

      if (ENTITY === 'users' && c.name === 'status') {
          if (r.status === 'suspended') {
              txt = el('span', {class: 'badge bg-danger'}, 'ถูกระงับ');
          } else {
              txt = el('span', {class: 'badge bg-success'}, 'ใช้งาน');
          }
      } else if (c.type==='bool') {
          txt = r?.[c.name] ? '✅ ใช้งาน' : '❌ ปิดใช้งาน';
      } else if (c.name === 'species_id') {
          const speciesId = r?.[c.name];
          if (speciesId !== null && SPECIES_MAP[speciesId]) {
              txt = SPECIES_MAP[speciesId].th;
          } else if (speciesId === null || speciesId === '') {
              txt = 'ทุกชนิด'; 
          } else {
              txt = String(speciesId);
          }
      }
      
      const td = el('td');
      if (typeof txt === 'object' && txt !== null) {
          td.appendChild(txt);
      } else {
          td.textContent = String(txt ?? '');
      }
      tr.appendChild(td);
    });
    const act = el('td');
    
    act.appendChild(el('button',{class:'btn btn-sm btn-info text-white', onclick:()=>openEdit(r[PK])},'แก้ไข'));
    
    tr.appendChild(act);
    tb.appendChild(tr);
  });
}

function renderPager(total, page, per){
  const pages = Math.max(1, Math.ceil(total/per));
  const ul = document.getElementById('pager'); ul.innerHTML='';
  const mk = (p, text, disabled=false, active=false)=>{
    const li = el('li',{class:`page-item ${disabled?'disabled':''} ${active?'active':''}`});
    const a = el('a',{class:'page-link', href:'#'} , text);
    a.addEventListener('click', (e)=>{ 
        e.preventDefault(); 
        if(!disabled) {
            const q = document.getElementById('q')?.value || '';
            const speciesId = document.getElementById('speciesFilter')?.value || '';
            const isActive = document.getElementById('activeFilter')?.value || '';
            let url = `entity.php?entity=${ENTITY}&page=${p}&q=${encodeURIComponent(q)}`;
            if (speciesId) url += `&species_filter=${encodeURIComponent(speciesId)}`;
            if (isActive !== '') url += `&active_filter=${encodeURIComponent(isActive)}`;
            window.location.href = url;
        } 
    });
    li.appendChild(a);
    return li;
  };
  ul.appendChild(mk(page-1, '« หน้าก่อนหน้า', page<=1)); 
  for(let i=1;i<=pages;i++){ ul.appendChild(mk(i, String(i), false, i===page)); }
  ul.appendChild(mk(page+1, 'หน้าถัดไป »', page>=pages)); 
}

let CURRENT_ID = null;
function openCreate(){
  CURRENT_ID = null;
  document.getElementById('modalTitle').textContent = `เพิ่มข้อมูล ${DEF.title}`; 
  buildForm({});
}
async function openEdit(id){
  try { var m = new bootstrap.Modal(document.getElementById('editModal')); m.show(); } catch(e){}
  CURRENT_ID = id;
  document.getElementById('modalTitle').textContent = `แก้ไขข้อมูล ${DEF.title}`; 
  
  const res2 = await fetch(`api.php?entity=${encodeURIComponent(ENTITY)}&id=${id}`);
  
  const json = await res2.json();
  const row = json.data && json.data.length > 0 ? json.data[0] : {}; 
  buildForm(row);
}

// --- ฟังก์ชันที่แก้ไข ---
async function buildForm(row){
  const form = document.getElementById('editForm'); form.innerHTML='';
  const error = document.getElementById('formError');
  
  try{
    if (!Array.isArray(DEF.columns) || DEF.columns.length===0) {
      error.classList.remove('d-none');
      error.textContent = 'helpers.php ไม่ได้กำหนด columns สำหรับเอนทิตี้นี้ หรือฝั่ง PHP คืนข้อมูลไม่ถูกต้อง';
      return;
    }

    (DEF.columns||[]).forEach(c => {
      const id = 'f_' + c.name;
      const wrap = el('div',{class:'col-md-6'});
      const labelEl = el('label',{for:id, class:'form-label'}, c.label || c.name);
      if (c.help) {
        const info = el('span', {class:'ms-1 text-muted', 'data-bs-toggle':'tooltip', title: c.help}, '🛈');
        labelEl.appendChild(info);
      }
      wrap.appendChild(labelEl);
      let input;
      const val = row[c.name];

      if (c.type==='text') {
        input = el('input',{id, name:c.name, class:'form-control', value: (val??'')});
      } else if (c.type==='textarea') {
        input = el('textarea',{id,name:c.name,class:'form-control', rows:3}, String(val??''));
      } else if (c.type==='bool') {
        const chk = el('input',{id,name:c.name,type:'checkbox', class:'form-check-input', checked: !!(val ?? c.default ?? 0)});
        input = el('div',{class:'form-check'}, [chk, el('label',{for:id, class:'form-check-label ms-2'}, 'เปิดใช้งาน')]); 
      } else if (c.type==='select-custom') {
        const sel = el('select',{id,name:c.name,class:'form-select'});
        Object.entries(c.options || {}).forEach(([value, label]) => {
            const opt = el('option',{value:value}, String(label));
            if (String(value)===String(val)) opt.setAttribute('selected','selected');
            sel.appendChild(opt);
        });
        input = sel;
      } else if (c.type==='select' || c.type==='select-nullable') {
        const sel = el('select',{id,name:c.name,class:'form-select'});
        if (c.type==='select-nullable') sel.appendChild(el('option',{value:''},'— เลือกชนิดสัตว์ —')); 
        if (c.source==='pet_species') {
          Object.entries(SPECIES_MAP).forEach(([species_id, data]) => {
            const label = data.th || data.code || species_id;
            const opt = el('option',{value:species_id}, String(label));
            if (String(species_id)===String(val)) opt.setAttribute('selected','selected');
            sel.appendChild(opt);
          });
        }
        input = sel;
      } else {
        input = el('input',{id, name:c.name, class:'form-control', value: (val??'')});
      }
      wrap.appendChild(input);
      form.appendChild(wrap);
    });
    error.classList.add('d-none');
    if (window.bootstrap && bootstrap.Tooltip) {
      document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el => new bootstrap.Tooltip(el));
    }
  }catch(e){
    console.error(e);
    error.classList.remove('d-none');
    error.textContent = 'เกิดข้อผิดพลาดในการสร้างฟอร์ม: ' + e.message;
  }
}

async function submitForm(){
  const form = document.getElementById('editForm');
  const payload = {};
  (DEF.columns||[]).forEach(c => {
    const elmt = form.querySelector(`[name="${c.name}"]`);
    if (!elmt) return;
    if (c.type==='bool') { payload[c.name] = (elmt.querySelector('input')||elmt).checked ? 1 : 0; }
    else payload[c.name] = (elmt.value ?? '').toString();
  });
  const method = CURRENT_ID ? 'PUT' : 'POST';
  const params = new URLSearchParams({entity:ENTITY});
  if (!CURRENT_ID) params.append('csrf', document.getElementById('csrf').value);
  const url = `api.php?${params.toString()}${CURRENT_ID?`&id=${CURRENT_ID}`:''}`;
  try{
    let res = await http(url, { method, headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
    const json = await res.json();
    if (json.status==='success') {
      bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
      fetchList(CUR_PAGE);
    } else {
      alert(json.message||'บันทึกไม่สำเร็จ');
    }
  }catch(e){
    alert('ส่งข้อมูลไม่สำเร็จ: '+e.message);
  }
}

function reloadList(){ fetchList(1); }
fetchList();
</script>
<?php include __DIR__ . '/layout/footer.php'; ?>