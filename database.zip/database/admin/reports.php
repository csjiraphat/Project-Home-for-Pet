<?php
// C:/xampp/htdocs/admin/reports.php - (ฉบับสมบูรณ์) ทำให้การอัปเดตสถานะสอดคล้องกัน และปรับปรุง Filter

// 1. นำเข้าไฟล์จำเป็น
require_once __DIR__ . '/db.php';
// require_login(); 

// -----------------------------------------------------------
// *** ฟังก์ชันสำหรับบันทึกการแจ้งเตือนลงในฐานข้อมูล ***
// -----------------------------------------------------------
function create_notification($db, $user_id, $type, $title, $message, $post_type = null, $post_id = null) {
  if (!$user_id) return;
  $post_type_val = $post_type; 
  $post_id_val = $post_id;     
  $stmt = $db->prepare("INSERT INTO user_notifications (user_id, type, title, message, related_post_type, related_post_id) VALUES (?, ?, ?, ?, ?, ?)");
  if (!$stmt) { error_log("Notification prepare failed: " . $db->error); return; }
  $stmt->bind_param('issssi', $user_id, $type, $title, $message, $post_type_val, $post_id_val);
  $stmt->execute();
  $stmt->close();
}
// -----------------------------------------------------------

// 2. กำหนดตัวแปรหลัก
$action = $_GET['action'] ?? 'list';
$report_id = isset($_REQUEST['report_id']) ? intval($_REQUEST['report_id']) : 0;

$token = $_REQUEST['_token'] ?? $_GET['_token'] ?? '';
$csrf_actions = ['update_status', 'hide_post'];
if (in_array($action, $csrf_actions) && function_exists('csrf_fail') && csrf_fail($token)) {
  die("โทเคนความปลอดภัย (CSRF) ไม่ถูกต้อง");
}

// ==========================================================
// *** NEW: ปรับปรุง action 'update_status' ให้ฉลาดขึ้น ***
// ==========================================================
if ($action === 'update_status') {
  $new_status = $_POST['status'] ?? '';
  $allowed_statuses = ['pending', 'reviewing', 'accepted', 'rejected', 'false_report', 'resolved'];

  if ($report_id && in_array($new_status, $allowed_statuses)) {
    // 1. ดึงข้อมูลรีพอร์ตเพื่อเอา post_id และ post_type มาใช้
    $report_info_stmt = $db->prepare("SELECT post_id, post_type FROM post_reports WHERE id = ?");
    $report_info_stmt->bind_param('i', $report_id);
    $report_info_stmt->execute();
    $report_info = $report_info_stmt->get_result()->fetch_assoc();
    $report_info_stmt->close();

    // 2. อัปเดตสถานะของรีพอร์ต (ทำเหมือนเดิม)
    $stmt = $db->prepare("UPDATE post_reports SET status = ? WHERE id = ?");
    $stmt->bind_param('si', $new_status, $report_id);
    $stmt->execute();
    $stmt->close();

    // 3. ตรวจสอบถ้าสถานะใหม่คือ 'false_report' หรือ 'rejected' ให้ยกเลิกการซ่อนโพสต์
    if ($report_info && ($new_status === 'false_report' || $new_status === 'rejected')) {
        $post_id = $report_info['post_id'];
        $post_type = $report_info['post_type'];
        $table_name = ($post_type === 'fh') ? 'fhome' : 'fpet';

        // 3.1 อัปเดตสถานะโพสต์กลับเป็น 'active'
        $unhide_stmt = $db->prepare("UPDATE $table_name SET status = 'active' WHERE id = ?");
        $unhide_stmt->bind_param('i', $post_id);
        $unhide_stmt->execute();
        $unhide_stmt->close();

        // 3.2 (ทางเลือก) แจ้งเตือนเจ้าของโพสต์ว่าโพสต์กลับมาใช้งานได้แล้ว
        $post_data_query = $db->query("SELECT title, user FROM $table_name WHERE id = $post_id");
        $post_info_data = $post_data_query ? $post_data_query->fetch_assoc() : null;
        if ($post_info_data) {
            $poster_username = $post_info_data['user'];
            $stmt_get_poster = $db->prepare("SELECT id FROM users WHERE username = ?");
            $stmt_get_poster->bind_param('s', $poster_username);
            $stmt_get_poster->execute();
            $poster_row = $stmt_get_poster->get_result()->fetch_assoc();
            $poster_id = $poster_row['id'] ?? null;
            $stmt_get_poster->close();
            
            if ($poster_id) {
                $post_title_safe = htmlspecialchars_decode($post_info_data['title']);
                $poster_msg = "ข่าวดี! โพสต์ของคุณเรื่อง **\"{$post_title_safe}\"** ได้รับการตรวจสอบอีกครั้งและกลับมาแสดงผลในระบบแล้ว";
                create_notification($db, $poster_id, 'post_restored', '✅ โพสต์ของคุณกลับมาใช้งานได้แล้ว', $poster_msg, $post_type, $post_id);
            }
        }
    }
  }
  header('Location: reports.php?action=list&status=status_updated');
  exit;
}

if ($action === 'hide_post') {
  $post_id = intval($_GET['post_id'] ?? 0);
  $post_type = $_GET['post_type'] ?? '';
  
  if ($post_id && ($post_type === 'fh' || $post_type === 'fp')) {
    $table_name = ($post_type === 'fh') ? 'fhome' : 'fpet';
    $post_data_query = $db->query("SELECT title, user FROM $table_name WHERE id = $post_id");
    $post_info = $post_data_query ? $post_data_query->fetch_assoc() : null;
    $post_title = $db->real_escape_string($post_info['title'] ?? '(โพสต์ที่ถูกดำเนินการไปแล้ว)');
    $poster_username = $post_info['user'] ?? '';
    if ($post_data_query) $post_data_query->close();
    
    $poster_id = null;
    if ($poster_username) {
        $stmt_get_poster = $db->prepare("SELECT id FROM users WHERE username = ?");
        $stmt_get_poster->bind_param('s', $poster_username);
        $stmt_get_poster->execute();
        $poster_row = $stmt_get_poster->get_result()->fetch_assoc();
        $poster_id = $poster_row['id'] ?? null;
        $stmt_get_poster->close();
    }

    $stmt_get_reporters = $db->prepare("SELECT DISTINCT reporter_id FROM post_reports WHERE post_type = ? AND post_id = ? AND status != 'resolved'");
    $stmt_get_reporters->bind_param('si', $post_type, $post_id);
    $stmt_get_reporters->execute();
    $reporters_res = $stmt_get_reporters->get_result();
    $reporters_ids = [];
    while($row = $reporters_res->fetch_assoc()) { $reporters_ids[] = $row['reporter_id']; }
    $stmt_get_reporters->close();

    $stmt_update = $db->prepare("UPDATE $table_name SET status = 'hidden' WHERE id = ?");
    $stmt_update->bind_param('i', $post_id);
    $stmt_update->execute();
    $stmt_update->close();
    
    $db->query("UPDATE post_reports SET status = 'resolved' WHERE post_type = '$post_type' AND post_id = $post_id");

    if ($poster_id) {
        $poster_title_safe = htmlspecialchars_decode($post_title);
        $poster_msg = "โพสต์ของคุณเรื่อง **\"{$poster_title_safe}\"** ถูกระงับการใช้งานจากระบบเนื่องจากละเมิดกฎ";
        create_notification($db, $poster_id, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกระงับ', $poster_msg, $post_type, $post_id);
    }
    foreach ($reporters_ids as $reporter_id) {
        $reporter_title_safe = htmlspecialchars_decode($post_title);
        $reporter_title = "✅ รีพอร์ตของคุณถูกดำเนินการแล้ว";
        $reporter_msg = "ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"{$reporter_title_safe}\"** ได้รับการตรวจสอบและถูกดำเนินการ (ระงับการใช้งาน) เรียบร้อยแล้ว";
        create_notification($db, $reporter_id, 'report_resolution_reporter', $reporter_title, $reporter_msg, $post_type, $post_id);
    }
  }
  header('Location: reports.php?action=list&status=post_hidden');
  exit;
}
// *** สิ้นสุดส่วนประมวลผล Action ***


// =========================================================================
// 4. VIEW RENDERING
// =========================================================================
require_once __DIR__ . '/layout/header.php';

require_once __DIR__ . '/nav.inc.php';

$alert_class = ''; $alert_msg = '';
if (isset($_GET['status'])) {
  switch ($_GET['status']) {
    case 'status_updated': $alert_class = 'success'; $alert_msg = '✅ อัปเดตสถานะรีพอร์ตสำเร็จแล้ว'; break;
    case 'post_hidden': $alert_class = 'success'; $alert_msg = '✅ ซ่อนโพสต์และแก้ไขรีพอร์ตที่เกี่ยวข้องเรียบร้อยแล้ว'; break;
  }
}
if ($alert_msg) { echo '<div class="alert alert-' . $alert_class . '">' . $alert_msg . '</div>'; }

// แผนที่สถานะทั้งหมด
$status_map = [
    'pending' => ['th' => 'รอตรวจสอบ', 'class' => 'bg-warning text-dark', 'hint' => 'เพิ่งถูกส่งเข้ามารอการตรวจสอบ'],
    'reviewing' => ['th' => 'กำลังตรวจสอบ', 'class' => 'bg-info', 'hint' => 'อยู่ระหว่างการตรวจสอบของแอดมิน'],
    'accepted' => ['th' => 'ยอมรับ', 'class' => 'bg-danger', 'hint' => 'รีพอร์ตได้รับการยอมรับและรอการดำเนินการ'],
    'rejected' => ['th' => 'ปฏิเสธ', 'class' => 'bg-light text-dark', 'hint' => 'รีพอร์ตถูกปฏิเสธเนื่องจากข้อมูลไม่เพียงพอ'],
    'resolved' => ['th' => 'ดำเนินการแล้ว', 'class' => 'bg-success', 'hint' => 'ดำเนินการตามรีพอร์ตเรียบร้อยแล้ว'],
    'false_report' => ['th' => 'รีพอร์ตเท็จ', 'class' => 'bg-secondary', 'hint' => 'รีพอร์ตถูกปฏิเสธอย่างชัดเจน'],
];

// สถานะสำหรับ Dropdown 'จัดการสถานะ' (Action)
$manage_statuses = [
    'pending' => $status_map['pending'],
    'false_report' => $status_map['false_report'],
    'resolved' => $status_map['resolved'], 
];

// *** NEW: สถานะสำหรับ Dropdown 'กรองสถานะ' (Filter) ***
$filter_status_map = [
    'pending' => $status_map['pending'],
    'resolved' => $status_map['resolved'],
    'false_report' => $status_map['false_report'],
];

function getStatusBadgeClass($status, $map) { return $map[$status]['class'] ?? 'bg-light text-dark'; }
function translateStatus($status, $map) { return $map[$status]['th'] ?? $status; }


switch ($action) {
  case 'list':
    $limit = 20; $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1; $offset = ($page - 1) * $limit;
    
    $filter_status = $_GET['status_filter'] ?? '';
    $filter_type = $_GET['type_filter'] ?? '';
    $start_date = $_GET['start_date'] ?? ''; 
    $end_date = $_GET['end_date'] ?? ''; 
    
    $whereParts = [];
    if ($filter_status) { $whereParts[] = "pr.status = '" . $db->real_escape_string($filter_status) . "'"; }
    if ($filter_type) { $whereParts[] = "pr.post_type = '" . $db->real_escape_string($filter_type) . "'"; }
    if ($start_date) { $whereParts[] = "pr.created_at >= '" . $db->real_escape_string($start_date) . " 00:00:00'"; }
    if ($end_date) { $whereParts[] = "pr.created_at <= '" . $db->real_escape_string($end_date) . " 23:59:59'"; }
    
    $where_sql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';
    $sql = "
      SELECT pr.id, pr.post_type, pr.post_id, pr.status, pr.created_at, pa.title AS post_title,
             u.username AS reporter_username, rr.name_th AS reason_text
      FROM post_reports pr
      LEFT JOIN posts_all pa ON pr.post_type = pa.post_type AND pr.post_id = pa.post_id
      LEFT JOIN users u ON pr.reporter_id = u.id
      LEFT JOIN report_reasons rr ON pr.reason_id = rr.reason_id
      $where_sql ORDER BY pr.created_at DESC LIMIT " . intval($offset) . ", " . intval($limit);
    $res = $db->query($sql);
    if ($res === false) { echo '<div class="card p-3"><p>Query error: ' . htmlspecialchars($db->error) . '</p></div>'; break; }

?>
    <div class="card p-3 shadow-sm">
      <h1 class="h3 mb-4">รายการรีพอร์ตทั้งหมด</h1>
      
      <form method="get" class="d-flex flex-wrap align-items-end gap-3 p-3 border rounded mb-4 bg-light">
        <input type="hidden" name="action" value="list">
        
        <div class="col-auto">
          <label class="form-label small text-muted mb-0">สถานะรีพอร์ต</label>
          <select name="status_filter" class="form-select form-select-sm" style="width: 150px;">
            <option value="">— ทั้งหมด —</option>
            <?php foreach($filter_status_map as $key => $val): ?>
                <option value="<?= $key ?>" <?= ($filter_status === $key) ? 'selected' : '' ?>><?= $val['th'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-auto">
          <label class="form-label small text-muted mb-0">ประเภทโพสต์</label>
          <select name="type_filter" class="form-select form-select-sm" style="width: 150px;">
            <option value="">— ทั้งหมด —</option>
            <option value="fh" <?= ($filter_type === 'fh') ? 'selected' : '' ?>>หาบ้าน (FH)</option>
            <option value="fp" <?= ($filter_type === 'fp') ? 'selected' : '' ?>>หาสัตว์เลี้ยง (FP)</option>
          </select>
        </div>
        
        <div class="col-auto">
          <label class="form-label small text-muted mb-0">วันที่รีพอร์ต (เริ่มต้น)</label>
          <input type="date" name="start_date" value="<?= htmlspecialchars($start_date) ?>" class="form-control form-control-sm">
        </div>
        <div class="col-auto">
          <label class="form-label small text-muted mb-0">ถึงวันที่ (สิ้นสุด)</label>
          <input type="date" name="end_date" value="<?= htmlspecialchars($end_date) ?>" class="form-control form-control-sm">
        </div>
        
        <div class="col-auto d-flex gap-2">
            <button class="btn btn-sm btn-dark" type="submit"><i class="bi bi-funnel"></i> กรอง</button>
            <a class="btn btn-sm btn-outline-secondary" href="reports.php?action=list"><i class="bi bi-x"></i> ล้างค่า</a>
        </div>
      </form>
      <div class="table-responsive">
        <table class="table table-striped table-hover align-middle">
          <thead style="background-color: #E9ECEF; color: black !important; border-bottom: 2px solid #dee2e6;">
            <tr>
              <th style="width: 25%;">โพสต์ที่ถูกรีพอร์ต</th>
              <th style="width: 20%;">เหตุผล</th>
              <th style="width: 10%;">ผู้รีพอร์ต</th>
              <th style="width: 15%;">วันที่รีพอร์ต</th>
              <th style="width: 15%;">สถานะ</th>
              <th style="width: 15%;">จัดการ</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($res->num_rows): while ($row = $res->fetch_assoc()): ?>
                <?php 
                    $report_date = date('m/d/Y', strtotime($row['created_at']));
                    $current_status = $row['status'];
                    $has_status_info = isset($status_map[$current_status]);
                ?>
                <tr>
                  <td>
                    <a href="javascript:void(0);" onclick="showPostDetails('<?= htmlspecialchars($row['post_type']) ?>', <?= intval($row['post_id']) ?>)">
                      <?= htmlspecialchars($row['post_title'] ?? ' (โพสต์ถูกซ่อน/ลบไปแล้ว)') ?>
                    </a>
                  </td>
                  <td><?= htmlspecialchars($row['reason_text'] ?? 'ไม่ระบุ') ?></td>
                  <td><?= htmlspecialchars($row['reporter_username'] ?? 'N/A') ?></td>
                  <td><?= $report_date ?></td>
                  <td>
                    <span class="badge <?= getStatusBadgeClass($current_status, $status_map) ?>" data-bs-toggle="tooltip" title="<?= $has_status_info ? $status_map[$current_status]['hint'] : $current_status ?>">
                      <?= translateStatus($current_status, $status_map) ?>
                      <?php if ($has_status_info): ?><i class="bi bi-info-circle small ms-1"></i><?php endif; ?>
                    </span>
                  </td>
                  <td>
                    <div class="d-flex flex-column gap-1">
                      <form action="reports.php?action=update_status" method="post" class="d-flex gap-1 align-items-center">
                        <input type="hidden" name="report_id" value="<?= intval($row['id']) ?>">
                        <input type="hidden" name="_token" value="<?= function_exists('csrf_token') ? csrf_token() : '' ?>">
                        <select name="status" class="form-select form-select-sm" style="flex-grow: 1; min-width: 120px; font-size: 0.8rem; height: 30px;">
                          <?php foreach($manage_statuses as $key => $val): ?>
                              <option value="<?= $key ?>" <?= $row['status'] == $key ? 'selected' : '' ?> title="<?= $val['hint'] ?>"><?= $val['th'] ?></option>
                          <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-sm btn-info text-white" title="อัปเดตสถานะ" style="width: 30px; height: 30px; padding: 5px;"><i class="bi bi-arrow-clockwise"></i></button>
                      </form>
                      <?php if($row['post_title'] !== null): ?>
                      <a href="reports.php?action=hide_post&report_id=<?= intval($row['id']) ?>&post_id=<?= intval($row['post_id']) ?>&post_type=<?= htmlspecialchars($row['post_type']) ?>&_token=<?= function_exists('csrf_token') ? csrf_token() : '' ?>" 
                        onclick="return confirm('คุณต้องการซ่อนโพสต์นี้ใช่หรือไม่? การกระทำนี้จะเปลี่ยนสถานะรีพอร์ตทั้งหมดที่เกี่ยวกับโพสต์นี้เป็น Resolved ด้วย')"
                        class="btn btn-sm btn-danger w-100" title="ซ่อนโพสต์" style="font-size: 0.8rem;">
                        <i class="bi bi-eye-slash"></i> ซ่อนโพสต์
                      </a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
            <?php endwhile; else: ?>
              <tr><td colspan="6" class="text-center text-muted">ไม่พบข้อมูลรีพอร์ต</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      
      <?php // Pagination
        $total_res_query = $db->query("SELECT COUNT(*) FROM post_reports pr $where_sql");
        if ($total_res_query) {
            $total_rows = $total_res_query->fetch_row()[0];
            $total_pages = ceil($total_rows / $limit);
            $total_res_query->close();
        } else { $total_rows = 0; $total_pages = 0; }
        if ($total_pages > 1):
      ?>
          <nav><ul class="pagination justify-content-end mt-3">
              <?php for ($i = 1; $i <= $total_pages; $i++):
                $page_link = "reports.php?action=list&page=$i&status_filter=".urlencode($filter_status)."&type_filter=".urlencode($filter_type)."&start_date=".urlencode($start_date)."&end_date=".urlencode($end_date);
              ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>"><a class="page-link" href="<?= htmlspecialchars($page_link) ?>"><?= $i ?></a></li>
              <?php endfor; ?>
          </ul></nav>
      <?php endif; ?>
    </div>
<?php
    break;
  default:
    header('Location: reports.php?action=list');
    exit;
}
?>

<div class="modal fade" id="postDetailModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">รายละเอียดโพสต์</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body"><div id="modal-content-area"><p class="text-center">กำลังโหลดข้อมูล...</p></div></div>
      <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ปิด</button></div>
    </div>
  </div>
</div>

<?php require_once __DIR__ . '/layout/footer.php'; ?>

<script>
const postDetailModal = new bootstrap.Modal(document.getElementById('postDetailModal'));
async function showPostDetails(type, id) {
  const modalContent = document.getElementById('modal-content-area');
  modalContent.innerHTML = '<p class="text-center">กำลังโหลดข้อมูล...</p>';
  postDetailModal.show();
  try {
    const response = await fetch(`api_get_post_details.php?type=${type}&id=${id}`);
    const data = await response.json();
    if (data.error) { modalContent.innerHTML = `<p class="text-center text-danger">เกิดข้อผิดพลาด: ${data.error}</p>`; return; }
    let html = `<h4>${data.title}</h4><p><strong>โดย:</strong> ${data.user}</p><hr>`;
    if (type === 'fh') {
      html += `<div class="row"><div class="col-md-6"><p><strong>ประเภท:</strong> ${data.type}</p><p><strong>สายพันธุ์:</strong> ${data.breed}</p><p><strong>เพศ:</strong> ${data.sex}</p><p><strong>อายุ:</strong> ${data.age}</p><p><strong>สี:</strong> ${data.color}</p><p><strong>ทำหมัน:</strong> ${data.steriliz}</p></div><div class="col-md-6"><p><strong>วัคซีน:</strong> ${data.vaccine}</p><p><strong>นิสัย:</strong> ${data.personality}</p><p><strong>เหตุผลหาบ้าน:</strong> ${data.reason}</p><p><strong>เงื่อนไข:</strong> ${data.adoptionTerms}</p></div></div>`;
      if (data.image_urls && data.image_urls.length > 0) {
        html += '<hr><p><strong>รูปภาพ:</strong></p>';
        data.image_urls.forEach(url => { html += `<img src="${url}" class="img-fluid rounded mb-2" style="max-height: 250px;"> `; });
      }
    } else {
       html += `<div class="row"><div class="col-md-6"><p><strong>ประเภท:</strong> ${data.type}</p><p><strong>สายพันธุ์:</strong> ${data.breed}</p><p><strong>เพศ:</strong> ${data.sex}</p><p><strong>ช่วงอายุ:</strong> ${data.min_age} - ${data.max_age}</p></div><div class="col-md-6"><p><strong>สีที่มองหา:</strong> ${data.color}</p><p><strong>ทำหมัน:</strong> ${data.steriliz}</p><p><strong>วัคซีนที่ต้องการ:</strong> ${data.vaccine}</p><p><strong>สภาพแวดล้อม:</strong> ${data.environment}</p></div></div>`;
    }
    modalContent.innerHTML = html;
  } catch (error) {
    modalContent.innerHTML = `<p class="text-center text-danger">ไม่สามารถโหลดข้อมูลได้</p>`;
    console.error('Fetch error:', error);
  }
}
document.addEventListener('DOMContentLoaded', function () {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) { return new bootstrap.Tooltip(tooltipTriggerEl); });
});
</script>