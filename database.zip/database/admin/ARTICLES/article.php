<?php
// C:\xampp\htdocs\admin\article.php - ระบบจัดการบทความแบบรวมไฟล์ (แก้ไขปัญหาทั้งหมด)

// 1. นำเข้าไฟล์จำเป็น
require_once __DIR__ . '/db.php';
// require_login(); 

// 2. กำหนดตัวแปรหลัก
$action = $_GET['action'] ?? 'list';
$id = isset($_REQUEST['id']) ? intval($_REQUEST['id']) : 0;
$article_id = isset($_REQUEST['article_id']) ? intval($_REQUEST['article_id']) : 0;
$status_msg = ''; // สำหรับเก็บข้อความแจ้งเตือน

// ตรวจสอบ CSRF token สำหรับ action ที่เปลี่ยนแปลงข้อมูล
$token = $_REQUEST['_token'] ?? $_GET['_token'] ?? '';
$csrf_actions = ['save', 'delete', 'delete_image'];
if (in_array($action, $csrf_actions) && csrf_fail($token)) {
  die("CSRF Token ไม่ถูกต้อง");
}

// =========================================================================
// 3. PROCESS ACTIONS (ต้องทำก่อนการแสดงผลใดๆ เพื่อให้ header() ทำงานได้)
// =========================================================================

if ($action === 'save') {
  // --- Action: Save (บันทึกข้อมูล) ---
  // ... (ส่วนการรับค่า POST เหมือนเดิม)
  $species = $_POST['species'] ?? 'dog';
  $title = $_POST['title'] ?? '';
  $tags = $_POST['tags'] ?? '';
  $published_at = $_POST['published_at'] ?? date('Y-m-d');
  $content = $_POST['content'] ?? '';
  $is_active = isset($_POST['is_active']) ? 1 : 0;
  $now = date('Y-m-d H:i:s');

  $new_id = $id; // ใช้ ID เดิมถ้าเป็นการแก้ไข

  if ($id) {
    $stmt = $db->prepare("UPDATE articles SET species=?, title=?, tags=?, content=?, published_at=?, is_active=?, updated_at=? WHERE id=?");
    $stmt->bind_param('sssssisi', $species, $title, $tags, $content, $published_at, $is_active, $now, $id);
    $stmt->execute();
    $stmt->close();
  } else {
    // *** สำหรับการสร้างใหม่: ต้องดึง ID ที่ถูกสร้างขึ้นมาใหม่ ***
    $stmt = $db->prepare("INSERT INTO articles (species, title, tags, content, published_at, is_active, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->bind_param('sssssisi', $species, $title, $tags, $content, $published_at, $is_active, $now, $now);
    $stmt->execute();
    $new_id = $db->insert_id; // ดึง ID ใหม่
    $stmt->close();
  }

  // *** เปลี่ยนการ Redirect: ไปหน้าจัดการรูปภาพโดยตรงหากเป็นบทความใหม่ (หรือแก้ไข) ***
  // (หากคุณต้องการกลับไปหน้ารายการเสมอ ให้เปลี่ยนเป็น 'Location: article.php?action=list')
  header('Location: article.php?action=list' . '&status=update_saved');
  exit;
}

if ($action === 'delete') {
  // --- Action: Delete (ลบข้อมูล) ---
  if ($id) {
    // (โค้ดลบไฟล์จริงควรทำเพิ่มเองตามความเหมาะสม)
    $db->query("DELETE FROM article_images WHERE article_id = " . intval($id));
    $db->query("DELETE FROM articles WHERE id = " . intval($id));
  }
  header('Location: article.php?action=list&status=deleted');
  exit;
}

if ($action === 'images' && $article_id) {
  // --- Action: Images (จัดการรูปภาพ - POST/DELETE) ---

  // 3a. การอัปโหลดรูปภาพใหม่
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image']) && !isset($_POST['update_image_id'])) {
    $post_token = $_POST['_token'] ?? '';
    if (csrf_fail($post_token)) {
      header('Location: article.php?action=images&article_id=' . $article_id . '&status=csrf_fail');
      exit;
    }

    $up = $_FILES['image'];
    if ($up['error'] === UPLOAD_ERR_OK) {
      $ext = pathinfo($up['name'], PATHINFO_EXTENSION);
      $filename_only = 'article_' . time() . '_' . mt_rand(1000, 9999) . '.' . preg_replace('/[^a-z0-9]/i', '', $ext);

      $upload_dir = __DIR__ . '/uploads';
      if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

      $destination = $upload_dir . '/' . $filename_only;

      if (move_uploaded_file($up['tmp_name'], $destination)) {
        $pos = $_POST['position'] ?? 'inline';
        $caption = $_POST['caption'] ?? null;
        $sort = intval($_POST['sort_order'] ?? 0);
        $db_url = 'uploads/' . $filename_only;

        $stmt = $db->prepare("INSERT INTO article_images (article_id, url, position, sort_order, caption) VALUES (?,?,?,?,?)");
        $stmt->bind_param('isssi', $article_id, $db_url, $pos, $sort, $caption);
        $stmt->execute();
        $stmt->close();
        header('Location: article.php?action=images&article_id=' . $article_id . '&status=uploaded');
        exit;
      }
    }
    header('Location: article.php?action=images&article_id=' . $article_id . '&status=upload_fail');
    exit;
  }

  // 3b. การแก้ไขรูปภาพที่มีอยู่ (Update)
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_image_id'])) {
    $image_id = intval($_POST['update_image_id']);
    $pos = $_POST['position'] ?? 'inline';
    $caption = $_POST['caption'] ?? null;
    $sort = intval($_POST['sort_order'] ?? 0);
    $new_url = null;
    $status = 'updated_meta';

    if ($image_id > 0) {

      // 1. ดึง URL ไฟล์เก่าเพื่อเตรียมลบ (ทำก่อน UPDATE DB)
      $stmt_old = $db->prepare("SELECT url FROM article_images WHERE id = ?");
      $stmt_old->bind_param('i', $image_id);
      $stmt_old->execute();
      $old_url_res = $stmt_old->get_result();
      $old_url_row = $old_url_res->fetch_assoc();
      $old_url = $old_url_row ? $old_url_row['url'] : null;
      $stmt_old->close();

      // 2. ตรวจสอบว่ามีการอัปโหลดไฟล์รูปภาพใหม่หรือไม่
      if (isset($_FILES['new_image']) && $_FILES['new_image']['error'] === UPLOAD_ERR_OK) {
        $up = $_FILES['new_image'];
        $ext = pathinfo($up['name'], PATHINFO_EXTENSION);
        $filename_only = 'article_' . time() . '_' . mt_rand(1000, 9999) . '.' . preg_replace('/[^a-z0-9]/i', '', $ext);
        $upload_dir = __DIR__ . '/uploads';
        $destination = $upload_dir . '/' . $filename_only;

        if (move_uploaded_file($up['tmp_name'], $destination)) {
          $new_url = 'uploads/' . $filename_only;
          $status = 'updated_file';

          // **สำคัญ:** ลบไฟล์เก่าออกจาก Server
          $file_to_delete = __DIR__ . '/' . $old_url;
          if ($old_url && file_exists($file_to_delete)) {
            unlink($file_to_delete);
          }
        }
      }

      // 3. เตรียมคำสั่ง UPDATE SQL
      if ($new_url) {
        // ถ้ามี URL ใหม่ (มีการเปลี่ยนรูปภาพ)
        $stmt = $db->prepare("UPDATE article_images SET url=?, position=?, sort_order=?, caption=? WHERE id=? AND article_id=?");
        $stmt->bind_param('sssisi', $new_url, $pos, $sort, $caption, $image_id, $article_id);
      } else {
        // ถ้าไม่มี URL ใหม่ (เปลี่ยนแค่ metadata)
        $stmt = $db->prepare("UPDATE article_images SET position=?, sort_order=?, caption=? WHERE id=? AND article_id=?");
        $stmt->bind_param('ssisi', $pos, $sort, $caption, $image_id, $article_id);
      }

      $stmt->execute();
      $stmt->close();
    }

    header('Location: article.php?action=images&article_id=' . $article_id . '&status=' . $status);
    exit;
  }

  // 3c. การลบรูปภาพ
  if (isset($_GET['delete_image'])) {
    $image_id = intval($_GET['delete_image']);
    // ดึง URL ไฟล์เก่าเพื่อเตรียมลบ
    $stmt_old = $db->prepare("SELECT url FROM article_images WHERE id = ?");
    $stmt_old->bind_param('i', $image_id);
    $stmt_old->execute();
    $old_url_res = $stmt_old->get_result();
    $old_url_row = $old_url_res->fetch_assoc();
    $old_url = $old_url_row ? $old_url_row['url'] : null;
    $stmt_old->close();

    // ลบจากฐานข้อมูล
    $db->query("DELETE FROM article_images WHERE id = " . intval($image_id) . " AND article_id = " . intval($article_id));

    // ลบไฟล์จริงออกจาก server
    $file_to_delete = __DIR__ . '/' . $old_url;
    if ($old_url && file_exists($file_to_delete)) {
      unlink($file_to_delete);
    }

    header('Location: article.php?action=images&article_id=' . $article_id . '&status=deleted_image');
    exit;
  }
}


// =========================================================================
// 4. VIEW RENDERING (นำเข้า Header/Nav)
// =========================================================================

require_once __DIR__ . '/layout/header.php';
require_once __DIR__ . '/nav.inc.php';

// ตรวจสอบสถานะและกำหนดข้อความแจ้งเตือน
$alert_class = '';
$alert_msg = '';
if (isset($_GET['status'])) {
  switch ($_GET['status']) {
    case 'uploaded':
      $alert_class = 'success';
      $alert_msg = '✅ อัปโหลดรูปภาพใหม่สำเร็จแล้ว!';
      break;
    case 'deleted_image':
      $alert_class = 'success';
      $alert_msg = '✅ ลบรูปภาพสำเร็จแล้ว!';
      break;
    case 'updated_file':
      $alert_class = 'success';
      $alert_msg = '✅ บันทึกรูปภาพใหม่สำเร็จแล้ว! (ไฟล์เก่าถูกลบออกแล้ว)';
      break;
    case 'updated_meta':
      $alert_class = 'warning';
      $alert_msg = '⚠️ บันทึกข้อมูลตำแหน่ง/คำบรรยายสำเร็จแล้ว (ไม่ได้เปลี่ยนไฟล์รูปภาพ)';
      break;
    case 'upload_fail':
      $alert_class = 'danger';
      $alert_msg = '❌ การอัปโหลดไฟล์ล้มเหลว กรุณาลองใหม่อีกครั้ง';
      break;
    case 'saved':
      $alert_class = 'success';
      $alert_msg = '✅ บันทึกบทความสำเร็จ กรุณาอัปโหลดรูปภาพ';
      break;
    case 'update_saved':
      $alert_class = 'success';
      $alert_msg = '✅ บันทึกบทความสำเร็จ';
      break;
  }
}
if ($alert_msg) {
  echo '<div class="container-stretch"><div class="alert alert-' . $alert_class . '">' . $alert_msg . '</div></div>';
}


switch ($action) {
  case 'list':
    // --- View: List (รายการบทความ) ---

    $limit = 20;
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $offset = ($page - 1) * $limit;

    $species = $_GET['species'] ?? '';
    $active = $_GET['active'] ?? '';

    $whereParts = [];
    if ($species !== '') {
      $whereParts[] = "species = '" . $db->real_escape_string($species) . "'";
    }
    if ($active !== '') {
      $whereParts[] = "is_active = " . intval($active);
    }
    $where_sql = $whereParts ? ('WHERE ' . implode(' AND ', $whereParts)) : '';

    $sql = "SELECT * FROM articles $where_sql ORDER BY published_at DESC, created_at DESC LIMIT " . intval($offset) . ", " . intval($limit);
    $res = $db->query($sql);
    if ($res === false) {
      echo '<div class="container-stretch"><p>Query error: ' . htmlspecialchars($db->error) . '</p></div>';
      break;
    }
?>
    <div class="container-stretch">
      <div class="card p-3">
        <h1>จัดการบทความ</h1>

        <form method="get" style="margin-bottom:12px;" class="d-flex gap-2 align-items-center">
          <input type="hidden" name="action" value="list">
          <label class="mb-0">Species
            <select name="species" class="form-control form-control-sm" style="width: auto; display: inline-block;">
              <option value="">-- ทั้งหมด --</option>
              <option value="dog" <?= ($species === 'dog') ? 'selected' : '' ?>>หมา</option>
              <option value="cat" <?= ($species === 'cat') ? 'selected' : '' ?>>แมว</option>
            </select>
          </label>
          <label class="mb-0">Active
            <select name="active" class="form-control form-control-sm" style="width: auto; display: inline-block;">
              <option value="">-- ทั้งหมด --</option>
              <option value="1" <?= ($active === '1') ? 'selected' : '' ?>>Active</option>
              <option value="0" <?= ($active === '0') ? 'selected' : '' ?>>Inactive</option>
            </select>
          </label>
          <button class="btn btn-sm btn-secondary" type="submit">กรอง</button>
          <a class="btn btn-sm btn-outline-secondary" href="article.php?action=list">ล้าง</a>
        </form>

        <p><a class="btn btn-primary" href="article.php?action=form">สร้างบทความใหม่</a></p>

        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>Species</th>
                <th>Title</th>
                <th>Tags</th>
                <th>Published At</th>
                <th>Active</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($res->num_rows): ?>
                <?php while ($row = $res->fetch_assoc()): ?>
                  <tr>
                    <td><?= htmlspecialchars($row['id']) ?></td>
                    <td><?= htmlspecialchars($row['species']) ?></td>
                    <td><?= htmlspecialchars($row['title']) ?></td>
                    <td><?= htmlspecialchars($row['tags']) ?></td>
                    <td><?= htmlspecialchars($row['published_at']) ?></td>
                    <td><?= $row['is_active'] ? '✅ Yes' : '❌ No' ?></td>
                    <td>
                      <a href="article.php?action=form&id=<?= intval($row['id']) ?>" class="btn btn-sm btn-info">แก้ไข</a>
                      <a href="article.php?action=delete&id=<?= intval($row['id']) ?>&_token=<?= csrf_token() ?>" onclick="return confirm('ลบบทความนี้หรือไม่? การกระทำนี้ไม่สามารถยกเลิกได้')" class="btn btn-sm btn-danger">ลบ</a>
                      <a href="article.php?action=images&article_id=<?= intval($row['id']) ?>" class="btn btn-sm btn-warning">รูปภาพ</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="7" class="text-center text-muted">ไม่พบข้อมูลบทความ</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <?php
        // Pagination logic
        $total_res = $db->query("SELECT COUNT(*) FROM articles $where_sql");
        $total_rows = $total_res->fetch_row()[0];
        $total_pages = ceil($total_rows / $limit);
        $total_res->close();

        if ($total_pages > 1):
        ?>
          <nav>
            <ul class="pagination justify-content-end">
              <?php for ($i = 1; $i <= $total_pages; $i++):
                $page_link = "article.php?action=list&page=$i";
                if ($species) $page_link .= '&species=' . urlencode($species);
                if ($active !== '') $page_link .= '&active=' . urlencode($active);
              ?>
                <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                  <a class="page-link" href="<?= htmlspecialchars($page_link) ?>"><?= $i ?></a>
                </li>
              <?php endfor; ?>
            </ul>
          </nav>
        <?php endif; ?>

      </div>
    </div>
  <?php
    break;

  case 'form':
    // --- View: Form (เพิ่ม/แก้ไขบทความ) ---

    $article = ['id' => 0, 'species' => 'dog', 'title' => '', 'content' => '', 'tags' => '', 'published_at' => date('Y-m-d'), 'is_active' => 1];
    $images = [];

    if ($id) {
      $stmt = $db->prepare("SELECT * FROM articles WHERE id = ?");
      $stmt->bind_param('i', $id);
      $stmt->execute();
      $res = $stmt->get_result();
      if ($row = $res->fetch_assoc()) $article = $row;
      $stmt->close();

      // ดึงรายการรูปภาพที่อัปโหลดแล้วสำหรับบทความนี้
      $img_res = $db->query("SELECT * FROM article_images WHERE article_id = $id ORDER BY sort_order ASC, id ASC");
      if ($img_res) $images = $img_res->fetch_all(MYSQLI_ASSOC);
    }
  ?>
    <div class="container-stretch">
      <div class="card p-4">
        <h1><?php echo $id ? 'แก้ไขบทความ' : 'สร้างบทความใหม่'; ?></h1>
        <form action="article.php?action=save" method="post">
          <input type="hidden" name="id" value="<?= intval($article['id']) ?>">
          <input type="hidden" name="_token" value="<?= csrf_token() ?>">

          <div class="mb-3">
            <label class="form-label">Species</label>
            <select name="species" class="form-select">
              <option value="dog" <?= ($article['species'] == 'dog') ? 'selected' : '' ?>>หมา</option>
              <option value="cat" <?= ($article['species'] == 'cat') ? 'selected' : '' ?>>แมว</option>
            </select>
          </div>
          <div class="mb-3">
            <label class="form-label">Title</label>
            <input class="form-control" name="title" value="<?= htmlspecialchars($article['title']) ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Tags (คั่นด้วย comma)</label>
            <input class="form-control" name="tags" value="<?= htmlspecialchars($article['tags']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Published at</label>
            <input class="form-control" type="date" name="published_at" value="<?= htmlspecialchars($article['published_at']) ?>">
          </div>
          <div class="mb-3">
            <label class="form-label">Content</label>
            <textarea class="form-control" name="content" rows="12" id="article_content"><?= htmlspecialchars($article['content']) ?></textarea>
          </div>

          <?php if ($id && !empty($images)): ?>
            <div class="mb-4 p-3 border rounded">
              <h5>รูปภาพสำหรับแทรกในเนื้อหา:</h5>
              <p class="text-muted small">
                คัดลอกโค้ด &lt;img ... /&gt; ด้านล่างไปวางในช่อง Content เพื่อแทรกรูปภาพ ณ ตำแหน่งที่ต้องการ
                <br>
                <strong>✨ เคล็ดลับ:</strong> คุณสามารถแก้ไขส่วน <code>style="..."</code> ที่อยู่ในโค้ดได้เองเพื่อปรับขนาดและการแสดงผล เช่น:
              <ul>
                <li>เปลี่ยน <code>max-width: 100%;</code> เป็น <code>width: 300px;</code> เพื่อกำหนดความกว้างคงที่</li>
                <li>เพิ่ม <code>float: left; margin-right: 15px;</code> เพื่อให้รูปภาพลอยชิดซ้ายและมีข้อความล้อมรอบ</li>
                <li>เพิ่ม <code>border-radius: 10px;</code> เพื่อทำให้ขอบรูปภาพมนขึ้น</li>
              </ul>
              </p>
              <?php foreach ($images as $img): ?>
                <div class="d-flex align-items-center mb-2 p-2 border rounded bg-light">
                  <img src="/admin/<?= htmlspecialchars($img['url']) ?>" style="max-height: 40px; margin-right: 15px;">
                  <span class="text-muted me-3">ID: <?= intval($img['id']) ?></span>
                  <code style="flex-grow: 1; user-select: all;">
                    &lt;img src="/admin/<?= htmlspecialchars($img['url']) ?>" alt="<?= htmlspecialchars($img['caption'] ?? '') ?>" style="max-width: 100%; height: auto;"&gt;
                  </code>
                  <a href="article.php?action=images&article_id=<?= intval($id) ?>" class="btn btn-sm btn-link text-warning ms-3">จัดการรูป</a>
                </div>
              <?php endforeach; ?>
            </div>
          <?php elseif ($id): ?>
            <div class="mb-4 p-3 border rounded bg-light text-center">
              <p class="mb-0 text-muted">บทความนี้ถูกบันทึกแล้ว: ยังไม่มีรูปภาพ</p>
              <a href="article.php?action=images&article_id=<?= intval($id) ?>" class="btn btn-sm btn-warning mt-2">อัปโหลดรูปภาพ</a>
            </div>
          <?php endif; ?>
          <div class="mb-3 form-check">
            <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active_check" <?= $article['is_active'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="is_active_check"> Active</label>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-success" type="submit">บันทึก</button>
            <a class="btn btn-secondary" href="article.php?action=list">ยกเลิก</a>
          </div>
        </form>
      </div>
    </div>
  <?php
    break;

  case 'images':
    // --- View: Images (จัดการรูปภาพ - GET view) ---
    if (!$article_id) {
      echo '<div class="container-stretch"><div class="card p-3"><p>article_id ไม่ถูกต้อง</p></div></div>';
      break;
    }

    // +++ START: โค้ดที่เพิ่มเข้ามาเพื่อดึงชื่อบทความ +++
    $article_title = 'ID: ' . intval($article_id); // ค่าเริ่มต้น
    $stmt_title = $db->prepare("SELECT title FROM articles WHERE id = ?");
    $stmt_title->bind_param('i', $article_id);
    if ($stmt_title->execute()) {
      $res_title = $stmt_title->get_result();
      if ($row_title = $res_title->fetch_assoc()) {
        $article_title = $row_title['title'];
      }
    }
    $stmt_title->close();
    // +++ END: โค้ดที่เพิ่มเข้ามา +++

    $sql = "SELECT * FROM article_images WHERE article_id = " . intval($article_id) . " ORDER BY sort_order ASC, id ASC";
    $res = $db->query($sql);
  ?>
    <div class="container-stretch">
      <div class="card p-4">
        <h1>จัดการรูปภาพ: <?= htmlspecialchars($article_title) ?></h1>
        <p><a href="article.php?action=form&id=<?= intval($article_id) ?>" class="btn btn-sm btn-secondary">← กลับไปหน้าแก้ไขบทความ</a></p>

        <h3 class="mt-4">อัปโหลดรูปภาพ</h3>
        <form method="post" enctype="multipart/form-data" class="row g-3" action="article.php?action=images&article_id=<?= intval($article_id) ?>">
          <input type="hidden" name="_token" value="<?= csrf_token() ?>">

          <div class="col-md-3">
            <label class="form-label">ไฟล์รูป</label>
            <input type="file" name="image" class="form-control" required>
          </div>
          <div class="col-md-3">
            <label class="form-label">Position (ตำแหน่ง)</label>
            <select name="position" class="form-select">
              <option value="top">Top (บนสุด)</option>
              <option value="inline" selected>Inline (แทรกในเนื้อหา)</option>
              <option value="bottom">Bottom (ล่างสุด)</option>
            </select>
          </div>
          <div class="col-md-2">
            <label class="form-label">Sort order</label>
            <input name="sort_order" class="form-control" value="0" type="number">
          </div>
          <div class="col-md-4">
            <label class="form-label">Caption</label>
            <input name="caption" class="form-control">
          </div>
          <div class="col-12">
            <button class="btn btn-primary" type="submit">อัปโหลด</button>
          </div>
        </form>

        <h3 class="mt-4">รายการรูป (เรียงตาม Sort Order)</h3>
        <div class="table-responsive">
          <table class="table table-striped align-middle">
            <thead>
              <tr>
                <th>ID</th>
                <th>Preview</th>
                <th>Position</th>
                <th>Sort</th>
                <th>Caption</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php if ($res && $res->num_rows): ?>
                <?php while ($row = $res->fetch_assoc()): ?>
                  <tr>
                    <td><?= intval($row['id']) ?></td>
                    <td><?php if ($row['url']): ?><img src="/admin/<?= htmlspecialchars($row['url']) ?>" style="max-height:80px;"><?php endif; ?></td>
                    <td><?= htmlspecialchars($row['position']) ?></td>
                    <td><?= intval($row['sort_order']) ?></td>
                    <td><?= htmlspecialchars($row['caption']) ?></td>
                    <td>
                      <button class="btn btn-sm btn-info me-2"
                        onclick="openEditModal(
                    <?= intval($row['id']) ?>, 
                    '<?= htmlspecialchars($row['position']) ?>', 
                    <?= intval($row['sort_order']) ?>, 
                    '<?= htmlspecialchars($row['caption'] ?? '') ?>'
                )">แก้ไข</button>

                      <a href="article.php?action=images&article_id=<?= intval($article_id) ?>&delete_image=<?= intval($row['id']) ?>&_token=<?= csrf_token() ?>"
                        onclick="return confirm('ลบรูปภาพนี้หรือไม่? การกระทำนี้จะลบไฟล์ออกจาก Server ด้วย')"
                        class="btn btn-sm btn-danger">ลบ</a>
                    </td>
                  </tr>
                <?php endwhile; ?>
              <?php else: ?>
                <tr>
                  <td colspan="6" class="text-center text-muted">ไม่พบรูปภาพ</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div class="modal fade" id="editImageModal" tabindex="-1" aria-labelledby="editImageModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="post" enctype="multipart/form-data" action="article.php?action=images&article_id=<?= intval($article_id) ?>">
            <input type="hidden" name="_token" value="<?= csrf_token() ?>">
            <input type="hidden" name="update_image_id" id="modal_update_image_id" value="">
            <div class="modal-header">
              <h5 class="modal-title" id="editImageModalLabel">แก้ไขรูปภาพ ID: <span id="modal_image_id_text"></span></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label class="form-label">Position (ตำแหน่ง)</label>
                <select name="position" class="form-select" id="modal_position">
                  <option value="top">Top (บนสุด)</option>
                  <option value="inline">Inline (แทรกในเนื้อหา)</option>
                  <option value="bottom">Bottom (ล่างสุด)</option>
                </select>
              </div>
              <div class="mb-3">
                <label class="form-label">Sort order</label>
                <input name="sort_order" class="form-control" type="number" id="modal_sort_order">
              </div>
              <div class="mb-3">
                <label class="form-label">Caption</label>
                <input name="caption" class="form-control" id="modal_caption">
              </div>
              <div class="mb-3">
                <label class="form-label">เปลี่ยนไฟล์รูปภาพ (เลือกใหม่หากต้องการเปลี่ยน)</label>
                <input type="file" name="new_image" class="form-control">
                <small class="text-muted">หาก **ไม่เลือกไฟล์ใหม่** จะบันทึกเฉพาะข้อมูล Position/Sort/Caption เท่านั้น (ไฟล์รูปภาพเดิม)</small>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ยกเลิก</button>
              <button type="submit" class="btn btn-success">บันทึกการแก้ไข</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <script>
      // Script นี้ต้องทำงานได้เมื่อมีการเรียกใช้ Bootstrap JS
      function openEditModal(id, pos, sort, caption) {
        document.getElementById('modal_image_id_text').textContent = id;
        document.getElementById('modal_update_image_id').value = id;
        document.getElementById('modal_position').value = pos;
        document.getElementById('modal_sort_order').value = sort;
        document.getElementById('modal_caption').value = caption;

        // ต้องเรียกใช้ Bootstrap JS เพื่อเปิด Modal
        const modal = new bootstrap.Modal(document.getElementById('editImageModal'));
        modal.show();
      }
    </script>

<?php
    break;

  default:
    // หาก action ไม่ถูกต้อง ให้กลับไปหน้ารายการ
    header('Location: article.php?action=list');
    exit;
}

// 5. นำเข้า Footer
require_once __DIR__ . '/layout/footer.php';
?>