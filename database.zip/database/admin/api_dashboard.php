<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/db.php';
try {
  $pdo->exec("SET NAMES utf8mb4");
  $one = function($sql) use ($pdo) { return (int)$pdo->query($sql)->fetchColumn(); };
  $total_users  = $one("SELECT COUNT(*) FROM users");
  $total_fh     = $one("SELECT COUNT(*) FROM fhome");
  $total_fp     = $one("SELECT COUNT(*) FROM fpet");
  $total_posts  = $total_fh + $total_fp;
  $total_comments = $one("SELECT COUNT(*) FROM comments");
  $sqlTrend = "
    SELECT d.post_day, COUNT(x.post_day) AS posts
    FROM (
      SELECT DATE(post_date) AS post_day FROM fhome
      UNION ALL
      SELECT DATE(post_date) AS post_day FROM fpet
    ) x
    RIGHT JOIN (
      SELECT CURDATE() - INTERVAL n DAY AS post_day
      FROM (SELECT 0 n UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
            UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6) n
    ) d ON x.post_day = d.post_day
    GROUP BY d.post_day
    ORDER BY d.post_day";
  $trend = $pdo->query($sqlTrend)->fetchAll(PDO::FETCH_ASSOC);
  $sqlTopBreeds = "
    SELECT breed, COUNT(*) AS cnt FROM (
      SELECT breed, post_date FROM fhome
      UNION ALL
      SELECT breed, post_date FROM fpet
    ) p
    WHERE p.post_date >= NOW() - INTERVAL 30 DAY
    GROUP BY breed
    ORDER BY cnt DESC
    LIMIT 5";
  $topBreeds = $pdo->query($sqlTopBreeds)->fetchAll(PDO::FETCH_ASSOC);
  $sqlSpecies = "
    SELECT species, COUNT(*) AS cnt FROM (
      SELECT CASE WHEN type IN ('หมา','dog','Dog') THEN 'Dog'
                  WHEN type IN ('แมว','cat','Cat') THEN 'Cat'
                  ELSE 'Other' END AS species
      FROM fhome WHERE post_date >= NOW() - INTERVAL 30 DAY
      UNION ALL
      SELECT CASE WHEN type IN ('หมา','dog','Dog') THEN 'Dog'
                  WHEN type IN ('แมว','cat','Cat') THEN 'Cat'
                  ELSE 'Other' END AS species
      FROM fpet WHERE post_date >= NOW() - INTERVAL 30 DAY
    ) t GROUP BY species";
  $speciesMix = $pdo->query($sqlSpecies)->fetchAll(PDO::FETCH_ASSOC);
  echo json_encode(['cards'=>['total_users'=>$total_users,'total_posts'=>$total_posts,'total_fh_posts'=>$total_fh,'total_fp_posts'=>$total_fp,'total_comments'=>$total_comments],
    'trend7d'=>$trend,'topBreeds30'=>$topBreeds,'speciesMix30'=>$speciesMix], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) { http_response_code(500); echo json_encode(['error'=>true,'message'=>$e->getMessage()]); }
