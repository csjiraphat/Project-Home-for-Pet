<?php
  $title='Admin';
  $hide_header_title = true;
  include __DIR__.'/layout/header.php';

  include __DIR__.'/nav.inc.php';
?>
<div class="row g-3 kpi">
  <div class="col-12 col-md-6 col-xl-4 d-flex">
    <div class="card p-3 w-100 shadow-sm">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <div class="text-muted small">ผู้ใช้งานทั้งหมด</div>
          <div class="fs-1 fw-bold" id="total_users">-</div>
        </div>
        <div class="icon users"><i class="bi bi-people"></i></div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-4 d-flex">
    <div class="card p-3 w-100 shadow-sm">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <div class="text-muted small">จำนวนโพสต์ทั้งหมด</div>
          <div class="fs-1 fw-bold"><span id="total_posts">-</span></div>
          <div class="text-muted small">หาบ้าน: <span id="total_fh_posts">-</span> / รับเลี้ยง: <span id="total_fp_posts">-</span></div>
        </div>
        <div class="icon posts"><i class="bi bi-file-text"></i></div>
      </div>
    </div>
  </div>
  <div class="col-12 col-md-6 col-xl-4 d-flex">
    <div class="card p-3 w-100 shadow-sm">
      <div class="d-flex justify-content-between align-items-center">
        <div>
          <div class="text-muted small">ข้อความ (คอมเมนต์) ทั้งหมด</div>
          <div class="fs-1 fw-bold" id="total_comments">-</div>
        </div>
        <div class="icon comments"><i class="bi bi-chat-dots"></i></div>
      </div>
    </div>
  </div>
</div>

<div class="row g-3 mt-1">
  <div class="col-lg-8">
    <div class="card chart p-3 shadow-sm">
      <div class="d-flex justify-content-between align-items-center mb-2">
        <h5 class="mb-0">แนวโน้มโพสต์ใหม่ 7 วันล่าสุด</h5>
      </div>
      <canvas id="chartTrend"></canvas>
    </div>
  </div>
  <div class="col-lg-4">
    <div class="card chart p-3 shadow-sm">
      <h5 class="mb-2">สัดส่วนชนิดสัตว์ (30 วัน)</h5>
      <canvas id="chartSpecies"></canvas>
    </div>
    <div class="card chart p-3 mt-3 shadow-sm">
      <h6 class="mb-2">สายพันธุ์ยอดนิยม (Top Breeds - 30 วัน)</h6>
      <ul id="topBreeds" class="list-group list-group-flush"></ul>
    </div>
  </div>
</div>

<?php include __DIR__.'/layout/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  async function loadDashboard() {
    const res = await fetch('api_dashboard.php'); const data = await res.json();
    for (const k in data.cards) { const el = document.getElementById(k); if (el) el.textContent = data.cards[k]; }
    const labels = data.trend7d.map(x => x.post_day);
    const values = data.trend7d.map(x => Number(x.posts));
    new Chart(document.getElementById('chartTrend').getContext('2d'), { type: 'line',
      data: { labels, datasets: [{ label: 'Posts', data: values, tension: .3, fill: false }] },
      options: { responsive: true, plugins: { legend: { display: false } } } });
    const slabels = data.speciesMix30.map(x => x.species);
    const svalues = data.speciesMix30.map(x => Number(x.cnt));
    new Chart(document.getElementById('chartSpecies').getContext('2d'), { type: 'pie',
      data: { labels: slabels, datasets: [{ data: svalues }] }, options: { responsive: true } });
    const ul = document.getElementById('topBreeds'); ul.innerHTML='';
    data.topBreeds30.forEach((b) => { const li=document.createElement('li');
      li.className='list-group-item d-flex justify-content-between align-items-center';
      li.textContent=b.breed||'ไม่ระบุ'; const badge=document.createElement('span');
      badge.className='badge bg-dark rounded-pill'; badge.textContent=b.cnt; li.appendChild(badge); ul.appendChild(li); });
  }
  document.addEventListener('DOMContentLoaded', loadDashboard);
</script>

</div></div>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', ()=>document.body.classList.toggle('show-sidebar'));
// Active menu highlight by page + params
(function(){
  const url = new URL(window.location.href);
  const page = url.pathname.split('/').pop();
  const type = url.searchParams.get('type');
  const entity = url.searchParams.get('entity');
  document.querySelectorAll('.sidebar .nav-link').forEach(a=>{
    const href=a.getAttribute('href');
    if(page==='index.php' && href==='index.php') a.classList.add('active');
    if(page==='posts.php' && href.includes('posts.php') && href.includes('type='+type)) a.classList.add('active');
    if(page==='entity.php' && entity && href.includes('entity='+entity)) a.classList.add('active');
  });
})();
</script>