<?php
// init.php — include this FIRST on every page
if (!ob_get_level()) { ob_start(); }
require_once __DIR__.'/db.php';
