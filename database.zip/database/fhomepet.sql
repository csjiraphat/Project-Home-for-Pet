-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2025 at 07:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fhomepet`
--

-- --------------------------------------------------------

--
-- Table structure for table `adoption_terms`
--

CREATE TABLE `adoption_terms` (
  `term_id` smallint(5) UNSIGNED NOT NULL,
  `name_th` varchar(256) NOT NULL,
  `name_en` varchar(256) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `default_checked` tinyint(1) NOT NULL DEFAULT 0,
  `order_index` smallint(5) UNSIGNED NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adoption_terms`
--

INSERT INTO `adoption_terms` (`term_id`, `name_th`, `name_en`, `description`, `required`, `default_checked`, `order_index`, `is_active`) VALUES
(1, 'บ้านต้องมีรั้ว/ปลอดภัย', 'Fenced/Safe Home', 'ต้องมั่นใจว่าบ้านมีรั้วรอบขอบชิดหรือมาตรการอื่น ๆ เพื่อป้องกันสัตว์เลี้ยงหนีออกนอกบ้าน', 0, 0, 10, 1),
(2, 'ยินยอมให้ตรวจเยี่ยมหลังรับเลี้ยง', 'Post-adoption Check', 'ผู้รับเลี้ยงต้องอนุญาตให้ผู้ให้บ้านเดิม/องค์กรเข้าเยี่ยมเพื่อติดตามความเป็นอยู่ของสัตว์เลี้ยงในภายหลัง', 0, 0, 20, 1),
(3, 'ยินดีทำหมันเมื่อถึงวัยอันควร', 'Spay/Neuter Commitment', 'ผู้รับเลี้ยงต้องทำหมันสัตว์เลี้ยงตามช่วงเวลาที่สัตวแพทย์แนะนำ', 1, 0, 30, 1),
(4, 'พร้อมดูแลวัคซีน/สุขภาพประจำปี', 'Annual Health & Vaccination', 'ผู้รับเลี้ยงต้องดูแลด้านวัคซีนและการตรวจสุขภาพประจำปีอย่างต่อเนื่อง', 1, 0, 40, 1),
(5, 'เหมาะกับบ้านเดี่ยว', 'Suitable for Single House', 'สัตว์เลี้ยงต้องการพื้นที่กว้าง', 0, 0, 50, 1),
(6, 'เหมาะกับคอนโด/อพาร์ตเมนต์', 'Suitable for Condominium', 'สัตว์เลี้ยงที่เงียบ/ไม่รบกวนเพื่อนบ้าน', 0, 0, 60, 1),
(7, 'ต้องมีสนามหญ้า/พื้นที่เล่น', 'Yard/Play Area Required', 'สำหรับสัตว์พลังงานสูง เช่น สุนัขพันธุ์ใหญ่', 0, 0, 70, 1),
(8, 'ต้องมีรั้วรอบบ้าน', 'Fenced Yard Required', 'ป้องกันสัตว์เลี้ยงหนีออกนอกบ้าน', 1, 0, 80, 1),
(9, 'ต้องเป็นที่พักที่อนุญาตสัตว์เลี้ยง', 'Pet-friendly Housing Required', 'ใช้กับผู้ที่อาศัยอพาร์ตเมนต์/คอนโดที่มีกฎห้ามสัตว์เลี้ยง', 1, 0, 90, 1);

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `species` enum('dog','cat') NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `reference_url` text DEFAULT NULL,
  `published_at` date NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `species`, `title`, `content`, `tags`, `reference_url`, `published_at`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'dog', 'เคล็ดลับ การดูแลสัตว์เลี้ยงแบบองค์รวม เพื่อชีวิตที่ยืนยาวและมีความสุข', 'การมีสัตว์เลี้ยงคือความสุขและความรับผิดชอบที่ยิ่งใหญ่ เจ้าของทุกคนย่อมอยากเห็นเพื่อนรักสี่ขามีสุขภาพดีและอยู่เคียงข้างไปนานๆ การดูแลสุขภาพสัตว์เลี้ยงแบบองค์รวม (Holistic Pet Care) ไม่ได้จำกัดอยู่แค่การรักษาโรคเมื่อป่วยเท่านั้น แต่คือการให้ความสำคัญกับ คุณภาพชีวิต ในทุกมิติ ทั้งร่างกาย จิตใจ และสิ่งแวดล้อม\r\n\r\n<img src=\"/admin/uploads/article_1759008980_7449.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">\r\n\r\n1. โภชนาการคือรากฐานของสุขภาพ (Nutrition is Key)\r\nอาหารมีบทบาทสำคัญที่สุดในการสร้างสุขภาพที่ดี ควรเลือกอาหารที่ เหมาะสมตามช่วงวัย สายพันธุ์ และกิจกรรม ของสัตว์เลี้ยง หากไม่แน่ใจ ควรปรึกษาสัตวแพทย์เพื่อขอคำแนะนำเรื่องปริมาณและประเภทอาหารที่ถูกต้อง\r\n\r\nเลือกอาหารคุณภาพสูง: ที่มีสารอาหารครบถ้วนสมดุล ไม่ใช่แค่เน้นปริมาณ\r\n\r\nควบคุมน้ำหนัก: ภาวะน้ำหนักเกินเป็นสาเหตุของโรคเรื้อรังหลายชนิด เช่น โรคข้อเสื่อมและเบาหวาน เจ้าของควรสังเกตช่วงเอวและสามารถคลำซี่โครงได้ง่าย หากอ้วนเกินไป ควรปรึกษาแพทย์เพื่อปรับแผนอาหาร\r\n\r\nน้ำสะอาด: ต้องจัดเตรียมน้ำสะอาดให้สัตว์เลี้ยงดื่มตลอดเวลา และเปลี่ยนน้ำทุกวัน\r\n\r\n2. การดูแลสุขภาพเชิงป้องกัน (Preventive Healthcare)\r\n\"ป้องกันดีกว่ารักษา\" เป็นหัวใจของการดูแลสัตว์เลี้ยงให้ห่างไกลโรค การพาไปพบสัตวแพทย์เพื่อตรวจสุขภาพเป็นประจำจึงจำเป็นอย่างยิ่ง\r\n\r\nตรวจสุขภาพประจำปี: เพื่อตรวจหาความผิดปกติในระยะเริ่มต้น ซึ่งทำให้รักษาได้ง่ายและมีโอกาสหายขาดสูง\r\n\r\nการฉีดวัคซีน: ต้องฉีดวัคซีนป้องกันโรคตามกำหนด เพื่อสร้างภูมิคุ้มกันที่แข็งแรง\r\n\r\nการป้องกันปรสิต: ให้ยาป้องกันเห็บ หมัด และพยาธิเป็นประจำ เพื่อป้องกันการติดเชื้อและโรคที่มาจากปรสิตเหล่านี้\r\n\r\n3. การออกกำลังกายและสุขภาพจิต (Exercise and Mental Well-being)\r\nสัตว์เลี้ยงที่มีความสุขต้องได้ใช้พลังงานและได้รับการกระตุ้นทางจิตใจอย่างเพียงพอ\r\n\r\nออกกำลังกายสม่ำเสมอ: การเดิน วิ่งเล่น หรือเล่นเกมที่เหมาะสมกับสายพันธุ์และช่วงวัย จะช่วยเสริมสร้างความแข็งแรงของกล้ามเนื้อและกระดูก\r\n\r\nรักษากิจวัตรประจำวัน: การมีตารางเวลาการให้อาหาร การขับถ่าย และการเล่นที่สม่ำเสมอจะช่วยให้สัตว์เลี้ยงรู้สึกปลอดภัยและลดความเครียด\r\n\r\nการกระตุ้นทางจิตใจ: ใช้ของเล่นลับสมอง (Puzzle Toys) หรือฝึกคำสั่งใหม่ๆ เพื่อให้พวกเขามีสมาธิและไม่รู้สึกเบื่อ การได้รับความสนใจและการเล่นกับเจ้าของเป็นประจำคืออาหารใจที่ดีที่สุด\r\n\r\n4. การจัดการสิ่งแวดล้อมที่ปลอดภัย (Safe Environment)\r\nสภาพแวดล้อมที่อยู่สบายและปลอดภัยส่งผลโดยตรงต่อสุขภาพโดยรวม\r\n\r\nพื้นที่พักผ่อน: จัดเตรียมที่นอนที่สะอาด แห้ง และอบอุ่น มีที่หลบแดดหลบฝน\r\n\r\nความสะอาด: หมั่นทำความสะอาดของใช้ เช่น ชามอาหาร กระบะทราย และที่นอน เพื่อป้องกันการสะสมของเชื้อโรคและกลิ่นไม่พึงประสงค์\r\n\r\nความปลอดภัยในบ้าน: เก็บสารเคมี ยา และอาหารที่เป็นอันตราย (เช่น ช็อกโกแลต องุ่น) ให้พ้นมือ รวมถึงระมัดระวังอันตรายจากสัตว์มีพิษ เช่น งู โดยเฉพาะในช่วงหน้าฝน\r\n\r\nการดูแลสัตว์เลี้ยงแบบองค์รวมคือการให้ความรัก ความรับผิดชอบ และความใส่ใจในทุกรายละเอียด เมื่อคุณดูแลพวกเขาด้วยความเข้าใจ พวกเขาก็จะตอบแทนคุณด้วยความรักที่บริสุทธิ์และช่วงเวลาที่แสนสุขอย่างแน่นอน', 'การดูแล', NULL, '2025-09-27', 1, '2025-09-27 09:24:07', '2025-09-27 16:36:38'),
(2, 'cat', 'การดูแลสัตว์เลี้ยงแบบองค์รวม เพื่อชีวิตที่ยืนยาวและมีความสุข', '<p><img style=\"max-width: 100%; height: 278px; display: block; margin-left: auto; margin-right: auto;\" src=\"/admin/uploads/article_1758984818_2536.jpg\" alt=\"0\" width=\"495\"> การตัดสินใจรับแมวเข้ามาเป็นสมาชิกใหม่ของบ้านเป็นการเริ่มต้นการเดินทางที่เต็มไปด้วยความสุขและความผูกพัน เพื่อให้แน่ใจว่าเพื่อนตัวน้อยของคุณจะมีชีวิตที่ยืนยาวและเปี่ยมสุข การดูแลเอาใจใส่ในทุกๆ ด้านจึงเป็นสิ่งสำคัญยิ่ง บทความนี้ได้รวบรวมแนวทางการดูแลแมวอย่างครบถ้วน ตั้งแต่เรื่องอาหารการกิน การดูแลสุขภาพ ไปจนถึงการสร้างสภาพแวดล้อมที่เหมาะสม เพื่อให้ทาสแมวมือใหม่และมือโปรได้นำไปปรับใช้ 1. โภชนาการและอาหาร: พื้นฐานสำคัญของสุขภาพที่ดี หัวใจของการดูแลแมวคือการมอบอาหารที่เหมาะสมและมีคุณค่าทางโภชนาการครบถ้วน แมวเป็นสัตว์กินเนื้อโดยธรรมชาติ (Carnivore) ดังนั้น อาหารของพวกเขาจึงควรมีโปรตีนจากสัตว์เป็นส่วนประกอบหลัก เลือกอาหารที่เหมาะสม: เลือกอาหารแมวสำเร็จรูปคุณภาพสูงที่ระบุว่ามีสารอาหารครบถ้วนตามช่วงวัย (ลูกแมว, แมวโต, แมวสูงวัย) อ่านฉลากเพื่อดูว่ามีเนื้อสัตว์เป็นส่วนผสมอันดับแรก สารอาหารที่จำเป็น: นอกจากโปรตีนแล้ว แมวต้องการกรดไขมัน (เช่น โอเมก้า 3 และ 6 เพื่อสุขภาพผิวหนังและขน), วิตามิน และแร่ธาตุต่างๆ เช่น แคลเซียมและฟอสฟอรัสเพื่อกระดูกที่แข็งแรง น้ำสะอาดคือสิ่งสำคัญ: แมวควรมีน้ำสะอาดดื่มได้ตลอดเวลา ควรเปลี่ยนน้ำทุกวันและล้างชามน้ำให้สะอาดเสมอ การตั้งน้ำพุแมวอาจช่วยกระตุ้นให้แมวดื่มน้ำมากขึ้น กำหนดเวลาให้อาหาร: การให้อาหารเป็นเวลา 2-3 มื้อต่อวัน จะช่วยควบคุมปริมาณอาหารได้ดีกว่าการเทอาหารทิ้งไว้ตลอดเวลา ซึ่งอาจนำไปสู่ภาวะน้ำหนักเกิน 2. การดูแลสุขภาพและการป้องกันโรค การป้องกันย่อมดีกว่าการรักษา การดูแลสุขภาพเชิงป้องกันจะช่วยให้แมวของคุณห่างไกลจากโรคภัยไข้เจ็บ การฉีดวัคซีน: ปรึกษาสัตวแพทย์เพื่อจัดโปรแกรมวัคซีนที่จำเป็น เช่น วัคซีนป้องกันโรคพิษสุนัขบ้า, โรคไข้หัดแมว และโรคลิวคีเมียในแมว การควบคุมปรสิต: ป้องกันปรสิตทั้งภายนอก (เห็บ, หมัด) และภายใน (พยาธิ) อย่างสม่ำเสมอ โดยใช้ผลิตภัณฑ์ตามคำแนะนำของสัตวแพทย์ การทำหมัน: การทำหมัน (ทั้งตัวผู้และตัวเมีย) ไม่เพียงแต่ช่วยควบคุมประชากรแมว แต่ยังส่งผลดีต่อสุขภาพในระยะยาว ลดความเสี่ยงของโรคบางชนิด และลดพฤติกรรมที่ไม่พึงประสงค์ เช่น การหนีเที่ยวนอกบ้านหรือการพ่นปัสสาวะเพื่อสร้างอาณาเขต ตรวจสุขภาพประจำปี: ควรพาแมวไปพบสัตวแพทย์เพื่อตรวจสุขภาพอย่างน้อยปีละหนึ่งครั้ง เพื่อตรวจหาความผิดปกติที่อาจเกิดขึ้นตั้งแต่เนิ่นๆ 3. การสร้างสภาพแวดล้อมที่ปลอดภัยและกระตุ้นพัฒนาการ แมวที่เลี้ยงในบ้านต้องการสภาพแวดล้อมที่ตอบสนองต่อสัญชาตญาณตามธรรมชาติของพวกมัน พื้นที่ส่วนตัวที่ปลอดภัย: จัดหามุมสงบหรือที่นอนนุ่มๆ ที่แมวสามารถรู้สึกปลอดภัยและได้พักผ่อนโดยไม่มีใครรบกวน กล่องกระดาษหรือคอนโดแมวก็เป็นตัวเลือกที่ดี กระบะทราย: จัดเตรียมกระบะทรายให้มีขนาดเหมาะสมและสะอาดอยู่เสมอ ควรวางไว้ในมุมที่เงียบสงบและเข้าถึงง่าย หากมีแมวหลายตัว ควรมีกระบะทรายมากกว่าจำนวนแมว 1 ใบ (เช่น แมว 2 ตัว ควรมีกระบะทราย 3 ใบ) ที่ฝนเล็บ: การฝนเล็บเป็นพฤติกรรมตามธรรมชาติของแมว จัดหาที่ฝนเล็บที่มั่นคงและมีความสูงเพียงพอให้แมวได้ยืดตัวและลับเล็บ เพื่อป้องกันไม่ให้แมวไปทำลายเฟอร์นิเจอร์ ของเล่นและการปีนป่าย: จัดหาของเล่นที่หลากหลายเพื่อกระตุ้นสัญชาตญาณนักล่า เช่น ลูกบอล, เบ็ดตกแมว หรือของเล่นที่มีแคทนิป คอนโดแมวหรือชั้นติดผนังจะช่วยให้แมวได้ปีนป่ายและสำรวจในแนวดิ่ง ซึ่งเป็นพฤติกรรมที่แมวชื่นชอบ 4. การดูแลความสะอาดและเสริมสวย การดูแลความสะอาดไม่เพียงแต่ทำให้แมวดูดี แต่ยังเป็นโอกาสในการตรวจเช็คสุขภาพผิวหนังและขนอีกด้วย การแปรงขน: แมวขนสั้นควรได้รับการแปรงขนอย่างน้อยสัปดาห์ละครั้ง ส่วนแมวขนยาวอาจต้องการการแปรงขนทุกวันเพื่อป้องกันขนพันกันและลดการเกิดก้อนขน (Hairball) ในทางเดินอาหาร การอาบน้ำ: โดยปกติแล้วแมวเป็นสัตว์รักสะอาดและไม่จำเป็นต้องอาบน้ำบ่อย ควรอาบน้ำเมื่อจำเป็นเท่านั้น เช่น เมื่อตัวสกปรกมาก และควรใช้แชมพูสำหรับแมวโดยเฉพาะ การตัดเล็บ: ควรตัดเล็บให้แมวเป็นประจำเพื่อป้องกันเล็บยาวเกินไปจนข่วนทำลายข้าวของหรือทิ่มเข้าไปในอุ้งเท้า ควรตัดเฉพาะส่วนปลายที่เป็นสีขาวใสเท่านั้น ทำความสะอาดหูและฟัน: ตรวจสอบหูของแมวเป็นประจำและใช้สำลีชุบน้ำยาเช็ดหูสำหรับแมวทำความสะอาดเมื่อสกปรก การแปรงฟันด้วยยาสีฟันสำหรับแมวจะช่วยป้องกันปัญหาสุขภาพช่องปากได้ 5. ทำความเข้าใจพฤติกรรมและภาษากายของแมว การเรียนรู้ที่จะ \"อ่าน\" พฤติกรรมของแมวจะช่วยสร้างความสัมพันธ์ที่แน่นแฟ้นยิ่งขึ้น ภาษากาย: สังเกตการเคลื่อนไหวของหู หาง และเสียงร้อง เพื่อทำความเข้าใจอารมณ์ของแมว เช่น หางที่ตั้งตรงบ่งบอกถึงความเป็นมิตร ในขณะที่หางที่สะบัดไปมาอย่างรวดเร็วอาจหมายถึงความรำคาญ การเล่น: แบ่งเวลาเล่นกับแมวทุกวัน การเล่นช่วยกระชับความสัมพันธ์และช่วยให้แมวได้ออกกำลังกาย ให้เวลาปรับตัว: เมื่อนำแมวเข้าบ้านใหม่ ควรให้เวลาและพื้นที่ส่วนตัวให้เขาได้ปรับตัวกับสภาพแวดล้อมใหม่ๆ อย่างค่อยเป็นค่อยไป <img style=\"max-width: 100%; height: 505px; display: block; margin-left: auto; margin-right: auto;\" src=\"/admin/uploads/article_1758984835_2521.jpg\" alt=\"0\" width=\"483\"> การดูแลแมวหนึ่งชีวิตคือความรับผิดชอบที่ยิ่งใหญ่ แต่ผลตอบแทนที่ได้คือความรัก ความผูกพัน และเสียงครางอย่างมีความสุขจากเพื่อนสี่ขาขนฟูที่จะมาเติมเต็มชีวิตของคุณในทุกๆ วัน</p>', 'การดูแล', '', '2025-09-27', 1, '2025-09-27 09:45:40', '2025-10-14 01:18:44'),
(4, 'dog', '5 เทคนิคฝึกน้องหมาเข้าบ้านใหม่ให้เชื่อฟัง', '<img src=\"/admin/uploads/article_1759008335_6893.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">\r\nการต้อนรับลูกสุนัขตัวใหม่เข้าบ้านเป็นช่วงเวลาที่น่าตื่นเต้น แต่ก็มาพร้อมกับความท้าทายในการฝึกสอน การสร้างกฎเกณฑ์และกิจวัตรประจำวันที่ชัดเจนตั้งแต่เนิ่นๆ เป็นสิ่งสำคัญ เริ่มต้นด้วยการฝึกเข้าห้องน้ำโดยพาน้องหมาออกไปขับถ่ายเป็นเวลาหลังตื่นนอนและหลังกินอาหารทุกมื้อ ใช้คำสั่งที่สั้นและกระชับ เช่น นั่ง หรือ คอย พร้อมให้รางวัลเป็นขนมเมื่อทำตามคำสั่ง การสร้างสภาพแวดล้อมที่ปลอดภัยและเต็มไปด้วยความรักจะช่วยให้พวกเขาปรับตัวได้เร็วขึ้น', 'ฝึกสุนัข, ลูกสุนัข, การเลี้ยงสุนัข, ปรับพฤติกรรม', NULL, '2025-09-26', 1, '2025-09-27 20:16:09', '2025-09-27 16:28:55'),
(5, 'dog', 'เปิดคู่มือดูแลน้องหมา รู้ทันโรคของสุนัขมีอะไรบ้าง ?', '<img src=\"/admin/uploads/article_1759009095_8907.jpg\" alt=\"0\" style=\"width: 100%; height: auto;\" data-resize-mode=\"cover\">\r\nหนึ่งสิ่งที่ทำให้คนเลี้ยงสุนัขรู้สึกกังวลใจอยู่เสมอ นั่นคืออาการป่วยที่ไม่รู้ว่าจะมาตอนไหนของเหล่าเจ้าตูบ ใครที่เป็นเจ้าของน้องหมาและมีความกังวลใจในเรื่องนี้ห้ามพลาด เพราะในบทความนี้เราได้รวบรวมโรคของสุนัขในแต่ละวัยมาบอกต่อ เพื่อใช้เป็นไกด์ในการดูแล รวมถึงเฝ้าระวังอาการอย่างเหมาะสม\r\n\r\nลูกสุนัข ช่วงวัยและโรคของสุนัขที่พบได้บ่อย\r\nลูกสุนัข คือสุนัขอายุตั้งแต่แรกเกิด จนถึงช่วงประมาณ 10 เดือน ซึ่งถือเป็นช่วงวัยที่ต้องการการดูแลและต้องระมัดระวังในเรื่องอาหารการกิน เพราะเป็นช่วงที่ต้องเสริมสร้างภูมิคุ้มกันให้แข็งแรง ซึ่งอาจป่วยได้ง่ายหากไม่มีการดูแลที่เหมาะสม\r\n\r\nโรคที่พบได้บ่อยในวัยลูกสุนัข\r\nโรคไข้สุนัข (Canine Distemper)\r\nโรคของสุนัขที่เกิดจากเชื้อไวรัส Canine Distemper Virus (CDV) นับเป็นโรคติดต่อร้ายแรง พบได้บ่อยในสุนัขอายุ 3-6 เดือน โดยจะมีอาการไข้สูง ซึม เบื่ออาหาร ตาแดง มีขี้ตาหรือน้ำตาเกรอะกรัง อาจมีอาการท้องเสียหรืออาเจียนร่วมด้วย และอาจรุนแรงจนทำให้มีอาการทางระบบประสาท เช่น ตัวกระตุก หรือชักได้\r\n\r\nแนวทางการป้องกันและรักษา: โรคไข้หัดสุนัขยังไม่มีวิธีรักษาที่เฉพาะเจาะจง แต่สามารถป้องกันได้ด้วยการพาสุนัขไปรับวัคซีนป้องกัน โดยเริ่มฉีดได้ตั้งแต่อายุ 6-8 เดือน\r\n\r\nโรคลำไส้อักเสบ (Canine Parvovirus)\r\nเกิดจากเชื้อไวรัส Parvovirus อาการที่แสดงให้เห็นอย่างชัดเจนของโรคนี้คือ สุนัขจะมีอาการท้องเสียอย่างรุนแรง มีการถ่ายเหลวเป็นน้ำหรือเลือด อุจจาระส่งกลิ่นเหม็นรุนแรง ซึ่งโรคลำไส้อักเสบหากป่วยแล้ว จะมีโอกาสเสียชีวิตค่อนข้างสูง และยังสามารถติดต่อกันเองในหมู่ลูกสุนัขได้ง่าย ในกรณีที่เลี้ยงรวมกันหลายตัว ซึ่งหากพบว่าน้องหมาตัวใดตัวหนึ่งป่วยเป็นโรคนี้ ควรทำการแยกออกมาจากน้องหมาตัวอื่น ๆ โดยเร็วที่สุด\r\n\r\nแนวทางการป้องกันและรักษา: เช่นเดียวกับโรคไข้หัดสุนัข ที่ยังไม่มีวิธีการรักษาอย่างเฉพาะเจาะจง แต่ให้ป้องกันด้วยการนำไปรับวัคซีนตามโปรแกรมฉีดที่สัตวแพทย์แนะนำอย่างเคร่งครัด เริ่มได้ตั้งแต่อายุ 6-8 สัปดาห์\r\n\r\nโรคหลอดลมอักเสบติดต่อในสุนัข (Kennel Cough)\r\nเป็นลักษณะอาการที่ใกล้เคียงกับไข้หวัดของมนุษย์ ลูกสุนัขที่เป็นโรคนี้ จะมีภาวะหลอดลมอักเสบติดต่อ โดยจะมีอาการไอและมีเสมหะ รวมถึงอาการซึม มีอาการตาแดงร่วมด้วย โดยสามารถติดต่อกันในหมู่ลูกสุนัขผ่านละอองน้ำมูกและน้ำลาย\r\n\r\nแนวทางการป้องกันและรักษา: หากมีอาการไม่รุนแรง แนะนำให้พาลูกสุนัขพักผ่อน ดื่มน้ำ และรับอาหารให้เพียงพอจนอาการทุเลาลง แต่ถ้าอาการเริ่มหนักขึ้น เพราะมีอาการทางปอดเข้ามาแทรกแซง ให้รีบพาไปพบสัตวแพทย์ เพื่อทำการรักษาอย่างเหมาะสมทันที ส่วนวิธีป้องกันก็สามารถพาไปรับวัคซีนได้ตั้งแต่อายุ 8 สัปดาห์เป็นต้นไป\r\n\r\nสุนัขโตเต็มวัย ช่วงวัยและโรคของสุนัขที่พบได้บ่อย\r\nสุนัขอายุ 10 เดือน ถึง 11 ปี ถือเป็นช่วงที่กำลังโตเต็มวัย มีการเรียนรู้พัฒนาการที่ชัดเจน ทั้งรูปร่างที่ตัวใหญ่และยาวขึ้น มีอุ้งเท้าและขาที่สมส่วน มีลักษณะทางกายภาพที่ชัดเจนตามสายพันธุ์ แต่ก็ยังมีโอกาสป่วยได้ไม่ต่างจากวัยลูกสุนัข\r\n\r\nโรคที่พบได้บ่อยในสุนัขโตเต็มวัย\r\nพยาธิหนอนหัวใจ (Dirofilaria immitis)\r\nเป็นอาการป่วยที่มียุงเป็นพาหะของโรค ซึ่งตัวอ่อนของพยาธิจะอาศัยอยู่ในตัวยุง และเมื่อยุงกัดสุนัข ตัวอ่อนจะเข้าไปในร่างกายและกลายเป็นตัวโตเต็มวัย ซึ่งจะเข้าไปอาศัยอยู่ในหัวใจห้องขวาและหลอดเลือดที่ส่งเลือดไปฟอกที่ปอด โดยพยาธิจะทำการชอนไช ทำลายเนื้อเยื่อหรืออุดตันหัวใจและหลอดเลือดได้\r\n\r\nสามารถสังเกตว่าน้องหมาของคุณ ป่วยเป็นโรคของสุนัขโรคนี้หรือไม่ ด้วยการดูจากการไอ หากไอแห้ง เหนื่อยง่าย และมีอาการท้องมาน แนะนำว่าให้รีบนำไปพบสัตวแพทย์โดยด่วน เพราะโรคนี้อาจรุนแรงและอันตรายถึงแก่ชีวิตได้เลย\r\n\r\nแนวทางการป้องกันและรักษา: สามารถรักษาได้ด้วยการใช้ยา หรือร่วมกับการผ่าตัด โดยฉีดยาฆ่าพยาธิ เพื่อไปกำจัดตัวโตเต็มวัยที่อาศัยอยู่ในร่างกายน้องหมา แต่ถ้ามีพยาธิหนอนหัวใจจำนวนมากก็จำเป็นต้องใช้วิธีผ่าตัดเพื่อเอาออกแทน\r\n\r\nโรคพิษสุนัขบ้า\r\nโรคที่เกิดจาก Rabies Virus พบได้บ่อยในไทย สามารถติดกันผ่านสุนัขหรือสัตว์เลี้ยงลูกด้วยนมทุกชนิด มีอาการที่แสดงอย่างชัดเจนผ่านนิสัยที่เริ่มเปลี่ยนไป หงุดหงิด กระวนกระวาย ก้าวร้าว แสดงอาการดุร้ายโดยการกัด หรือเข้าไปทำร้ายทุกอย่างที่ขวางหน้า ลิ้นห้อย น้ำลายไหลยืด ก่อนจะชัก เป็นอัมพาต และเสียชีวิตในที่สุด\r\n\r\nแนวทางการป้องกันและรักษา: เป็นอีกหนึ่งโรคของสุนัขที่ยังไม่มีวิธีรักษาที่ชัดเจน แต่มีวิธีช่วยป้องกันได้ โดยการฉีดวัคซีน ตั้งแต่อายุ 3 เดือนขึ้นไป และรับวัคซีนต่อเนื่องตามคำแนะนำของสัตวแพทย์\r\n\r\nโรคพยาธิเม็ดเลือด\r\nอีกโรคของสุนัขที่พบได้บ่อยในสุนัขโตเต็มวัย มีพาหะจากเห็บ เกิดจากเชื้อโปรโตซัว 3 ชนิด คือ Babesia canis, Ehrlichia canis และ Hepatozoon canis อาการของสุนัขที่ป่วยด้วยโรคนี้ จะมีอาการโลหิตจางจากการที่เม็ดเลือดถูกทำลาย ผนังหลอดเลือดอักเสบ เลือดออกง่าย กำเดาไหลง่าย หรือมีจุดเลือดออกสีแดงตามผิวหนัง โดยเฉพาะตรงช่องท้อง ร่วมกับอาการเหงือกซีด\r\n\r\nแนวทางการป้องกันและรักษา: สามารถรักษาได้โดยการให้ยาฆ่าพยาธิเม็ดเลือด และรักษาตามอาการอย่างต่อเนื่อง ส่วนวิธีป้องกันสามารถทำได้เพียงแค่ไม่ให้สุนัขของเรามีเห็บ โดยใช้วิธีฉีดยา ยาหยอดหลัง หรือยากิน ตามคำแนะนำที่เหมาะสมของสัตวแพทย์\r\n\r\nสุนัขสูงวัย ช่วงวัยและโรคของสุนัขที่พบได้บ่อย\r\nสุนัขสูงวัย คือน้องหมาใช่ช่วงอายุ 12 ปีขึ้นไป เป็นวัยที่ไม่มีพลังงานมากเหมือนเมื่อก่อน ระบบร่างกายเสื่อมสภาพ เสี่ยงต่อการเกิดโรคหรือติดเชื้อได้ง่าย ทำให้ต้องระมัดระวังเรื่องน้ำและอาหารที่กินเข้าไป รวมถึงความสะอาด และการดูแลตามอาการให้เหมาะสม\r\n\r\n<img src=\"/admin/uploads/article_1759009197_4866.jpg\" alt=\"0\" style=\"width: 100%; height: auto; float: left;\" data-resize-mode=\"cover\">\r\n\r\nโรคที่พบได้บ่อยในสุนัขสูงวัย\r\nโรคไตวายเรื้อรัง\r\nนับเป็นอีกโรคของสุนัขที่ที่พบได้มากในน้องหมาสูงวัย สาเหตุเกิดจากการที่ไตค่อย ๆ เสื่อมสภาพ ทำงานได้น้อยลง จึงทำให้ไม่สามารถกรองและขับของเสียได้ดีเท่าเดิม ส่งผลให้ร่างกายของสุนัขเกิดการสะสมของเสีย จนมากขึ้นเรื่อย ๆ ซึ่งความน่ากลัวคือไม่สามารถสังเกตอาการเริ่มต้นได้ เพราะกว่าจะแสดงออกมา ไตก็ลดการทำงานไปมากกว่า 75% ซึ่งทำให้ร่างกายของน้องหมามีปัญหาสุขภาพอย่างชัดเจนไปแล้ว\r\n\r\nแนวทางการป้องกันและรักษา: ไม่มีวิธีรักษาให้หายขาด แต่จะประคองการรักษาไปตามอาการอย่างต่อเนื่อง ส่วนวิธีป้องกัน แนะนำให้เจ้าของพาสุนัขมาตรวจสุขภาพประจำปีอย่างสม่ำเสมอ เพื่อเฝ้าระวังและเริ่มแผนการรักษาได้อย่างทันท่วงที\r\n\r\nโรคหัวใจ\r\nพบได้ทั้งโรคลิ้นหัวใจไมทรัลเสื่อม (Myxomatous Valvular Degeneration) และโรคหัวใจโต (Dilated Cardiomyopathy) โดยโรคลิ้นหัวใจไมทรัลเสื่อมนั้นมักพบได้ในสุนัขพันธุ์เล็ก เกิดขึ้นจากลิ้นหัวใจไมทรัลที่ทำหน้าที่ปิดเปิดเลือดในหัวใจห้องบนซ้ายและห้องล่างซ้ายทำงานได้ไม่ดีเท่าเดิม ส่งผลให้เลือดไหลเวียนไม่ดี อาจเกิดเลือดคั่งที่หัวใจและปอด\r\n\r\nส่วนโรคหัวใจโต มักจะพบในสุนัขพันธุ์ใหญ่มากกว่า ลักษณะหัวใจมีขนาดพองตัว แต่กล้ามเนื้อหัวใจกลับบางลง ทำให้แรงบีบหัวใจลดลง มีอาการเลือดคั่งในหัวใจ ไม่สามารถนำเลือดไปเลี้ยงส่วนต่าง ๆ ของร่างกายได้อย่างเหมาะสม โดยอาการร่วมของทั้งสองโรค คืออาการเหนื่อยง่าย หอบ ไม่สามารถออกกำลังหรือทำกิจกรรมหนัก ๆ ได้ เพราะอาจเป็นลม ร่วมกับมีอาการไอ ซึ่งทำให้เสียชีวิตได้เลย\r\n\r\nแนวทางการป้องกันและรักษา: วิธีการรักษาคือการดูแลจากสัตวแพทย์อย่างใกล้ชิด เพิ่มเติมด้วยการตรวจคลื่นไฟฟ้าหัวใจ (ECG) และอัลตราซาวด์เพื่อหาสาเหตุให้ตรงจุด ส่วนวิธีป้องกัน คือให้พาสุนัขไปทำการตรวจสุขภาพเป็นประจำทุก ๆ ปี เพื่อประเมินและรับการวินิจฉัย ร่วมกับการรักษาที่เหมาะสม\r\n\r\nหลังจากรู้แล้วโรคของสุนัขมีอะไรบ้าง แต่จะเข้าใจข้อมูลอย่างเดียวก็ไม่ได้ แต่ต้องรู้เท่าทันด้วยการตรวจเช็กสุขภาพน้องหมาเป็นประจำด้วย พร้อมดูแลเรื่องอาหารการกินให้เหมาะสม หากใครที่กำลังมองหาอาหารหมาป่วยที่ได้มาตรฐาน มีวัตถุดิบชั้นดี ถูกต้องตามหลักโภชนาการจากแบรนด์ชั้นนำ สามารถปรึกษาและเลือกซื้อได้เลยที่ PETClub อาณาจักรสินค้าสัตว์เลี้ยงที่จำหน่ายทั้งอาหารและอุปกรณ์สำหรับสัตว์เลี้ยงทุกประเภท จึงมั่นใจได้ว่าจะมีผลิตภัณฑ์อาหารสุนัข สูตรอาหารหมาป่วยให้เลือกซื้อได้อย่างปลอดภัยแน่นอน', 'สุขภาพสุนัข, โรคสุนัข, สุนัขป่วย, การดูแล', NULL, '2025-09-25', 1, '2025-09-27 20:16:09', '2025-09-27 17:15:33'),
(6, 'dog', 'อาหารต้องห้ามสำหรับสุนัข: อะไรบ้างที่น้องหมากินไม่ได้?', '<img src=\"/admin/uploads/article_1759011513_3154.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">\r\nอาหารของมนุษย์หลายชนิดเป็นพิษต่อสุนัขและอาจเป็นอันตรายถึงชีวิต สิ่งที่ห้ามให้เด็ดขาดคือ: ช็อกโกแลต, องุ่นและลูกเกด, หัวหอมและกระเทียม, อะโวคาโด, แอลกอฮอล์, และสารให้ความหวานไซลิทอล (Xylitol) ที่มักพบในหมากฝรั่งและขนมบางชนิด การทำความเข้าใจเรื่องนี้จะช่วยป้องกันเหตุการณ์ไม่คาดฝันและรักษาสุขภาพที่ดีให้กับเพื่อนสี่ขาของคุณ', 'โภชนาการ, อาหารสุนัข, ของกินอันตราย, สุขภาพ', NULL, '2025-09-24', 1, '2025-09-27 20:16:09', '2025-09-27 17:18:46'),
(7, 'dog', 'เคล็ดลับดูแลขนสุนัขให้สวยเงางาม สุขภาพดี', '<img src=\"/admin/uploads/article_1759011647_1634.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">ขนที่สวยงามเป็นสัญญาณของสุนัขที่มีสุขภาพดี การดูแลขนควรเริ่มจากการแปรงขนเป็นประจำเพื่อกำจัดขนที่ตายแล้วและป้องกันการพันกัน การเลือกแชมพูที่เหมาะสมกับสภาพผิวหนังและเส้นขนก็สำคัญไม่แพ้กัน หลังอาบน้ำควรเช็ดและเป่าขนให้แห้งสนิทเพื่อป้องกันความอับชื้น นอกจากนี้ อาหารที่มีกรดไขมันโอเมก้า 3 และ 6 จะช่วยบำรุงเส้นขนจากภายในสู่ภายนอก', 'ดูแลขน, แปรงขน, อาบน้ำสุนัข, กรูมมิ่ง', NULL, '2025-09-23', 1, '2025-09-27 20:16:09', '2025-09-27 17:21:03'),
(8, 'dog', 'พาน้องหมาออกกำลังกายอย่างไรให้เหมาะสมตามสายพันธุ์', '<img src=\"/admin/uploads/article_1759011715_8922.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">สุนัขแต่ละสายพันธุ์มีความต้องการในการออกกำลังกายที่แตกต่างกัน สุนัขพลังงานสูงอย่างไซบีเรียน ฮัสกี้ หรือ บอร์เดอร์ คอลลี่ ต้องการการวิ่งหรือกิจกรรมที่หนักหน่วงอย่างน้อยวันละ 1-2 ชั่วโมง ในขณะที่สุนัขพันธุ์เล็กอย่างชิวาวาหรือปั๊กอาจต้องการเพียงการเดินเล่นสั้นๆ วันละ 20-30 นาที การออกกำลังกายที่เหมาะสมไม่เพียงแต่ช่วยควบคุมน้ำหนัก แต่ยังช่วยลดปัญหาพฤติกรรมที่เกิดจากความเบื่อหน่ายได้อีกด้วย', 'ออกกำลังกาย, พลังงานสูง, สุนัขพันธุ์ใหญ่, สุขภาพ', NULL, '2025-09-22', 1, '2025-09-27 20:16:09', '2025-09-27 17:22:05'),
(9, 'cat', 'ถอดรหัสภาษากายแมว: รู้ใจเหมียวผ่านทางหู หาง และเสียงร้อง', '<img src=\"/admin/uploads/article_1759011813_8758.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">แมวสื่อสารกับเราตลอดเวลาผ่านภาษากายที่ซับซ้อน การสังเกตหู หาง และดวงตาจะช่วยให้คุณเข้าใจอารมณ์ของพวกเขาได้ดีขึ้น เช่น หางตั้งตรงหมายถึงความเป็นมิตรและทักทาย, หูที่ลู่ไปข้างหลังแสดงถึงความกลัวหรือก้าวร้าว, การส่งเสียงครางเบาๆ (Purring) ไม่ได้แปลว่ามีความสุขเสมอไป แต่อาจเป็นการปลอบใจตัวเองเมื่อรู้สึกเจ็บปวด การเรียนรู้สิ่งเหล่านี้จะทำให้ความสัมพันธ์ของคุณกับแมวแน่นแฟ้นยิ่งขึ้น', 'พฤติกรรมแมว, ภาษากาย, แมวสื่อสาร, การเลี้ยงแมว', NULL, '2025-09-26', 1, '2025-09-27 20:16:09', '2025-09-27 17:23:40'),
(10, 'cat', 'แก้ปัญหาแมวไม่ใช้กระบะทราย: สาเหตุและวิธีแก้ไข', '<img src=\"/admin/uploads/article_1759011873_3052.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">การที่แมวขับถ่ายนอกกระบะทรายเป็นปัญหาที่พบได้บ่อย สาเหตุอาจมาจากความเครียด, ปัญหาสุขภาพ, กระบะทรายที่ไม่สะอาด, หรือการไม่ชอบทรายที่ใช้อยู่ วิธีแก้ไขเบื้องต้นคือการทำความสะอาดกระบะทรายทุกวัน, ลองเปลี่ยนชนิดของทราย, และวางกระบะทรายในตำแหน่งที่เงียบสงบและเข้าถึงง่าย หากมีแมวหลายตัว ควรมีจำนวนกระบะทรายมากกว่าจำนวนแมว 1 ใบเสมอ หากปัญหายังคงอยู่ควรพาไปพบสัตวแพทย์เพื่อตรวจหาสาเหตุทางสุขภาพ', 'กระบะทราย, ขับถ่าย, พฤติกรรม, แมวเครียด', NULL, '2025-09-25', 1, '2025-09-27 20:16:09', '2025-09-27 17:24:40'),
(11, 'cat', 'เปลี่ยนบ้านให้น่าอยู่สำหรับแมวระบบปิด (Indoor Cat)', '<img src=\"/admin/uploads/article_1759011940_4085.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">แมวที่เลี้ยงในบ้านต้องการสภาพแวดล้อมที่ช่วยกระตุ้นสัญชาตญาณตามธรรมชาติ การจัดหาคอนโดแมวหรือชั้นวางให้ปีนป่ายในแนวดิ่งเป็นสิ่งสำคัญมาก ของเล่นลับสมองหรือเบ็ดตกแมวช่วยสนองสัญชาตญาณนักล่า การจัดมุมริมหน้าต่างให้นั่งดูนกก็เป็นความบันเทิงชั้นดี การสร้างสิ่งแวดล้อมที่หลากหลายจะช่วยลดความเบื่อหน่ายและความเครียด ทำให้แมวของคุณมีความสุขและสุขภาพจิตดี', 'แมวในบ้าน, ของเล่นแมว, คอนโดแมว, สิ่งแวดล้อม', NULL, '2025-09-24', 1, '2025-09-27 20:16:09', '2025-09-27 17:25:54'),
(12, 'cat', 'โรคไตในแมว: ภัยเงียบที่ทาสแมวต้องระวัง', '<img src=\"/admin/uploads/article_1759012006_4454.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">โรคไตเรื้อรังเป็นหนึ่งในโรคที่พบบ่อยที่สุดในแมวสูงวัย อาการในระยะแรกมักไม่ชัดเจน แต่สัญญาณที่ควรสังเกตคือแมวดื่มน้ำเยอะและปัสสาวะเยอะกว่าปกติ, เบื่ออาหาร, น้ำหนักลด, และมีภาวะขาดน้ำ การตรวจสุขภาพและตรวจเลือดเป็นประจำทุกปีมีความสำคัญอย่างยิ่งในการตรวจพบโรคนี้ตั้งแต่เนิ่นๆ ซึ่งจะช่วยชะลอความเสื่อมของไตและยืดอายุขัยของแมวได้', 'โรคไต, สุขภาพแมว, แมวสูงวัย, แมวป่วย', NULL, '2025-09-23', 1, '2025-09-27 20:16:09', '2025-09-27 17:26:57'),
(13, 'cat', 'อาหารเปียก vs อาหารเม็ด: แบบไหนดีที่สุดสำหรับแมวของคุณ?', '<img src=\"/admin/uploads/article_1759012072_3780.jpg\" alt=\"0\" style=\"max-width: 100%; height: auto;\">ทั้งอาหารเปียกและอาหารเม็ดต่างก็มีข้อดีข้อเสียที่แตกต่างกัน อาหารเปียกมีปริมาณน้ำสูง ช่วยให้แมวได้รับน้ำเพียงพอและลดความเสี่ยงของโรคทางเดินปัสสาวะ ในขณะที่อาหารเม็ดสะดวกในการให้และช่วยขัดฟันได้ในระดับหนึ่ง การให้อาหารแบบผสมผสาน (Mixed Feeding) อาจเป็นทางเลือกที่ดีที่สุด โดยให้อาหารเปียกเป็นมื้อหลักและมีอาหารเม็ดวางไว้ให้กินระหว่างวัน ปรึกษาสัตวแพทย์เพื่อเลือกสูตรที่เหมาะสมกับแมวของคุณ', 'อาหารแมว, โภชนาการ, อาหารเปียก, อาหารเม็ด', NULL, '2025-09-22', 1, '2025-09-27 20:16:09', '2025-09-27 17:28:02'),
(16, 'cat', 'วิธีเลือกกระบะทรายแมวที่เหมาะกับแมว เพื่อเก็บกลิ่นที่ดี', '<p><strong><span class=\"NormalTextRun SCXW261090711 BCX8\"><span class=\"NormalTextRun SCXW94073908 BCX8\">กระบะทรายแมว</span><span class=\"NormalTextRun SCXW94073908 BCX8\">เลือกอย่างไร</span><span class=\"NormalTextRun SCXW94073908 BCX8\">&hellip;</span><span class=\"NormalTextRun SCXW94073908 BCX8\">ให้ขับถ่ายสบายตัว</span></span></strong></p>\r\n<p><span class=\"NormalTextRun SCXW39623807 BCX8\">แมวก็ไม่ต่างกับคน</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">ที่จะเลือกของใช้ส่วนตัวทั้งที</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">ก็ต้องเอาให้ดีโดนใจผู้ใช้</span><span class=\"NormalTextRun SCXW39623807 BCX8\">เพื่อให้เจ้าตัวไม่รู้สึกอึดอัด</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">และใช้ของสิ่งนั้นได้นาน</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">ๆ</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">อย่างเช่นการเลือก</span><span class=\"NormalTextRun SCXW39623807 BCX8\">&ldquo;</span><span class=\"NormalTextRun SCXW39623807 BCX8\">ห้องน้ำแมว</span><span class=\"NormalTextRun SCXW39623807 BCX8\">&rdquo;</span><span class=\"NormalTextRun SCXW39623807 BCX8\">หรือ</span><span class=\"NormalTextRun SCXW39623807 BCX8\">&ldquo;</span><span class=\"NormalTextRun SCXW39623807 BCX8\">กระบะทรายแมว</span><span class=\"NormalTextRun SCXW39623807 BCX8\">&rdquo;</span><span class=\"NormalTextRun SCXW39623807 BCX8\">ให้น้องแมวขับถ่ายคล่องฟินไม่มีสะดุด</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">วันนี้</span><span class=\"NormalTextRun SCXW39623807 BCX8\">PET &lsquo;N ME&nbsp;</span><span class=\"NormalTextRun SCXW39623807 BCX8\">มีข้อสังเกตง่าย</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">ๆ</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">มานำเสนอว่า</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">ห้องน้ำ</span>&nbsp;<span class=\"NormalTextRun SCXW39623807 BCX8\">และ</span><span class=\"NormalTextRun SCXW39623807 BCX8\">ทรายแมว</span><span class=\"NormalTextRun SCXW39623807 BCX8\">แบบไหนถึงจะใช่กับสไตล์น้องแมวของคุณกันนะ</span></p>\r\n<p><strong><span class=\"NormalTextRun SCXW265998845 BCX8\">กระบะทรายแมวแบบเปิด</span></strong></p>\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"TEOHQPY\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"IGCFC3F\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"CWJFMO1\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"VFR83JS\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"SFPLNES\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"JKQ43O9\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"N1BXCR6\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"LTK9MHN\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<p><img class=\"aligncenter wp-image-3940 size-full entered lazyloaded\" src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_2.webp\" sizes=\"(max-width: 1080px) 100vw, 1080px\" srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-600x336.webp 600w\" alt=\"litter_2\" width=\"1080\" height=\"605\" data-lazy-srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_2-600x336.webp 600w\" data-lazy-sizes=\"(max-width: 1080px) 100vw, 1080px\" data-lazy-src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_2.webp\" data-ll-status=\"loaded\"></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<p><span data-contrast=\"none\">กระบะทรายแบบเปิด</span><span data-contrast=\"none\">&nbsp;:&nbsp;</span><span data-contrast=\"none\">เหมาะสำหรับน้องแมวที่ชอบกลบทราย</span>&nbsp;<span data-contrast=\"none\">เพราะแบบนี้จะมีความกว้าง</span>&nbsp;<span data-contrast=\"none\">และไม่มีกรอบอะไรมาขัดขวางการขุดของน้องแมวได้</span>&nbsp;<span data-contrast=\"none\">สามารถเดินเข้าออกสะดวก</span>&nbsp;<span data-contrast=\"none\">นอกจากนี้ยังทำความสะอาดง่าย</span>&nbsp;<span data-contrast=\"none\">จะเปลี่ยนทรายบ่อยแค่ไหนก็สบายทาสอย่างเราสุด</span>&nbsp;<span data-contrast=\"none\">ๆ</span>&nbsp;<span data-contrast=\"none\">แต่อาจจะต้องมีพื้นที่สำหรับการตั้ง</span>&nbsp;<span data-contrast=\"none\">เพื่อให้อากาศถ่ายเทคล่อง</span></p>\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"TEOHQPY\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"IGCFC3F\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"CWJFMO1\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"VFR83JS\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"SFPLNES\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"JKQ43O9\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"N1BXCR6\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"LTK9MHN\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<h2><span id=\"%E0%B8%81%E0%B8%A3%E0%B8%B0%E0%B8%9A%E0%B8%B0%E0%B8%97%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B9%81%E0%B8%A1%E0%B8%A7%E0%B9%81%E0%B8%9A%E0%B8%9A%E0%B8%9B%E0%B8%B4%E0%B8%94\" class=\"ez-toc-section\"></span><strong><span class=\"NormalTextRun SCXW90007936 BCX8\">กระบะทรายแมวแบบปิด</span></strong></h2>\r\n<p><img class=\"aligncenter wp-image-3939 size-full entered lazyloaded\" src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_3.webp\" sizes=\"(max-width: 1080px) 100vw, 1080px\" srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-600x336.webp 600w\" alt=\"litter_3\" width=\"1080\" height=\"605\" data-lazy-srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_3-600x336.webp 600w\" data-lazy-sizes=\"(max-width: 1080px) 100vw, 1080px\" data-lazy-src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_3.webp\" data-ll-status=\"loaded\"></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"TEOHQPY\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"IGCFC3F\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"CWJFMO1\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"VFR83JS\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"SFPLNES\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"JKQ43O9\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<div data-content-type=\"row\" data-appearance=\"contained\" data-element=\"main\">\r\n<div data-enable-parallax=\"0\" data-parallax-speed=\"0.5\" data-background-images=\"{}\" data-background-type=\"image\" data-video-loop=\"true\" data-video-play-only-visible=\"true\" data-video-lazy-load=\"true\" data-video-fallback-src=\"\" data-element=\"inner\" data-pb-style=\"N1BXCR6\">\r\n<div class=\"pagebuilder-column-group\" data-content-type=\"column-group\" data-grid-size=\"12\" data-element=\"main\">\r\n<div class=\"pagebuilder-column\" data-content-type=\"column\" data-appearance=\"full-height\" data-background-images=\"{}\" data-element=\"main\" data-pb-style=\"LTK9MHN\">\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<p><span class=\"NormalTextRun SCXW233963699 BCX8\">กระบะทรายแบบปิด</span><span class=\"NormalTextRun SCXW233963699 BCX8\">&nbsp;:&nbsp;</span><span class=\"NormalTextRun SCXW233963699 BCX8\">สำหรับน้องเหมียวขี้อาย</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">หรือตกใจง่ายที่ต้องการพื้นที่ส่วนตัว</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เพราะรุ่นนี้จะมีที่ครอบด้านบนแบบระบายอากาศ</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">แต่ก็ยังปกปิดได้ดี</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">และยังสามารถช่วยควบคุมกลิ่นสำหรับพื้นที่เลี้ยงขนาดจำกัด</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เช่น</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">คอนโด</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">หรือห้องเดี่ยว</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">หมดกังวลเรื่องกลิ่นไปได้เลย</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">แต่ไม่ว่าจะเลือกแบบไหน</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ก็อย่าลืม</span><span class=\"NormalTextRun SCXW233963699 BCX8\">!!&nbsp;</span><span class=\"NormalTextRun SCXW233963699 BCX8\">เช็กขนาดของตัวน้องแมว</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">และกระบะทรายว่า</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เพียงพอต่อการขยับตัวระหว่างทำธุระหรือไม่</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ซึ่งควรเลือกขนาดความสูงของผนังกระบะทรายอยู่ที่</span><span class=\"NormalTextRun SCXW233963699 BCX8\">5-7&nbsp;</span><span class=\"NormalTextRun SCXW233963699 BCX8\">นิ้ว</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เป็นอย่างต่ำ</span><span class=\"LineBreakBlob BlobObject DragDrop SCXW233963699 BCX8\"><span class=\"SCXW233963699 BCX8\"><br></span><br class=\"SCXW233963699 BCX8\"></span><span class=\"NormalTextRun SCXW233963699 BCX8\">สำหรับน้องแมวขนาดตัวทั่วไป</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เพื่อให้หางของน้องไม่โผล่ออกมา</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ไม่รู้สึกอึดอัด</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">และสามารถขับถ่ายได้คล่องตัว</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ที่สำคัญจะต้องไม่ลืมตรวจสอบกระบะทรายระหว่างที่มีการใช้งานอย่างสม่ำเสมอว่า</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ชำรุดส่วนไหนบ้างจากรอยขีดข่วน</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">หรือการกัดกร่อนจากปัสสาวะแมวที่เป็นกรด</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">หากพบเจอควรทำการเปลี่ยนกระบะใหม่ทันที</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">เพื่อให้ห้องน้ำของน้อง</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">ๆ</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">สะอาด</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">น่าใช้</span>&nbsp;<span class=\"NormalTextRun SCXW233963699 BCX8\">และไม่เป็นแหล่งสะสมเชื้อโรคชั้นดีที่จะมีอันตรายต่อสุขภาพภายหลัง</span></p>\r\n<h2><span id=\"%E0%B8%9B%E0%B8%A3%E0%B8%B0%E0%B9%80%E0%B8%A0%E0%B8%97%E0%B8%82%E0%B8%AD%E0%B8%87%E0%B8%97%E0%B8%A3%E0%B8%B2%E0%B8%A2%E0%B9%81%E0%B8%A1%E0%B8%A7\" class=\"ez-toc-section\"></span><strong>ประเภทของทรายแมว</strong></h2>\r\n<p><span data-contrast=\"none\">กระบะทรายตรงใจน้องเหมียวแล้ว</span>&nbsp;<span data-contrast=\"none\">ก็ควรเลือกวัสดุเม็ดทรายให้ตรงตามลักษณะการใช้งานของน้องแมว</span>&nbsp;<span data-contrast=\"none\">และความสะดวกของผู้เลี้ยง</span>&nbsp;<span data-contrast=\"none\">ด้วยความที่จุดเด่นของแต่ละชนิดไม่เหมือนกัน</span></p>\r\n<p><img class=\"aligncenter wp-image-3938 size-full entered lazyloaded\" src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_4.webp\" sizes=\"(max-width: 1080px) 100vw, 1080px\" srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-600x336.webp 600w\" alt=\"litter_4\" width=\"1080\" height=\"605\" data-lazy-srcset=\"https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4.webp 1080w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-300x168.webp 300w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-1024x574.webp 1024w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-768x430.webp 768w, https://www.petnme.co.th/wp-content/uploads/2024/02/litter_4-600x336.webp 600w\" data-lazy-sizes=\"(max-width: 1080px) 100vw, 1080px\" data-lazy-src=\"https://petnme.co.th/wp-content/uploads/2024/02/litter_4.webp\" data-ll-status=\"loaded\"></p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n<div data-content-type=\"text\" data-appearance=\"default\" data-element=\"main\">\r\n<h3><strong><span data-contrast=\"none\">1.</span></strong><strong><span data-contrast=\"none\">ทรายแมวแบบไม่จับตัว</span></strong><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:0,&quot;335559740&quot;:240}\">&nbsp;</span></h3>\r\n<p><span data-contrast=\"none\">เหมาะสำหรับบ้านที่ต้องการใช้ปริมาณเยอะกับแมวหลายตัว</span>&nbsp;<span data-contrast=\"none\">หรือเลี้ยงแมวในกรง</span>&nbsp;<span data-contrast=\"none\">เพราะราคาถูก</span>&nbsp;<span data-contrast=\"none\">และดูดซึมได้ดี</span>&nbsp;<span data-contrast=\"none\">แต่ตัวเม็ดทรายจะไม่จับตัวเป็นก้อนเมื่อสัมผัสของเหลว</span>&nbsp;<span data-contrast=\"none\">จึงยากต่อการทำความสะอาดกระบะทราย</span><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:150,&quot;335559740&quot;:240}\">&nbsp;</span></p>\r\n<h3><strong><span data-contrast=\"none\">2.</span></strong><strong><span data-contrast=\"none\">ทรายแมวแบบจับตัวเป็นก้อน</span></strong><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:0,&quot;335559740&quot;:240}\">&nbsp;</span></h3>\r\n<p><span data-contrast=\"none\">ไม่เหมาะกับแมวที่แพ้ฝุ่น</span>&nbsp;<span data-contrast=\"none\">เพราะมีส่วนประกอบของเบนโทไนต์</span><span data-contrast=\"none\">&nbsp;(Bentonite)&nbsp;</span><span data-contrast=\"none\">เป็นหลัก</span>&nbsp;<span data-contrast=\"none\">ที่เมื่อแตกกระจายจะทำให้เกิดฝุ่นคลุ้ง</span>&nbsp;<span data-contrast=\"none\">และติดเท้าแมว</span>&nbsp;<span data-contrast=\"none\">แต่ข้อดีคือเมื่อทรายโดนความชื้นจะจับตัวเป็นก้อนได้เร็ว</span>&nbsp;<span data-contrast=\"none\">ง่ายต่อการตักทิ้ง</span><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:150,&quot;335559740&quot;:240}\">&nbsp;</span></p>\r\n<h3><strong><span data-contrast=\"none\">3.</span></strong><strong><span data-contrast=\"none\">ทรายแมวแบบย่อยสลาย</span></strong><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:0,&quot;335559740&quot;:240}\">&nbsp;</span></h3>\r\n<p><span data-contrast=\"none\">เหมาะกับแมวที่แพ้ง่าย</span>&nbsp;<span data-contrast=\"none\">ชอบเลีย</span>&nbsp;<span data-contrast=\"none\">ชอบคุ้ย</span>&nbsp;<span data-contrast=\"none\">หรือเลี้ยงใกล้ชิดกับคน</span>&nbsp;<span data-contrast=\"none\">เพราะทำมาจากวัสดุธรรมชาติ</span>&nbsp;<span data-contrast=\"none\">เช่น</span>&nbsp;<span data-contrast=\"none\">เศษไม้สน</span>&nbsp;<span data-contrast=\"none\">เต้าหู้</span>&nbsp;<span data-contrast=\"none\">ขี้เลื่อย</span>&nbsp;<span data-contrast=\"none\">ฯลฯ</span>&nbsp;<span data-contrast=\"none\">ซึ่งเป็นมิตรต่อสิ่งแวดล้อม</span>&nbsp;<span data-contrast=\"none\">สามารถดูดซึมน้ำได้ในปริมาณที่มาก</span>&nbsp;<span data-contrast=\"none\">และยังช่วยลดกลิ่นเหม็นได้ดี</span>&nbsp;<span data-contrast=\"none\">แต่จะมีราคาค่อนข้างสูงกว่าทรายแมวทั่วไป</span><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:150,&quot;335559740&quot;:240}\">&nbsp;</span></p>\r\n<h3><strong><span data-contrast=\"none\">4.</span></strong><strong><span data-contrast=\"none\">ทรายคริสตัล</span></strong><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:0,&quot;335559740&quot;:240}\">&nbsp;</span></h3>\r\n<p><span data-contrast=\"none\">เหมาะกับแมวที่มีกลิ่นปัสสาวะแรงฉุน</span>&nbsp;<span data-contrast=\"none\">เพราะผลิตจากซิลิก้าเจล</span>&nbsp;<span data-contrast=\"none\">ช่วยดูดซับกลิ่นดี</span>&nbsp;<span data-contrast=\"none\">ใช้ได้นาน</span>&nbsp;<span data-contrast=\"none\">และมีน้ำหนักเบา</span>&nbsp;<span data-contrast=\"none\">แต่ควรระวังเล็กน้อย</span>&nbsp;<span data-contrast=\"none\">เพราะสามารถติดตามขนของน้องแมวได้</span>&nbsp;<span data-contrast=\"none\">ทำให้ไม่เหมาะกับแมวขนยาว</span><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:150,&quot;335559740&quot;:240}\">&nbsp;</span></p>\r\n<h3><strong><span data-contrast=\"none\">5.</span></strong><strong><span data-contrast=\"none\">ทรายแมวซีโอไลท์</span></strong><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:0,&quot;335559740&quot;:240}\">&nbsp;</span></h3>\r\n<p><span data-contrast=\"none\">มีคุณสมบัติดูดกลิ่น</span>&nbsp;<span data-contrast=\"none\">และแห้งไว</span>&nbsp;<span data-contrast=\"none\">ใช้คู่กับแผ่นรองซับ</span>&nbsp;<span data-contrast=\"none\">เก็บกลิ่นช่วยดูดซึมซับของเหลวถึง</span><span data-contrast=\"none\">&nbsp;2&nbsp;</span><span data-contrast=\"none\">น</span>&nbsp;<span data-contrast=\"none\">เปลี่ยนง่ายไม่ต้องตักทราย</span>&nbsp;<span data-contrast=\"none\">นอกจากนี้ยังติดเท้าน้องแมวยากด้วยนะ</span>&nbsp;<span data-contrast=\"none\">เหมาะกับน้องแมวทานเก่ง</span>&nbsp;<span data-contrast=\"none\">หรือปัสสาวะบ่อย</span>&nbsp;<span data-contrast=\"none\">และเลี้ยงในบ้าน</span>&nbsp;<span data-contrast=\"none\">หรือคอนโด</span><span data-ccp-props=\"{&quot;201341983&quot;:0,&quot;335559739&quot;:150,&quot;335559740&quot;:240}\">&nbsp;</span></p>\r\n<p><span data-contrast=\"none\">เพื่อทำให้การขับถ่ายของน้องแมวในทุก</span>&nbsp;<span data-contrast=\"none\">ๆ</span>&nbsp;<span data-contrast=\"none\">วันมีความสุข</span>&nbsp;<span data-contrast=\"none\">สบายตัว</span>&nbsp;<span data-contrast=\"none\">จึงต้องเลือกให้เหมาะกับลักษณะนิสัยของน้องแมวมากที่สุด</span>&nbsp;<span data-contrast=\"none\">เพราะคุณคือคนที่รู้ใจน้องแมวดีกว่าใครเลยแหละ</span><span data-contrast=\"none\">&nbsp;&ldquo;</span><span data-contrast=\"none\">ความสุข</span>&nbsp;<span data-contrast=\"none\">และสุขภาพที่ดีของเจ้าเหมียว</span>&nbsp;<span data-contrast=\"none\">ก็คือรอยยิ้มของเรา</span><span data-contrast=\"none\">&nbsp;(:&rdquo;</span></p>\r\n</div>', 'การเลี้ยงดู', 'https://www.petnme.co.th/how-to-choose-the-litter-boxes-for-your-cats/', '2025-10-14', 1, '2025-10-13 21:35:28', '2025-10-14 01:00:04');

-- --------------------------------------------------------

--
-- Table structure for table `article_images`
--

CREATE TABLE `article_images` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `url` varchar(512) NOT NULL,
  `position` enum('top','inline','bottom') NOT NULL DEFAULT 'top',
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `caption` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `article_images`
--

INSERT INTO `article_images` (`id`, `article_id`, `url`, `position`, `sort_order`, `caption`, `created_at`) VALUES
(1, 2, 'uploads/article_1758984818_2536.jpg', 'top', 0, '0', '2025-09-27 14:53:38'),
(2, 2, 'uploads/article_1758984835_2521.jpg', 'inline', 1, '0', '2025-09-27 14:53:55'),
(3, 4, 'uploads/article_1759008335_6893.jpg', 'top', 0, '0', '2025-09-27 21:25:35'),
(4, 4, 'uploads/article_1759008358_2091.jpg', 'bottom', 1, '0', '2025-09-27 21:25:58'),
(5, 1, 'uploads/article_1759008980_7449.jpg', 'top', 1, '0', '2025-09-27 21:36:20'),
(6, 5, 'uploads/article_1759009095_8907.jpg', 'top', 0, '0', '2025-09-27 21:38:15'),
(7, 5, 'uploads/article_1759009197_4866.jpg', 'inline', 1, '0', '2025-09-27 21:39:57'),
(8, 6, 'uploads/article_1759011513_3154.jpg', 'top', 0, '0', '2025-09-27 22:18:33'),
(9, 7, 'uploads/article_1759011647_1634.jpg', 'top', 0, '0', '2025-09-27 22:20:47'),
(10, 8, 'uploads/article_1759011715_8922.jpg', 'top', 0, '0', '2025-09-27 22:21:55'),
(11, 9, 'uploads/article_1759011813_8758.jpg', 'top', 0, '0', '2025-09-27 22:23:33'),
(12, 10, 'uploads/article_1759011873_3052.jpg', 'top', 0, '0', '2025-09-27 22:24:33'),
(13, 11, 'uploads/article_1759011940_4085.jpg', 'top', 0, '0', '2025-09-27 22:25:40'),
(14, 12, 'uploads/article_1759012006_4454.jpg', 'top', 0, '0', '2025-09-27 22:26:46'),
(15, 13, 'uploads/article_1759012072_3780.jpg', 'top', 0, '0', '2025-09-27 22:27:52');

-- --------------------------------------------------------

--
-- Table structure for table `breeds`
--

CREATE TABLE `breeds` (
  `breed_id` int(10) UNSIGNED NOT NULL,
  `name_th` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `species_id` tinyint(3) UNSIGNED NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `breeds`
--

INSERT INTO `breeds` (`breed_id`, `name_th`, `name_en`, `species_id`, `is_active`) VALUES
(1, 'ไทยหลังอาน', 'Thai Ridgeback', 1, 1),
(2, 'ชิสุ', 'Shih Tzu', 1, 1),
(3, 'พุดเดิ้ล', 'Poodle', 1, 1),
(4, 'เปอร์เซีย', 'Persian', 2, 1),
(5, 'ไทยวิเชียรมาศ', 'Siamese', 2, 1),
(6, 'สฟิงซ์', 'Sphynx', 2, 1),
(7, 'โกลเด้น รีทรีฟเวอร์', 'Golden Retriever', 1, 1),
(8, 'ลาบราดอร์ รีทรีฟเวอร์', 'Labrador Retriever', 1, 1),
(9, 'เฟรนช์ บูลด็อก', 'French Bulldog', 1, 1),
(10, 'ปอมเมอเรเนียน', 'Pomeranian', 1, 1),
(11, 'ชิวาวา', 'Chihuahua', 1, 1),
(12, 'ไซบีเรียน ฮัสกี้', 'Siberian Husky', 1, 1),
(13, 'บีเกิ้ล', 'Beagle', 1, 1),
(14, 'ปั๊ก', 'Pug', 1, 1),
(15, 'เยอรมันเชพเพิร์ด', 'German Shepherd', 1, 1),
(16, 'เพมโบรค เวลช์ คอร์กี้', 'Pembroke Welsh Corgi', 1, 1),
(17, 'แจ็ครัสเซล เทอร์เรียร์', 'Jack Russell Terrier', 1, 1),
(18, 'ไทยบางแก้ว', 'Thai Bangkaew', 1, 1),
(19, 'ชิบะ อินุ', 'Shiba Inu', 1, 1),
(20, 'อิงลิช บูลด็อก', 'English Bulldog', 1, 1),
(21, 'สก็อตติชโฟลด์', 'Scottish Fold', 2, 1),
(22, 'บริติชชอร์ตแฮร์', 'British Shorthair', 2, 1),
(23, 'อเมริกันชอร์ตแฮร์', 'American Shorthair', 2, 1),
(24, 'เมนคูน', 'Maine Coon', 2, 1),
(25, 'เอ็กโซติก ชอร์ตแฮร์', 'Exotic Shorthair', 2, 1),
(26, 'แร็กดอลล์', 'Ragdoll', 2, 1),
(27, 'เบงกอล', 'Bengal', 2, 1),
(28, 'รัสเซียนบลู', 'Russian Blue', 2, 1),
(29, 'มันช์กิ้น', 'Munchkin', 2, 1),
(30, 'โคราช', 'Korat', 2, 1),
(31, 'ขาวมณี', 'Khao Manee', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `post_type` enum('fh','fp') NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `user` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `post_type`, `parent_id`, `user`, `content`, `created_at`) VALUES
(1, 9, 'fp', NULL, 'npdgame2', 'มีอยู่1ตัว', '2025-08-20 18:57:25'),
(3, 9, 'fp', 1, 'npdgame', 'ขอแชทไปนะครับ', '2025-09-01 17:04:45'),
(4, 17, 'fp', NULL, 'npdgame2', 'Hi yt', '2025-09-29 22:48:54'),
(5, 12, 'fh', NULL, 'npdgame', 'น่ารักจัง', '2025-09-29 23:02:35'),
(6, 12, 'fh', 5, 'npdgame', '😘', '2025-09-29 23:02:56'),
(7, 11, 'fp', NULL, 'npdgame2', 'มีครับ', '2025-10-05 02:05:41'),
(8, 1, 'fh', NULL, 'npdgame', 'ไม่มีรูปหรอครับ', '2025-10-05 02:34:29'),
(9, 1, 'fh', 8, 'npdgame2', 'แชทมาครับ', '2025-10-05 02:50:16'),
(10, 1, 'fh', NULL, 'npdgame', 'Test', '2025-10-05 02:50:56'),
(11, 12, 'fh', 6, 'npdgame', 'Test', '2025-10-05 03:29:10'),
(12, 11, 'fp', 7, 'npdgame', 'แชท', '2025-10-05 03:30:01');

-- --------------------------------------------------------

--
-- Table structure for table `comment_likes`
--

CREATE TABLE `comment_likes` (
  `id` int(10) UNSIGNED NOT NULL,
  `comment_id` int(10) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fhome`
--

CREATE TABLE `fhome` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `breed` varchar(100) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `age` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `steriliz` varchar(255) NOT NULL,
  `vaccine` varchar(255) NOT NULL,
  `personality` text NOT NULL,
  `reason` text NOT NULL,
  `adoptionTerms` text NOT NULL,
  `image` text NOT NULL,
  `user` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `postType` varchar(20) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fhome`
--

INSERT INTO `fhome` (`id`, `title`, `type`, `breed`, `sex`, `age`, `color`, `steriliz`, `vaccine`, `personality`, `reason`, `adoptionTerms`, `image`, `user`, `status`, `postType`, `post_date`) VALUES
(1, 'หาบ้านพุดเดิ้ล', 'หมา', 'พุดเดิ้ล', 'ผู้', '2 เดือน', 'น้ำตาล', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'เข้ากับคนง่าย, รักเด็ก', 'ย้ายที่อยู่', 'บ้านต้องมีรั้ว/ปลอดภัย, ยินดีทำหมันเมื่อถึงวัยอันควร', '[\"media_68c07472bc171.jpeg\"]', 'npdgame2', 'active', 'fh', '2025-09-27 22:32:13'),
(2, 'หาบ้านให้น้องดำหลงค่ะ', 'หมา', 'ไซบีเรียน ฮัสกี้', 'ผู้', '1 ปี', 'ดำ', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'ฉลาด/เรียนรู้ไว', 'เก็บได้/พลัดหลง', 'บ้านต้องมีรั้ว/ปลอดภัย', '[\"uploads\\/media_68e32924519d9.jpeg\"]', 'npdgame2', 'active', 'fh', '2025-10-06 02:27:48'),
(3, 'หาบ้านให้บลูด็อก', 'หมา', 'อิงลิช บูลด็อก', 'ผู้', '2 เดือน', 'น้ำตาล', 'ทำหมันแล้ว', 'โรคพิษสุนัขบ้า', 'ขี้อ้อน, ขี้เล่น, ฉลาด/เรียนรู้ไว', 'ย้ายที่อยู่', 'บ้านต้องมีรั้ว/ปลอดภัย', '[\"media_68edb24f2af60.jpeg\",\"media_68edb24f2b404.jpeg\"]', 'npdgame2', 'active', 'fh', '2025-10-14 07:44:20'),
(4, 'หมาสามสี', 'หมา', 'ปั๊ก', 'ผู้', '', 'สามสี', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'ขี้เล่น', 'ย้ายที่อยู่', 'ยินยอมให้ตรวจเยี่ยมหลังรับเลี้ยง', '[\"media_68ee0a6e46855.jpeg\"]', 'npdgame2', 'active', 'fh', '2025-10-17 15:35:09'),
(10, 'ไทยหลังอานสีดำหาบ้าน', 'หมา', 'ไทยหลังอาน', 'ผู้', '1 ปี', 'ดำ', 'ทำหมันแล้ว', 'วัคซีนป้องกันโรคไข้หัด, โรคลำไส้อักเสบ, โรคพิษสุนัขบ้า', 'รักเด็ก', 'เก็บได้/พลัดหลง', 'พร้อมดูแลวัคซีน/สุขภาพประจำปี', '[\"media_68b88f919b586.mp4\"]', 'npdgame2', 'active', 'fh', '2025-09-27 22:31:18'),
(12, 'หาบ้านให้เปอร์เซีย', 'แมว', 'เปอร์เซีย', 'เมีย', '7 เดือน', 'ขาว', 'ยังไม่ได้ทำหมัน', 'โรคลิวคีเมีย, โรคพิษสุนัขบ้า, วัคซีนป้องกันโรคไข้หัด', 'เงียบ/เรียบร้อย', 'ย้ายที่อยู่', 'ยินยอมให้ตรวจเยี่ยมหลังรับเลี้ยง, พร้อมดูแลวัคซีน/สุขภาพประจำปี, ยินดีทำหมันเมื่อถึงวัยอันควร', '[\"media_68b89a52152d4.jpg\",\"media_68b931d6f2cec.jpg\",\"media_68b9324764abd.mp4\"]', 'npdgame2', 'active', 'fh', '2025-09-29 18:09:42'),
(18, 'พุดเดิ้ลสีน้ำตาลหาบ้านด่วน', 'หมา', 'พุดเดิ้ล', 'เมีย', '7 เดือน', 'น้ำตาล', 'ยังไม่ได้ทำหมัน', 'วัคซีนป้องกันโรคไข้หัด, โรคพิษสุนัขบ้า', 'ขี้เล่น, เข้ากับคนง่าย, รักเด็ก', 'ย้ายที่อยู่', 'บ้านต้องมีรั้ว/ปลอดภัย, พร้อมดูแลวัคซีน/สุขภาพประจำปี, ยินดีทำหมันเมื่อถึงวัยอันควร', '[\"uploads/media_poodle1.jpg\",\"uploads/media_poodle2.jpg\"]', 'mint.home', 'hidden', 'fh', '2025-10-14 00:09:12'),
(19, 'โกลเด้น รีทรีฟเวอร์ ขนสวยสุขภาพดี', 'หมา', 'โกลเด้น รีทรีฟเวอร์', 'ผู้', '1 ปี 2 เดือน', 'ทอง', 'ทำหมันแล้ว', 'วัคซีนรวม 5 โรค (ไข้หัด, ตับอักเสบ, ลำไส้อักเสบ, พาราอินฟลูเอนซา, เลปโตสไปโรซิส), โรคพิษสุนัขบ้า', 'ขี้เล่น, รักเด็ก, เป็นมิตรกับสัตว์อื่น', 'เจ้าของมีปัญหาสุขภาพ/เวลา', 'ต้องมีรั้วรอบบ้าน, พร้อมดูแลวัคซีน/สุขภาพประจำปี', '[\"uploads/media_golden1.jpg\"]', 'jane.dual', 'active', 'fh', '2025-09-17 19:42:29'),
(20, 'เปอร์เซียสีขาว ตาใส ขี้อ้อน', 'แมว', 'เปอร์เซีย', 'เมีย', '8 เดือน', 'ขาว', 'ยังไม่ได้ทำหมัน', 'โรคลิวคีเมีย, โรคระบบทางเดินหายใจส่วนต้น, โรคพิษสุนัขบ้า', 'ขี้อ้อน, เงียบ/เรียบร้อย', 'เก็บได้/พลัดหลง', 'ยินยอมให้ตรวจเยี่ยมหลังรับเลี้ยง, พร้อมดูแลวัคซีน/สุขภาพประจำปี', '[\"uploads/media_persian1.jpg\",\"uploads/media_persian2.jpg\"]', 'noon.home', 'active', 'fh', '2025-09-17 19:42:29'),
(21, 'ไทยหลังอาน ชอบวิ่งเล่น เฝ้าบ้านเก่ง', 'หมา', 'ไทยหลังอาน', 'ผู้', '10 เดือน', 'ดำ', 'ทำหมันแล้ว', 'วัคซีนป้องกันโรคไข้หัด, วัคซีนป้องกันโรคเลปโตสไปโรซิส, โรคพิษสุนัขบ้า', 'พลังงานสูง, เฝ้าบ้านเก่ง, ซื่อสัตย์', 'ปัญหาการเงิน', 'ต้องมีรั้วรอบบ้าน, ต้องมีสนามหญ้า/พื้นที่เล่น', '[\"uploads/media_thairidge1.jpg\"]', 'aom.dual', 'active', 'fh', '2025-09-17 19:42:29');

-- --------------------------------------------------------

--
-- Table structure for table `fpet`
--

CREATE TABLE `fpet` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(50) NOT NULL,
  `breed` varchar(100) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `min_age` varchar(255) NOT NULL,
  `max_age` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `steriliz` varchar(255) NOT NULL,
  `vaccine` varchar(255) NOT NULL,
  `environment` varchar(255) NOT NULL,
  `user` varchar(255) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `postType` varchar(20) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fpet`
--

INSERT INTO `fpet` (`id`, `title`, `type`, `breed`, `sex`, `min_age`, `max_age`, `color`, `steriliz`, `vaccine`, `environment`, `user`, `status`, `postType`, `post_date`) VALUES
(1, 'หาน้องพุดเดิ้ล', 'หมา', 'พุดเดิ้ล', 'ผู้', '0 ปี 2 เดือน', '0 ปี 6 เดือน', 'ทอง, น้ำตาล', 'ทำหมันแล้ว', 'โรคพิษสุนัขบ้า, โรคตับอักเสบ', 'บ้านเดี่ยว, มีรั้วรอบบ้าน', 'npdgame', 'active', 'fp', '2025-09-23 16:11:19'),
(2, 'ต้องการหมาเฝ้าบ้านได้อายุไม่เกิน1ปี', 'หมา', 'ไซบีเรียน ฮัสกี้', 'ผู้', '1 ปี 0 เดือน', '1 ปี 0 เดือน', 'ดำ, ขาว, ขาว-ดำ', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'บ้านพร้อมสนามกว้าง', 'npdgame', 'active', 'fp', '2025-10-06 02:30:36'),
(3, 'หาน้องบูลด็อก2เดือน', 'หมา', 'อิงลิช บูลด็อก', 'ผู้', '0 ปี 2 เดือน', '0 ปี 5 เดือน', 'ขาว, ครีม', 'ยังไม่ได้ทำหมัน', 'โรคพิษสุนัขบ้า', 'อพาร์ตเมนต์ที่อนุญาตสัตว์เลี้ยง', 'นาย b', 'active', 'fp', '2025-10-14 00:20:19'),
(4, 'สแปมโพส', 'แมว', 'สฟิงซ์', 'ผู้', '0 ปี 6 เดือน', '0 ปี 6 เดือน', 'ส้ม', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'คอนโด/อพาร์ตเมนต์', 'นาย b', 'hidden', 'fp', '2025-10-16 16:35:31'),
(5, 'หาหมา', 'หมา', 'ปั๊ก', 'ผู้', '0 ปี 7 เดือน', '0 ปี 7 เดือน', 'สามสี', 'ยังไม่ได้ทำหมัน', 'ยังไม่ได้ฉีด', 'บ้านเดี่ยว', 'npdgame', 'active', 'fp', '2025-10-14 08:28:09'),
(9, 'หาน้องอเมริกันช็อตแฮร์', 'แมว', 'อเมริกันชอร์ตแฮร์', 'เมีย', '0 ปี 5 เดือน', '0 ปี 5 เดือน', 'ขาว, ส้ม', 'ยังไม่ได้ทำหมัน', 'ครบ, วัคซีนป้องกันโรคไข้หัด, โรคระบบทางเดินหายใจส่วนต้น, โรคลิวคีเมีย, โรคพิษสุนัขบ้า, โรคตับอักเสบ', 'บ้านมีรั้ว, มีรั้วรอบบ้าน', 'npdgame', 'active', 'fp', '2025-09-27 22:41:37'),
(11, 'แมวหนังไก่ น่ารัก ', 'แมว', 'สฟิงซ์', 'เมีย', '0 ปี 2 เดือน', '0 ปี 3 เดือน', 'น้ำตาล, ขาว', 'ยังไม่ได้ทำหมัน', 'โรคพิษสุนัขบ้า, วัคซีนป้องกันโรคเฮอร์ปีส์ไวรัส, วัคซีนรวม 4 โรคแมว (FVRCP + Chlamydophila)', 'บ้านเดี่ยว', 'npdgame', 'active', 'fp', '2025-09-30 02:52:19'),
(13, 'อยากรับเลี้ยงพุดเดิ้ล ขนสั้น สุขภาพดี', 'หมา', 'พุดเดิ้ล', 'เมีย', '0 ปี 2 เดือน', '2 ปี 0 เดือน', 'ขาว, ครีม', 'ทำหมันแล้ว', 'โรคพิษสุนัขบ้า', 'บ้านเดี่ยว, มีรั้วรอบบ้าน', 'boss.find', 'active', 'fp', '2025-09-17 19:42:29'),
(14, 'มองหาโกลเด้นนิสัยดีอยู่กับเด็กได้', 'หมา', 'โกลเด้น รีทรีฟเวอร์', 'ผู้', '0 ปี 6 เดือน', '3 ปี 0 เดือน', 'ทอง', 'ยังไม่ได้ทำหมัน', 'วัคซีนรวม 5 โรค (ไข้หัด, ตับอักเสบ, ลำไส้อักเสบ, พาราอินฟลูเอนซา, เลปโตสไปโรซิส), โรคพิษสุนัขบ้า', 'บ้านพร้อมสนามกว้าง, บ้านมีรั้วสูง', 'park.find', 'active', 'fp', '2025-09-17 19:42:29'),
(15, 'อยากได้เปอร์เซีย ขนสวย ขี้อ้อน', 'แมว', 'เปอร์เซีย', 'เมีย', '0 ปี 3 เดือน', '2 ปี 0 เดือน', 'ขาว', 'ยังไม่ได้ทำหมัน', 'FVRCP, โรคลิวคีเมีย', 'คอนโด/อพาร์ตเมนต์, อพาร์ตเมนต์ที่อนุญาตสัตว์เลี้ยง', 'beam.find', 'active', 'fp', '2025-09-17 19:42:29'),
(16, 'หาไทยหลังอาน สุขภาพแข็งแรง', 'หมา', 'ไทยหลังอาน', 'ผู้', '0 ปี 1 เดือน', '1 ปี 6 เดือน', 'ดำ, น้ำตาล', 'ทำหมันแล้ว', 'วัคซีนป้องกันโรคเลปโตสไปโรซิส, โรคพิษสุนัขบ้า', 'บ้านเดี่ยว, มีรั้วรอบบ้าน', 'ohm.dual', 'active', 'fp', '2025-09-17 19:42:29'),
(18, 'อยากรับเลี้ยงลาบราดอร์ เพื่อนวิ่งตอนเช้า', 'หมา', 'ลาบราดอร์ รีทรีฟเวอร์', 'ผู้', '0 ปี 4 เดือน', '2 ปี 6 เดือน', 'ดำ, น้ำตาล', 'ทำหมันแล้ว', 'วัคซีนรวม 6 โรค (DHPPiL+Corona), โรคพิษสุนัขบ้า', 'บ้านพร้อมสนามกว้าง, บ้านมีรั้วสูง', 'aom.dual', 'active', 'fp', '2025-09-17 19:42:29');

-- --------------------------------------------------------

--
-- Table structure for table `housing_types`
--

CREATE TABLE `housing_types` (
  `housing_id` smallint(5) UNSIGNED NOT NULL,
  `name_th` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `housing_types`
--

INSERT INTO `housing_types` (`housing_id`, `name_th`, `name_en`, `description`, `is_active`) VALUES
(1, 'บ้านเดี่ยว', 'Single House', 'มีพื้นที่ส่วนตัวสำหรับสัตว์เลี้ยง', 1),
(2, 'ทาวน์โฮม/ทาวน์เฮาส์', 'Townhome', 'อาจมีพื้นที่จำกัด เหมาะกับสัตว์เลี้ยงที่ไม่ต้องการพื้นที่มาก', 1),
(3, 'คอนโด/อพาร์ตเมนต์', 'Condominium', 'เหมาะกับสัตว์เลี้ยงขนาดเล็กที่สงบและมีการควบคุม', 1),
(4, 'มีรั้วรอบบ้าน', 'Fenced Yard', 'ช่วยป้องกันสัตว์เลี้ยงหลบหนีและเพิ่มความปลอดภัย', 1),
(5, 'มีสนามหญ้า/พื้นที่กว้าง', 'Yard/Spacious', 'เหมาะกับสัตว์เลี้ยงที่มีพลังงานสูงและต้องการพื้นที่วิ่งเล่น', 1),
(6, 'หอพัก', 'dormitory', 'ต้องตรวจสอบกฎระเบียบของหอพักอย่างเคร่งครัดเรื่องการเลี้ยงสัตว์', 1),
(7, 'คอนโด/อพาร์ตเมนต์ขนาดเล็ก', 'Small Condominium', 'เหมาะกับสัตว์เลี้ยงขนาดเล็ก เช่น ชิวาวา, แมวพันธุ์เล็ก', 1),
(8, 'บ้านพร้อมสนามกว้าง', 'House with Yard', 'เหมาะกับสุนัขพันธุ์ใหญ่/พลังงานสูง เช่น ลาบราดอร์, ไซบีเรียน ฮัสกี้', 1),
(9, 'บ้านมีรั้วสูง', 'Fenced House', 'ช่วยป้องกันสัตว์เลี้ยงหลบหนี เหมาะกับสุนัขทุกพันธุ์', 1),
(10, 'อพาร์ตเมนต์ที่อนุญาตสัตว์เลี้ยง', 'Pet-friendly Apartment', 'สำหรับผู้เช่าที่พักที่อนุญาตให้เลี้ยงสัตว์', 1);

-- --------------------------------------------------------

--
-- Table structure for table `personalities`
--

CREATE TABLE `personalities` (
  `personality_id` smallint(5) UNSIGNED NOT NULL,
  `name_th` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `species_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `personalities`
--

INSERT INTO `personalities` (`personality_id`, `name_th`, `name_en`, `description`, `species_id`, `is_active`) VALUES
(1, 'ขี้เล่น', 'Playful', 'ชอบทำกิจกรรม มีความกระตือรือร้น ชอบเล่นกับเจ้าของ', NULL, 1),
(2, 'เข้ากับคนง่าย', 'Friendly', 'เข้าหาคนแปลกหน้าหรือสัตว์อื่นได้ง่าย ไม่หวาดระแวง', NULL, 1),
(3, 'เงียบ/เรียบร้อย', 'Calm', 'ไม่ค่อยส่งเสียงดัง ชอบพักผ่อน ไม่วุ่นวาย', NULL, 1),
(4, 'พลังงานสูง', 'High Energy', 'ต้องการการออกกำลังกายและกิจกรรมกระตุ้นสูง', NULL, 1),
(5, 'รักเด็ก', 'Good with Children', 'อดทนกับเด็ก ไม่แสดงความก้าวร้าวต่อเด็กเล็ก', NULL, 1),
(7, 'ดื้อ', 'stubborn', 'ไม่ทำตามคำสั่งง่าย ๆ ต้องใช้ความพยายามในการฝึก', NULL, 1),
(8, 'ขี้อ้อน', 'Affectionate', 'ชอบอยู่ใกล้เจ้าของ รักความสนใจ', NULL, 1),
(9, 'ซื่อสัตย์', 'Loyal', 'ผูกพันกับเจ้าของสูง', 1, 1),
(10, 'ระแวง/ขี้กลัว', 'Shy/Timid', 'มักกลัวเสียงดังหรือคนแปลกหน้า', NULL, 1),
(11, 'เป็นมิตรกับสัตว์อื่น', 'Good with Other Pets', 'เข้ากับสัตว์เลี้ยงตัวอื่นได้ดี', NULL, 1),
(12, 'เฝ้าบ้านเก่ง', 'Protective', 'ระวังภัย เก่งเรื่องปกป้องบ้าน', 1, 1),
(13, 'อยากรู้อยากเห็น', 'Curious', 'ชอบสำรวจสิ่งใหม่ ๆ', NULL, 1),
(14, 'ฉลาด/เรียนรู้ไว', 'Intelligent', 'ฝึกง่าย ตอบสนองเร็ว', NULL, 1),
(15, 'สงบเยือกเย็น', 'Laid-back', 'ไม่ค่อยตื่นเต้นง่าย ๆ', 2, 1),
(16, 'ดื้อเงียบ', 'Independent', 'รักอิสระ ทำตามใจตัวเอง', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pet_species`
--

CREATE TABLE `pet_species` (
  `species_id` tinyint(3) UNSIGNED NOT NULL,
  `code` varchar(16) NOT NULL,
  `name_th` varchar(64) NOT NULL,
  `name_en` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pet_species`
--

INSERT INTO `pet_species` (`species_id`, `code`, `name_th`, `name_en`) VALUES
(1, 'dog', 'หมา', 'Dog'),
(2, 'cat', 'แมว', 'Cat');

-- --------------------------------------------------------

--
-- Stand-in structure for view `posts_all`
-- (See below for the actual view)
--
CREATE TABLE `posts_all` (
`post_type` varchar(2)
,`post_id` int(11)
,`title` varchar(255)
,`username` varchar(255)
,`post_date` timestamp
);

-- --------------------------------------------------------

--
-- Table structure for table `post_matches`
--

CREATE TABLE `post_matches` (
  `id` int(10) UNSIGNED NOT NULL,
  `left_type` enum('fh','fp') NOT NULL,
  `left_id` int(11) NOT NULL,
  `right_type` enum('fh','fp') NOT NULL,
  `right_id` int(11) NOT NULL,
  `score` decimal(5,2) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_matches`
--

INSERT INTO `post_matches` (`id`, `left_type`, `left_id`, `right_type`, `right_id`, `score`, `created_at`) VALUES
(57, 'fh', 10, 'fp', 16, 80.00, '2025-09-28 05:31:18'),
(58, 'fh', 10, 'fp', 9, 70.00, '2025-09-28 05:31:18'),
(59, 'fh', 10, 'fp', 18, 60.00, '2025-09-28 05:31:18'),
(60, 'fh', 1, 'fp', 11, 80.00, '2025-09-28 05:32:13'),
(61, 'fh', 1, 'fp', 1, 70.00, '2025-09-28 05:32:13'),
(62, 'fh', 1, 'fp', 3, 60.00, '2025-09-28 05:32:13'),
(65, 'fp', 9, 'fh', 20, 60.00, '2025-09-28 05:41:37'),
(66, 'fp', 9, 'fh', 12, 60.00, '2025-09-28 05:41:37'),
(67, 'fp', 9, 'fh', 22, 40.00, '2025-09-28 05:41:37'),
(68, 'fp', 1, 'fh', 1, 70.00, '2025-09-28 05:42:13'),
(69, 'fp', 1, 'fh', 19, 60.00, '2025-09-28 05:42:13'),
(70, 'fp', 1, 'fh', 18, 60.00, '2025-09-28 05:42:13'),
(146, 'fh', 12, 'fp', 15, 80.00, '2025-09-30 01:55:56'),
(147, 'fh', 12, 'fp', 9, 60.00, '2025-09-30 01:55:56'),
(148, 'fh', 12, 'fp', 17, 50.00, '2025-09-30 01:55:56'),
(149, 'fp', 11, 'fh', 20, 60.00, '2025-09-30 09:52:19'),
(150, 'fp', 11, 'fh', 12, 60.00, '2025-09-30 09:52:19'),
(151, 'fp', 11, 'fh', 22, 40.00, '2025-09-30 09:52:19'),
(152, 'fh', 2, 'fp', 18, 50.00, '2025-10-06 09:27:48'),
(153, 'fh', 2, 'fp', 16, 50.00, '2025-10-06 09:27:48'),
(154, 'fh', 2, 'fp', 14, 50.00, '2025-10-06 09:27:48'),
(156, 'fp', 2, 'fh', 2, 90.00, '2025-10-06 09:30:36'),
(157, 'fp', 2, 'fh', 1, 60.00, '2025-10-06 09:30:36'),
(158, 'fp', 2, 'fh', 21, 50.00, '2025-10-06 09:30:36'),
(177, 'fp', 4, 'fh', 20, 40.00, '2025-10-14 08:46:54'),
(178, 'fp', 4, 'fh', 12, 40.00, '2025-10-14 08:46:54'),
(185, 'fh', 3, 'fp', 3, 70.00, '2025-10-14 14:46:35'),
(186, 'fh', 3, 'fp', 18, 60.00, '2025-10-14 14:46:35'),
(187, 'fh', 3, 'fp', 16, 60.00, '2025-10-14 14:46:35'),
(188, 'fp', 5, 'fh', 2, 60.00, '2025-10-14 15:28:09'),
(189, 'fp', 5, 'fh', 1, 60.00, '2025-10-14 15:28:09'),
(190, 'fp', 5, 'fh', 21, 40.00, '2025-10-14 15:28:09'),
(191, 'fp', 6, 'fh', 2, 60.00, '2025-10-14 15:30:09'),
(192, 'fp', 6, 'fh', 1, 60.00, '2025-10-14 15:30:09'),
(193, 'fp', 6, 'fh', 21, 40.00, '2025-10-14 15:30:09'),
(197, 'fp', 3, 'fh', 3, 70.00, '2025-10-17 10:26:15'),
(198, 'fp', 3, 'fh', 4, 50.00, '2025-10-17 10:26:15'),
(199, 'fp', 3, 'fh', 2, 50.00, '2025-10-17 10:26:15'),
(200, 'fh', 4, 'fp', 5, 90.00, '2025-10-17 22:35:09'),
(201, 'fh', 4, 'fp', 2, 60.00, '2025-10-17 22:35:09'),
(202, 'fh', 4, 'fp', 14, 50.00, '2025-10-17 22:35:09');

-- --------------------------------------------------------

--
-- Table structure for table `post_reports`
--

CREATE TABLE `post_reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_type` enum('fh','fp') NOT NULL,
  `post_id` int(11) NOT NULL,
  `reporter_id` int(11) NOT NULL,
  `reason_id` smallint(5) UNSIGNED DEFAULT NULL,
  `custom_reason` varchar(500) DEFAULT NULL,
  `status` enum('pending','reviewing','accepted','rejected','false_report','resolved') NOT NULL DEFAULT 'pending',
  `reporter_ip` varbinary(16) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `duplicate_of` int(10) UNSIGNED DEFAULT NULL,
  `is_open` tinyint(1) GENERATED ALWAYS AS (case when `status` in ('pending','reviewing') then 1 else NULL end) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post_reports`
--

INSERT INTO `post_reports` (`id`, `post_type`, `post_id`, `reporter_id`, `reason_id`, `custom_reason`, `status`, `reporter_ip`, `created_at`, `updated_at`, `duplicate_of`) VALUES
(1, 'fh', 18, 1, 2, NULL, 'resolved', 0xc0a8010b, '2025-09-19 06:49:31', '2025-10-14 07:09:12', NULL),
(7, 'fp', 14, 4, 2, NULL, 'pending', 0x0a0a2317, '2025-10-14 09:32:08', '2025-10-14 09:32:08', NULL),
(8, 'fp', 4, 2, 1, NULL, 'resolved', 0x0a0a2317, '2025-10-14 14:45:58', '2025-10-16 23:35:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_report_actions`
--

CREATE TABLE `post_report_actions` (
  `id` int(10) UNSIGNED NOT NULL,
  `report_id` int(10) UNSIGNED NOT NULL,
  `actor_id` int(11) NOT NULL,
  `action` enum('status_change','merge','note','assign') NOT NULL,
  `from_status` enum('pending','reviewing','accepted','rejected','false_report','resolved') DEFAULT NULL,
  `to_status` enum('pending','reviewing','accepted','rejected','false_report','resolved') DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `rehome_reasons`
--

CREATE TABLE `rehome_reasons` (
  `reason_id` smallint(5) UNSIGNED NOT NULL,
  `name_th` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rehome_reasons`
--

INSERT INTO `rehome_reasons` (`reason_id`, `name_th`, `name_en`, `description`, `is_active`) VALUES
(1, 'ย้ายที่อยู่', 'Relocation', 'เจ้าของต้องย้ายไปในที่ที่ไม่อนุญาตให้เลี้ยงสัตว์', 1),
(2, 'เจ้าของมีปัญหาสุขภาพ/เวลา', 'Owner Constraints', 'เจ้าของไม่สามารถให้เวลาหรือดูแลได้เต็มที่เนื่องจากปัญหาสุขภาพหรือภาระงาน', 1),
(3, 'เก็บได้/พลัดหลง', 'Found/Stray', 'สัตว์เลี้ยงที่พบข้างถนน/เก็บมาเลี้ยงและต้องการหาบ้านถาวร', 1),
(4, 'ปัญหาพฤติกรรม/เข้ากันไม่ได้', 'Behavior/Compatibility', 'สัตว์เลี้ยงมีพฤติกรรมบางอย่างที่เจ้าของไม่สามารถจัดการได้ หรือเข้ากับวิถีชีวิตเจ้าของไม่ได้', 1),
(5, 'เหตุผลอื่นๆ', 'Other', 'เหตุผลที่ไม่เข้าข่ายรายการอื่น ๆ เช่น การหย่าร้าง, ความเสียหายของที่พัก', 1),
(6, 'ปัญหาการเงิน', 'Financial Issues', 'ความไม่พร้อมทางการเงินในการดูแลค่าใช้จ่ายด้านอาหารและสุขภาพ', 1),
(7, 'เจ้าของเสียชีวิต', 'Owner Deceased', 'เจ้าของเดิมเสียชีวิตและไม่มีใครดูแลต่อ', 1),
(8, 'เจ้าของตั้งครรภ์/มีเด็กเล็ก', 'Pregnancy / Newborn', 'ความกังวลด้านความปลอดภัย/สุขภาพของเด็ก หรือไม่สามารถดูแลสัตว์เลี้ยงไปพร้อมกับเด็กได้', 1),
(9, 'สัตว์เลี้ยงตัวอื่นเข้ากันไม่ได้', 'Conflict with Other Pets', 'มีการทะเลาะวิวาทหรือเกิดความเครียดระหว่างสัตว์เลี้ยงในบ้าน', 1);

-- --------------------------------------------------------

--
-- Table structure for table `report_reasons`
--

CREATE TABLE `report_reasons` (
  `reason_id` smallint(5) UNSIGNED NOT NULL,
  `code` varchar(50) NOT NULL,
  `name_th` varchar(255) NOT NULL,
  `name_en` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `order_index` smallint(5) UNSIGNED NOT NULL DEFAULT 100
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_reasons`
--

INSERT INTO `report_reasons` (`reason_id`, `code`, `name_th`, `name_en`, `description`, `is_active`, `order_index`) VALUES
(1, 'spam', 'สแปม/โฆษณา', 'Spam/Ads', NULL, 1, 10),
(2, 'scam', 'หลอกลวง/ฉ้อโกง', 'Scam/Fraud', NULL, 1, 20),
(3, 'violent', 'ความรุนแรง/ทารุณกรรมสัตว์', 'Violence/Animal Abuse', NULL, 1, 30),
(4, 'illegal', 'ผิดกฎหมาย/อันตราย', 'Illegal/Dangerous', NULL, 1, 40),
(5, 'duplicated', 'โพสต์ซ้ำ/สับสน', 'Duplicated/Confusing', NULL, 1, 50),
(6, 'other', 'เหตุผลอื่น ๆ', 'Other', NULL, 1, 90);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(7) NOT NULL,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `userType` varchar(20) NOT NULL,
  `status` enum('active','suspended') NOT NULL DEFAULT 'active',
  `profilePicture` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `userType`, `status`, `profilePicture`) VALUES
(1, 'npdgame', 'asd123@gmail.com', '123456789', 'fpet', 'active', 'profile_687a0d11c07d04.54565560.jpeg'),
(2, 'npdgame2', 'asd1232@gmail.com', '123456789', 'fhome', 'active', 'profile_68b8959cdbb838.27792186.jpeg'),
(3, 'gay', 'aa@gmail.com', '123456', 'fpet', 'active', ''),
(4, 'นาย b', 'b2@gmail.com', '123456', 'fpet', 'active', NULL),
(1001, 'mint.home', 'mint.home@example.com', '123456789', 'fhome', 'active', 'profile_mint.jpeg'),
(1002, 'boss.find', 'boss.find@example.com', '123456789', 'fpet', 'active', 'profile_boss.jpeg'),
(1003, 'jane.dual', 'jane.dual@example.com', '123456789', 'fhome', 'active', 'profile_jane.jpeg'),
(1004, 'ohm.dual', 'ohm.dual@example.com', '123456789', 'fpet', 'active', 'profile_ohm.jpeg'),
(1005, 'noon.home', 'noon.home@example.com', '123456789', 'fhome', 'active', 'profile_noon.jpeg'),
(1006, 'park.find', 'park.find@example.com', '123456789', 'fpet', 'active', 'profile_park.jpeg'),
(1007, 'aom.dual', 'aom.dual@example.com', '123456789', 'fhome', 'active', 'profile_aom.jpeg'),
(1008, 'beam.find', 'beam.find@example.com', '123456789', 'fpet', 'active', 'profile_beam.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(7) NOT NULL,
  `type` enum('report_resolution_reporter','report_resolution_poster','match_found','new_comment') NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `related_post_type` enum('fh','fp') DEFAULT NULL,
  `related_post_id` int(11) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `user_id`, `type`, `title`, `message`, `related_post_type`, `related_post_id`, `is_read`, `created_at`) VALUES
(1, 1001, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกดำเนินการ (ลบ)', 'โพสต์ของคุณเรื่อง **\"สก็อตติชโฟลด์ หน้ากลม ขนหนา\"** ถูกลบออกจากระบบเนื่องจากละเมิดกฎการใช้งาน', 'fh', 22, 0, '2025-10-05 01:25:20'),
(2, 2, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกดำเนินการ (ลบ)', 'โพสต์ของคุณเรื่อง **\"เทสรีพอต\"** ถูกลบออกจากระบบเนื่องจากละเมิดกฎการใช้งาน', 'fh', 1111, 1, '2025-10-05 02:04:10'),
(3, 1, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"เทสรีพอต\"** ได้รับการตรวจสอบและถูกดำเนินการ (ลบ) เรียบร้อยแล้ว', 'fh', 1111, 1, '2025-10-05 02:04:10'),
(4, 2, 'new_comment', '💬 มีคอมเมนต์ใหม่ในโพสต์ของคุณ', 'npdgame ได้แสดงความคิดเห็นว่า: \"Test\"', 'fh', 1, 1, '2025-10-05 02:50:56'),
(5, 2, '', '📬 มีคนตอบกลับความคิดเห็นของคุณ', 'npdgame ได้ตอบกลับความคิดเห็นของคุณว่า: \"แชท\"', 'fp', 11, 1, '2025-10-05 03:30:01'),
(6, 2, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกดำเนินการ (ลบ)', 'โพสต์ของคุณเรื่อง **\"บางแก้ว ดำ-ขาว หาบ้านให้น้อง\"** ถูกลบออกจากระบบเนื่องจากละเมิดกฎการใช้งาน', 'fh', 3, 1, '2025-10-06 09:45:38'),
(7, 1, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"บางแก้ว ดำ-ขาว หาบ้านให้น้อง\"** ได้รับการตรวจสอบและถูกดำเนินการ (ลบ) เรียบร้อยแล้ว', 'fh', 3, 0, '2025-10-06 09:45:38'),
(8, 3, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"บางแก้ว ดำ-ขาว หาบ้านให้น้อง\"** ได้รับการตรวจสอบและถูกดำเนินการ (ลบ) เรียบร้อยแล้ว', 'fh', 3, 1, '2025-10-06 09:45:39'),
(9, 1001, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกระงับ', 'โพสต์ของคุณเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ถูกระงับการใช้งานจากระบบเนื่องจากละเมิดกฎ', 'fh', 18, 0, '2025-10-06 10:34:42'),
(10, 1, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ได้รับการตรวจสอบและถูกดำเนินการ (ระงับการใช้งาน) เรียบร้อยแล้ว', 'fh', 18, 0, '2025-10-06 10:34:42'),
(11, 1001, '', '✅ โพสต์ของคุณกลับมาใช้งานได้แล้ว', 'ข่าวดี! โพสต์ของคุณเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ได้รับการตรวจสอบอีกครั้งและกลับมาแสดงผลในระบบแล้ว', 'fh', 18, 0, '2025-10-06 10:45:06'),
(12, 1001, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกระงับ', 'โพสต์ของคุณเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ถูกระงับการใช้งานจากระบบเนื่องจากละเมิดกฎ', 'fh', 18, 0, '2025-10-14 07:09:12'),
(13, 1, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ได้รับการตรวจสอบและถูกดำเนินการ (ระงับการใช้งาน) เรียบร้อยแล้ว', 'fh', 18, 0, '2025-10-14 07:09:12'),
(14, 1001, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกระงับ', 'โพสต์ของคุณเรื่อง **\"พุดเดิ้ลสีน้ำตาลหาบ้านด่วน\"** ถูกระงับการใช้งานจากระบบเนื่องจากละเมิดกฎ', 'fh', 18, 0, '2025-10-14 07:10:05'),
(15, 4, 'report_resolution_poster', '🚨 โพสต์ของคุณถูกระงับ', 'โพสต์ของคุณเรื่อง **\"สแปมโพส\"** ถูกระงับการใช้งานจากระบบเนื่องจากละเมิดกฎ', 'fp', 4, 1, '2025-10-16 23:35:31'),
(16, 2, 'report_resolution_reporter', '✅ รีพอร์ตของคุณถูกดำเนินการแล้ว', 'ขอบคุณสำหรับความร่วมมือ! โพสต์ที่คุณรายงานไปเรื่อง **\"สแปมโพส\"** ได้รับการตรวจสอบและถูกดำเนินการ (ระงับการใช้งาน) เรียบร้อยแล้ว', 'fp', 4, 0, '2025-10-16 23:35:31');

-- --------------------------------------------------------

--
-- Table structure for table `vaccines`
--

CREATE TABLE `vaccines` (
  `vaccine_id` int(10) UNSIGNED NOT NULL,
  `name_th` varchar(128) NOT NULL,
  `name_en` varchar(128) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `species_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `dose_recommend` varchar(128) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vaccines`
--

INSERT INTO `vaccines` (`vaccine_id`, `name_th`, `name_en`, `description`, `species_id`, `dose_recommend`, `is_active`) VALUES
(1, 'วัคซีนป้องกันโรคไข้หัด', 'Distemper', NULL, 1, NULL, 1),
(2, 'โรคลำไส้อักเสบ', 'Parvovirus (CPV)', NULL, 1, NULL, 1),
(3, 'โรคตับอักเสบ', 'Hepatitis (CAV-1)', NULL, 1, NULL, 1),
(4, 'โรคพิษสุนัขบ้า', 'Rabies', NULL, 1, NULL, 1),
(5, 'วัคซีนป้องกันโรคไข้หัด', 'Panleukopenia (Feline Distemper)', NULL, 2, NULL, 1),
(6, 'โรคระบบทางเดินหายใจส่วนต้น', 'FVR/FCV (Respiratory Complex)', NULL, 2, NULL, 1),
(7, 'โรคลิวคีเมีย', 'FeLV', NULL, 2, NULL, 1),
(8, 'โรคพิษสุนัขบ้า', 'Rabies', NULL, 2, NULL, 1),
(9, 'วัคซีนป้องกันโรคเลปโตสไปโรซิส', 'Leptospirosis', NULL, 1, NULL, 1),
(10, 'วัคซีนป้องกันโรคหลอดลมอักเสบติดต่อ', 'Canine Infectious Tracheobronchitis (Kennel Cough)', NULL, 1, NULL, 1),
(11, 'วัคซีนรวม 5 โรค (ไข้หัด, ตับอักเสบ, ลำไส้อักเสบ, พาราอินฟลูเอนซา, เลปโตสไปโรซิส)', 'DHPPi+L', NULL, 1, NULL, 1),
(12, 'วัคซีนรวม 6 โรค (DHPPiL+Corona)', 'DHPPiL+C', NULL, 1, NULL, 1),
(13, 'วัคซีนป้องกันโรคพิษสุนัขบ้าในแมว', 'Rabies (Feline)', NULL, 2, NULL, 1),
(14, 'วัคซีนป้องกันโรคคาลิซิไวรัส', 'Feline Calicivirus', NULL, 2, NULL, 1),
(15, 'วัคซีนป้องกันโรคเฮอร์ปีส์ไวรัส', 'Feline Herpesvirus (Rhinotracheitis)', NULL, 2, NULL, 1),
(16, 'วัคซีนป้องกันโรคคลามัยเดีย', 'Chlamydophila felis', NULL, 2, NULL, 1),
(17, 'วัคซีนรวม 3 โรคแมว (ไข้หัดแมว, คาลิซิ, เฮอร์ปีส์)', 'FVRCP', NULL, 2, NULL, 1),
(18, 'วัคซีนรวม 4 โรคแมว (FVRCP + Chlamydophila)', 'FVRCP+Ch', NULL, 2, NULL, 1);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_report_status_7d`
-- (See below for the actual view)
--
CREATE TABLE `vw_report_status_7d` (
`status` enum('pending','reviewing','accepted','rejected','false_report','resolved')
,`cnt` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_report_top_posts_30d`
-- (See below for the actual view)
--
CREATE TABLE `vw_report_top_posts_30d` (
`post_type` enum('fh','fp')
,`post_id` int(11)
,`title` varchar(255)
,`reports` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `vw_top_reporters`
-- (See below for the actual view)
--
CREATE TABLE `vw_top_reporters` (
`username` varchar(100)
,`cnt` bigint(21)
);

-- --------------------------------------------------------

--
-- Structure for view `posts_all`
--
DROP TABLE IF EXISTS `posts_all`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `posts_all`  AS SELECT 'fh' AS `post_type`, `f`.`id` AS `post_id`, `f`.`title` AS `title`, `f`.`user` AS `username`, `f`.`post_date` AS `post_date` FROM `fhome` AS `f`union all select 'fp' AS `post_type`,`p`.`id` AS `post_id`,`p`.`title` AS `title`,`p`.`user` AS `username`,`p`.`post_date` AS `post_date` from `fpet` `p`  ;

-- --------------------------------------------------------

--
-- Structure for view `vw_report_status_7d`
--
DROP TABLE IF EXISTS `vw_report_status_7d`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_report_status_7d`  AS SELECT `post_reports`.`status` AS `status`, count(0) AS `cnt` FROM `post_reports` WHERE `post_reports`.`created_at` >= current_timestamp() - interval 7 day GROUP BY `post_reports`.`status` ;

-- --------------------------------------------------------

--
-- Structure for view `vw_report_top_posts_30d`
--
DROP TABLE IF EXISTS `vw_report_top_posts_30d`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_report_top_posts_30d`  AS SELECT `r`.`post_type` AS `post_type`, `r`.`post_id` AS `post_id`, `pa`.`title` AS `title`, count(0) AS `reports` FROM (`post_reports` `r` join `posts_all` `pa` on(`pa`.`post_type` = `r`.`post_type` and `pa`.`post_id` = `r`.`post_id`)) WHERE `r`.`created_at` >= current_timestamp() - interval 30 day GROUP BY `r`.`post_type`, `r`.`post_id`, `pa`.`title` ORDER BY count(0) DESC ;

-- --------------------------------------------------------

--
-- Structure for view `vw_top_reporters`
--
DROP TABLE IF EXISTS `vw_top_reporters`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vw_top_reporters`  AS SELECT `u`.`username` AS `username`, count(0) AS `cnt` FROM (`post_reports` `r` join `users` `u` on(`u`.`id` = `r`.`reporter_id`)) GROUP BY `r`.`reporter_id`, `u`.`username` ORDER BY count(0) DESC ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adoption_terms`
--
ALTER TABLE `adoption_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD UNIQUE KEY `uq_term_name_th` (`name_th`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `articles` ADD FULLTEXT KEY `idx_title_tags` (`title`,`tags`);

--
-- Indexes for table `article_images`
--
ALTER TABLE `article_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `article_id` (`article_id`);

--
-- Indexes for table `breeds`
--
ALTER TABLE `breeds`
  ADD PRIMARY KEY (`breed_id`),
  ADD UNIQUE KEY `uq_breed_name_species` (`name_th`,`species_id`),
  ADD KEY `fk_breeds_species` (`species_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_post_type_id` (`post_type`,`post_id`),
  ADD KEY `idx_parent_id` (`parent_id`);

--
-- Indexes for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_comment_user` (`comment_id`,`username`),
  ADD KEY `idx_comment` (`comment_id`);

--
-- Indexes for table `fhome`
--
ALTER TABLE `fhome`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fpet`
--
ALTER TABLE `fpet`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `housing_types`
--
ALTER TABLE `housing_types`
  ADD PRIMARY KEY (`housing_id`),
  ADD UNIQUE KEY `uq_housing_name_th` (`name_th`);

--
-- Indexes for table `personalities`
--
ALTER TABLE `personalities`
  ADD PRIMARY KEY (`personality_id`),
  ADD UNIQUE KEY `uq_personality_name_species` (`name_th`,`species_id`),
  ADD KEY `fk_personalities_species` (`species_id`);

--
-- Indexes for table `pet_species`
--
ALTER TABLE `pet_species`
  ADD PRIMARY KEY (`species_id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `post_matches`
--
ALTER TABLE `post_matches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_left_right` (`left_type`,`left_id`,`right_type`,`right_id`),
  ADD KEY `idx_left` (`left_type`,`left_id`),
  ADD KEY `idx_right` (`right_type`,`right_id`),
  ADD KEY `idx_score` (`score`);

--
-- Indexes for table `post_reports`
--
ALTER TABLE `post_reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_open_report_per_user` (`post_type`,`post_id`,`reporter_id`,`is_open`),
  ADD KEY `idx_target` (`post_type`,`post_id`,`status`),
  ADD KEY `idx_reporter` (`reporter_id`,`created_at`),
  ADD KEY `idx_reason` (`reason_id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_updated` (`updated_at`),
  ADD KEY `fk_pr_dup` (`duplicate_of`);

--
-- Indexes for table `post_report_actions`
--
ALTER TABLE `post_report_actions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_report_created` (`report_id`,`created_at`),
  ADD KEY `idx_actor` (`actor_id`,`created_at`);

--
-- Indexes for table `rehome_reasons`
--
ALTER TABLE `rehome_reasons`
  ADD PRIMARY KEY (`reason_id`),
  ADD UNIQUE KEY `uq_reason_name_th` (`name_th`);

--
-- Indexes for table `report_reasons`
--
ALTER TABLE `report_reasons`
  ADD PRIMARY KEY (`reason_id`),
  ADD UNIQUE KEY `uq_reason_code` (`code`),
  ADD KEY `idx_active_order` (`is_active`,`order_index`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_read_created` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `vaccines`
--
ALTER TABLE `vaccines`
  ADD PRIMARY KEY (`vaccine_id`),
  ADD UNIQUE KEY `uq_vaccine_name_species` (`name_th`,`species_id`),
  ADD KEY `fk_vaccines_species` (`species_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adoption_terms`
--
ALTER TABLE `adoption_terms`
  MODIFY `term_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `article_images`
--
ALTER TABLE `article_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `breeds`
--
ALTER TABLE `breeds`
  MODIFY `breed_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fhome`
--
ALTER TABLE `fhome`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;

--
-- AUTO_INCREMENT for table `fpet`
--
ALTER TABLE `fpet`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `housing_types`
--
ALTER TABLE `housing_types`
  MODIFY `housing_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `personalities`
--
ALTER TABLE `personalities`
  MODIFY `personality_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `pet_species`
--
ALTER TABLE `pet_species`
  MODIFY `species_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `post_matches`
--
ALTER TABLE `post_matches`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=203;

--
-- AUTO_INCREMENT for table `post_reports`
--
ALTER TABLE `post_reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `post_report_actions`
--
ALTER TABLE `post_report_actions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rehome_reasons`
--
ALTER TABLE `rehome_reasons`
  MODIFY `reason_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `report_reasons`
--
ALTER TABLE `report_reasons`
  MODIFY `reason_id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `vaccines`
--
ALTER TABLE `vaccines`
  MODIFY `vaccine_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `article_images`
--
ALTER TABLE `article_images`
  ADD CONSTRAINT `article_images_ibfk_1` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `breeds`
--
ALTER TABLE `breeds`
  ADD CONSTRAINT `fk_breeds_species` FOREIGN KEY (`species_id`) REFERENCES `pet_species` (`species_id`) ON UPDATE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `fk_parent_comment` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `fk_like_comment` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `personalities`
--
ALTER TABLE `personalities`
  ADD CONSTRAINT `fk_personalities_species` FOREIGN KEY (`species_id`) REFERENCES `pet_species` (`species_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `post_reports`
--
ALTER TABLE `post_reports`
  ADD CONSTRAINT `fk_pr_dup` FOREIGN KEY (`duplicate_of`) REFERENCES `post_reports` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_pr_reason` FOREIGN KEY (`reason_id`) REFERENCES `report_reasons` (`reason_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_pr_reporter` FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `post_report_actions`
--
ALTER TABLE `post_report_actions`
  ADD CONSTRAINT `fk_pra_report` FOREIGN KEY (`report_id`) REFERENCES `post_reports` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD CONSTRAINT `fk_user_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vaccines`
--
ALTER TABLE `vaccines`
  ADD CONSTRAINT `fk_vaccines_species` FOREIGN KEY (`species_id`) REFERENCES `pet_species` (`species_id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
