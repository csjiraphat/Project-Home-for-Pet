<?php
// C:\xampp\htdocs\db_fhomepet\article\article.php
// เวอร์ชัน: แก้ปัญหา Invalid parameter number โดยไม่ reuse named placeholders และเพิ่ม Fallback รูปปก

error_reporting(0);
ob_start();

require_once __DIR__ . '/../db.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

$response = ['status' => 'error', 'message' => 'Internal Server Error.'];

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    ob_clean();
    echo json_encode(['status' => 'ok']);
    exit;
}

if (!isset($pdo) || $pdo === null) {
    http_response_code(500);
    $response['message'] = 'Database connection is not available.';
    ob_clean();
    echo json_encode($response);
    exit;
}

$entity = $_GET['entity'] ?? '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$species = $_GET['species'] ?? null;
$q = $_GET['q'] ?? '';
$limit = isset($_GET['limit']) ? max(1, intval($_GET['limit'])) : 20;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

/**
 * ดึง URL รูปภาพแรกที่ปรากฏในเนื้อหา HTML
 * @param string $html เนื้อหาบทความ
 * @return string|null URL ของรูปภาพแรก หรือ null หากไม่พบ
 */
function get_first_image_url($html) {
    // ใช้ RegEx เพื่อค้นหาแท็ก <img ... src="..."> ตัวแรก
    if (preg_match('/<img[^>]+src=[\'"]([^\'"]+)[\'"][^>]*>/i', $html, $matches)) {
        $url = $matches[1];
        // ตรวจสอบและปรับ URL ให้แน่ใจว่าขึ้นต้นด้วย /admin/ ถ้ามาจาก uploads/
        if (strpos($url, 'uploads/') === 0) {
            return '/admin/' . $url;
        }
        // ถ้าเป็น /admin/uploads/ หรือ URL เต็ม ก็ส่งคืนค่าเดิม
        return $url;
    }
    return null; 
}


if ($entity !== 'articles') {
    http_response_code(404);
    $response['message'] = 'API entity not found.';
    ob_clean();
    echo json_encode($response);
    exit;
}

try {
    // --- Detail view (ไม่มีการเปลี่ยนแปลง) ---
    if ($id > 0) {
        $sql_article = "SELECT * FROM articles WHERE id = :id AND is_active = 1 LIMIT 1";
        $stmt_article = $pdo->prepare($sql_article);
        $stmt_article->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt_article->execute();
        $article = $stmt_article->fetch(PDO::FETCH_ASSOC);

        if ($article) {
            // โค้ดนี้จะดึงเฉพาะรูปภาพที่บันทึกแยกไว้ใน article_images (ตามโค้ดเดิม)
            $sql_images = "SELECT id, CONCAT('/admin/', url) as url FROM article_images WHERE article_id = :article_id ORDER BY sort_order ASC, id ASC";
            $stmt_images = $pdo->prepare($sql_images);
            $stmt_images->bindValue(':article_id', $id, PDO::PARAM_INT);
            $stmt_images->execute();
            $article['images'] = $stmt_images->fetchAll(PDO::FETCH_ASSOC) ?: [];
            
            // NOTE: สำหรับหน้า Detail หากไม่มีรูปใน article_images อาจต้องหา fallback จาก content ในโค้ด Front-end
            
            $response = ['status' => 'success', 'data' => $article];
            http_response_code(200);
            ob_clean();
            echo json_encode($response);
            exit;
        } else {
            http_response_code(404);
            $response['message'] = 'Article not found.';
            ob_clean();
            echo json_encode($response);
            exit;
        }
    }

    // --- List view (มีการเปลี่ยนแปลง) ---
    $base_where = "a.is_active = 1";
    $params = [];
    $order_by = "a.published_at DESC, a.id DESC";
    
    // *** แก้ไข: ดึง a.content เต็มมาเพื่อใช้หา Fallback รูปภาพ ***
    $select_fields = "a.id, a.species, a.title, a.tags, a.published_at, a.content AS raw_content_full"; 

    if (in_array($species, ['dog', 'cat'], true)) {
        $base_where .= " AND a.species = :species";
        $params[':species'] = $species;
    }

    if ($q !== '') {
        // ใช้สอง placeholder แยกกันเพื่อหลีกเลี่ยงปัญหา reuse ของ named placeholder
        $select_fields .= ", (MATCH(a.title, a.tags) AGAINST(:q_select IN NATURAL LANGUAGE MODE)) AS relevance_score";
        $base_where .= " AND MATCH(a.title, a.tags) AGAINST(:q_where IN NATURAL LANGUAGE MODE)";

        $params[':q_select'] = $q;
        $params[':q_where'] = $q;

        $order_by = "relevance_score DESC, a.published_at DESC";
    }

    $sql_list = "
        SELECT {$select_fields},
               (SELECT CONCAT('/admin/', url) FROM article_images ai 
                WHERE ai.article_id = a.id ORDER BY sort_order ASC, id ASC LIMIT 1) AS image_url
        FROM articles a
        WHERE {$base_where}
        ORDER BY {$order_by}
        LIMIT :limit OFFSET :offset
    ";

    $stmt_list = $pdo->prepare($sql_list);

    // bind dynamic params
    foreach ($params as $pname => $pval) {
        $stmt_list->bindValue($pname, $pval);
    }

    // bind pagination
    $stmt_list->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
    $stmt_list->bindValue(':offset', (int)$offset, PDO::PARAM_INT);

    $stmt_list->execute();
    $articles = $stmt_list->fetchAll(PDO::FETCH_ASSOC);

    $final_articles = array_map(function ($a) {
        $full_content = $a['raw_content_full'] ?? '';
        
        // --- 1. สร้าง Snippet ---
        $clean_snippet = trim(strip_tags($full_content));
        $a['snippet'] = mb_substr($clean_snippet, 0, 180, 'UTF-8') . (mb_strlen($clean_snippet, 'UTF-8') > 180 ? '...' : '');
        
        // --- 2. Logic Fallback รูปภาพ: ถ้า image_url ที่มาจาก article_images เป็น NULL ให้ใช้รูปแรกจากเนื้อหาแทน ---
        if (empty($a['image_url'])) {
            $a['image_url'] = get_first_image_url($full_content);
        }
        
        // --- 3. ล้างข้อมูลที่ไม่ต้องการ ---
        unset($a['raw_content_full']); 
        if (isset($a['relevance_score'])) {
            unset($a['relevance_score']);
        }
        return $a;
    }, $articles);

    $response = ['status' => 'success', 'data' => $final_articles];
    http_response_code(200);
    ob_clean();
    echo json_encode($response);
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Server Error: ' . $e->getMessage();
    ob_clean();
    echo json_encode($response);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = 'Server Error: ' . $e->getMessage();
    ob_clean();
    echo json_encode($response);
    exit;
}