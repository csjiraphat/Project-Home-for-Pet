<?php
// api/admin/reports/list.php
require_once __DIR__.'/../_inc/admin_auth.php'; // also creates $db
header('Content-Type: application/json; charset=utf-8');

$page = max(1, intval($_GET['page'] ?? 1));
$per  = min(100, max(10, intval($_GET['per'] ?? 20)));
$off  = ($page-1)*$per;
$status = $_GET['status'] ?? '';
$q = trim($_GET['q'] ?? '');

$w = []; $p = [];
if ($status !== '' && in_array($status, ['pending','reviewing','accepted','rejected','false_report','resolved'], true)) {
  $w[] = "r.status = ?"; $p[] = $status;
}
if ($q !== '') {
  $w[] = "(pa.title LIKE ? OR u.username LIKE ? OR rr.name_th LIKE ? OR r.custom_reason LIKE ?)";
  $p[] = "%".$q."%"; $p[] = "%".$q."%"; $p[] = "%".$q."%"; $p[] = "%".$q."%";
}
$where = $w ? ('WHERE '.implode(' AND ', $w)) : '';

$sql = "
SELECT r.id, r.post_type, r.post_id, r.status, r.severity,
       r.created_at, r.updated_at,
       rr.name_th AS reason_name, r.custom_reason,
       pa.title AS post_title, pa.username AS post_owner, pa.post_date,
       u.username AS reporter_username
FROM post_reports r
LEFT JOIN report_reasons rr ON rr.reason_id = r.reason_id
LEFT JOIN posts_all pa ON pa.post_type = r.post_type AND pa.post_id = r.post_id
LEFT JOIN users u ON u.id = r.reporter_id
{$where}
ORDER BY r.created_at DESC
LIMIT {$per} OFFSET {$off}";
$rows = $db->fetchAll($sql, $p);

$count = $db->fetchColumn("SELECT COUNT(*) FROM post_reports r
LEFT JOIN report_reasons rr ON rr.reason_id = r.reason_id
LEFT JOIN posts_all pa ON pa.post_type = r.post_type AND pa.post_id = r.post_id
LEFT JOIN users u ON u.id = r.reporter_id
{$where}", $p);

echo json_encode(['ok'=>true,'total'=>intval($count),'items'=>$rows], JSON_UNESCAPED_UNICODE);
?>
