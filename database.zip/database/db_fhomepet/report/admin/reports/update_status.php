<?php
// api/admin/reports/update_status.php
require_once __DIR__.'/../_inc/admin_auth.php';
header('Content-Type: application/json; charset=utf-8');

$report_id = intval($_POST['report_id'] ?? 0);
$to_status = $_POST['to_status'] ?? '';
$notes = trim($_POST['resolution_notes'] ?? '');

$valid = ['pending','reviewing','accepted','rejected','false_report','resolved'];
if ($report_id<=0 || !in_array($to_status,$valid,true)) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'invalid_params']); exit;
}

$report = $db->fetchAssoc('SELECT * FROM post_reports WHERE id=?', [$report_id]);
if (!$report) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'not_found']); exit; }

try {
  $db->pdo()->beginTransaction();

  $db->update('post_reports', [
    'status'=>$to_status,
    'resolved_by'=>$admin_user_id,
    'resolution_notes'=> $notes !== '' ? $notes : null
  ], ['id'=>$report_id]);

  $db->insert('post_report_actions', [
    'report_id'=>$report_id,
    'actor_id'=>$admin_user_id,
    'action'=>'status_change',
    'from_status'=>$report['status'],
    'to_status'=>$to_status,
    'note'=>$notes !== '' ? $notes : null
  ]);

  $db->pdo()->commit();
  echo json_encode(['ok'=>true]);
} catch (Exception $ex) {
  $db->pdo()->rollBack();
  http_response_code(500);
  echo json_encode(['ok'=>false,'error'=>'server_error']);
}
?>
