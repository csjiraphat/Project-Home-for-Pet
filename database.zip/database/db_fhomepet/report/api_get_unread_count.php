<?php
// /db_fhomepet/report/api_get_unread_count.php
require_once __DIR__ . '/../db.php'; 

header('Content-Type: application/json');

// สมมติว่ามีการส่ง user_id ผ่าน GET parameter
$current_user_id = intval($_GET['user_id'] ?? 0); 

if (!$current_user_id) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Missing user ID parameter.']);
    exit;
}

// SQL Query: นับจำนวนแจ้งเตือนที่ยังไม่ได้อ่าน
$sql = "SELECT COUNT(*) FROM user_notifications WHERE user_id = ? AND is_read = 0";

$stmt = $db->prepare($sql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Database prepare failed: ' . $db->error]);
    exit;
}

$stmt->bind_param('i', $current_user_id);
$stmt->execute();
$stmt->bind_result($unread_count);
$stmt->fetch();
$stmt->close();

echo json_encode(['ok' => true, 'unread_count' => $unread_count]);
?>