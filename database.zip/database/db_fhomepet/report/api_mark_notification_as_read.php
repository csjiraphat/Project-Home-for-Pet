<?php
// /db_fhomepet/report/api_mark_notification_as_read.php - Endpoint สำหรับอัปเดตสถานะการแจ้งเตือน

// สมมติว่าไฟล์ db.php อยู่ในโครงสร้างที่เข้าถึงได้ (เช่น /db_fhomepet/db.php หรือปรับ path ตามจริง)
// ถ้า db.php อยู่ใน root ของ db_fhomepet
require_once __DIR__ . '/../db.php'; 

header('Content-Type: application/json');

// ตั้งค่า CORS เพื่อให้ React Native สามารถเรียกใช้ได้
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// ต้องใช้ POST method เพื่อทำการเปลี่ยนแปลงข้อมูล
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Invalid request method. Only POST is allowed.']);
    exit;
}

// รับข้อมูลจาก JSON body
$input = json_decode(file_get_contents('php://input'), true);
$notification_id = intval($input['notification_id'] ?? 0);
// $current_user_id = intval($input['user_id'] ?? 0); // ควรส่ง user_id มาเพื่อความปลอดภัย

if (!$notification_id) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing notification ID.']);
    exit;
}

// อัปเดตสถานะ is_read เป็น 1
// 💡 NOTE: ใน production ควรเพิ่ม WHERE user_id = [current_user_id] เพื่อป้องกันไม่ให้ผู้ใช้แก้ไข notification ของคนอื่น
$sql = "UPDATE user_notifications SET is_read = 1 WHERE id = ?";

$stmt = $db->prepare($sql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Database prepare failed: ' . $db->error]);
    exit;
}

$stmt->bind_param('i', $notification_id);
$success = $stmt->execute();

$stmt->close();

if ($success) {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Notification marked as read.']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to update notification status.']);
}
?>