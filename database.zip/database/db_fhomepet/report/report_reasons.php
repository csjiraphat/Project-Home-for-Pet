<?php
// api/report_reasons.php
require_once __DIR__.'/_inc/db.php';
header('Content-Type: application/json; charset=utf-8');

$rows = $db->fetchAll('SELECT reason_id, code, name_th, name_en, description FROM report_reasons WHERE is_active=1 ORDER BY order_index, reason_id');
echo json_encode(['ok'=>true,'items'=>$rows], JSON_UNESCAPED_UNICODE);
?>
