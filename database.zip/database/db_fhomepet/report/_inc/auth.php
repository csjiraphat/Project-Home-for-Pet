<?php
// report/_inc/auth.php
// Robust auth helper: support Authorization header across Apache variants
require_once __DIR__.'/db.php';

function get_all_headers_fallback() {
  if (function_exists('getallheaders')) return getallheaders();
  $headers = [];
  foreach ($_SERVER as $name => $value) {
    if (strpos($name, 'HTTP_') === 0) {
      $key = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))));
      $headers[$key] = $value;
    }
  }
  return $headers;
}

function get_auth_bearer() {
  // 1) Standard CGI/FPM
  if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
    $hdr = $_SERVER['HTTP_AUTHORIZATION'];
    if (stripos($hdr, 'Bearer ') === 0) return substr($hdr, 7);
  }

  // 2) Some Apache setups rewrite to REDIRECT_HTTP_AUTHORIZATION
  if (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
    $hdr = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
    if (stripos($hdr, 'Bearer ') === 0) return substr($hdr, 7);
  }

  // 3) apache_request_headers() / getallheaders()
  $headers = function_exists('apache_request_headers') ? apache_request_headers() : get_all_headers_fallback();
  foreach (['Authorization','authorization','AUTHORIZATION'] as $k) {
    if (!empty($headers[$k]) && stripos($headers[$k], 'Bearer ') === 0) {
      return substr($headers[$k], 7);
    }
  }

  // 4) Fallback: custom header (allow mobile to send if Authorization is stripped)
  foreach (['X-Auth-Token','X-Auth-User'] as $alt) {
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $alt));
    if (!empty($_SERVER[$key])) return $_SERVER[$key];
  }

  // 5) (Optional) last-resort query param for debugging only
  if (!empty($_GET['auth'])) return $_GET['auth'];

  return null;
}

function current_user_id() {
  global $db;
  $tok = get_auth_bearer();
  if (!$tok) return null;
  if (ctype_digit($tok)) return intval($tok); // numeric token = user id
  // else treat as username
  $row = $db->fetchAssoc('SELECT id FROM users WHERE username = ? LIMIT 1', [$tok]);
  if ($row && isset($row['id'])) return intval($row['id']);
  return null;
}

$current_user_id = current_user_id();
