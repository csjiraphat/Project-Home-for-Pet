<?php
// api/_inc/db.php
// Simple PDO wrapper for MariaDB/MySQL

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_NAME', getenv('DB_NAME') ?: 'fhomepet');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

class DB {
  private $pdo;

  public function __construct() {
    $dsn = 'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset='.DB_CHARSET;
    $opts = [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
  }

  public function pdo() { return $this->pdo; }

  public function fetchAll($sql, $params = []) {
    $st = $this->pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
  }

  public function fetchAssoc($sql, $params = []) {
    $st = $this->pdo->prepare($sql);
    $st->execute($params);
    return $st->fetch();
  }

  public function fetchColumn($sql, $params = []) {
    $st = $this->pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchColumn();
  }

  public function insert($table, $data) {
    $cols = array_keys($data);
    $ph = array_map(function($c){ return ':' . $c; }, $cols);
    $sql = 'INSERT INTO '.$table.' ('.implode(',', $cols).') VALUES ('.implode(',', $ph).')';
    $st = $this->pdo->prepare($sql);
    foreach ($data as $k=>$v) { $st->bindValue(':'.$k, $v); }
    $st->execute();
    return $this->pdo->lastInsertId();
  }

  public function update($table, $data, $where) {
    $set = [];
    foreach ($data as $k=>$v) $set[] = $k.'=:set_'.$k;
    $cond = [];
    foreach ($where as $k=>$v) $cond[] = $k.'=:whr_'.$k;
    $sql = 'UPDATE '.$table.' SET '.implode(',',$set).' WHERE '.implode(' AND ',$cond);
    $st = $this->pdo->prepare($sql);
    foreach ($data as $k=>$v) { $st->bindValue(':set_'.$k, $v); }
    foreach ($where as $k=>$v) { $st->bindValue(':whr_'.$k, $v); }
    return $st->execute();
  }
}

$db = new DB();
?>
