<?php
// api/_inc/admin_auth.php
// Simple admin gate for demo: require X-Admin-Token header to match ADMIN_TOKEN.
require_once __DIR__.'/db.php';

define('ADMIN_TOKEN', getenv('ADMIN_TOKEN') ?: 'changeme');

function get_header($name) {
  $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
  return $_SERVER[$key] ?? null;
}

function require_admin() {
  $token = get_header('X-Admin-Token');
  if (!$token || $token !== ADMIN_TOKEN) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'unauthorized_admin']);
    exit;
  }
}

require_admin();
$admin_user_id = 1; // bind to first admin user for audit logging
?>
