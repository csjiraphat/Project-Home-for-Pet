<?php
function create_notification($db, $user_id, $type, $title, $message, $post_type = null, $post_id = null) {
  if (!$user_id) return;
  
  $post_type_val = $post_type; 
  $post_id_val = $post_id;     

  $stmt = $db->prepare("
    INSERT INTO user_notifications 
    (user_id, type, title, message, related_post_type, related_post_id) 
    VALUES (?, ?, ?, ?, ?, ?)
  ");
  
  if (!$stmt) {
    error_log("Notification prepare failed: " . $db->error);
    return;
  }
  
  $stmt->bind_param('issssi', 
    $user_id, 
    $type, 
    $title, 
    $message, 
    $post_type_val, 
    $post_id_val
  );

  $success = $stmt->execute();
  if (!$success) {
      error_log("Notification execute failed: " . $stmt->error);
  }
  $stmt->close();
}
?>