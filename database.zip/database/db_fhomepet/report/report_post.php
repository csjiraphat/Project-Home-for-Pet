<?php
// api/report_post.php
require_once __DIR__.'/_inc/db.php';
// require_once __DIR__.'/_inc/auth.php'; // 🚫 คอมเมนต์ออกเพื่อหลีกเลี่ยงการตรวจสอบ session/token ที่ไม่สมบูรณ์
header('Content-Type: application/json; charset=utf-8');

// ----------------------------------------------------------------------
// *** แก้ไข: กำหนด REPORTER ID โดยตรงจาก POST (สำหรับการทดสอบ) ***
// ----------------------------------------------------------------------
$reporter_id_from_post = intval($_POST['reporter_id'] ?? 0);
$current_user_id = $reporter_id_from_post;
// ----------------------------------------------------------------------

$post_type = $_POST['post_type'] ?? '';
$post_id   = intval($_POST['post_id'] ?? 0);
$reason_id = isset($_POST['reason_id']) ? intval($_POST['reason_id']) : null;
$custom_reason = trim($_POST['custom_reason'] ?? '');
$evidence = $_POST['evidence'] ?? []; // array of URL strings

// 1. ตรวจสอบพารามิเตอร์พื้นฐาน
if (!in_array($post_type, ['fh','fp'], true) || $post_id <= 0) {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'invalid_params']); exit;
}

// 2. ตรวจสอบสิทธิ์ (ใช้ ID จาก POST แทน Session/Token)
if ($current_user_id <= 0) { // 👈 ตรวจสอบว่า ID ที่ส่งมามีค่าจริง
  http_response_code(401);
  echo json_encode(['ok'=>false,'error'=>'unauthorized']); exit;
}

// 3. ตรวจสอบเหตุผล
if (empty($reason_id) && $custom_reason === '') {
  http_response_code(400);
  echo json_encode(['ok'=>false,'error'=>'reason_required']); exit;
}

// 4. ตรวจสอบว่าโพสต์มีอยู่จริง
$tbl = $post_type === 'fh' ? 'fhome' : 'fpet';
$exists = $db->fetchColumn("SELECT COUNT(*) FROM {$tbl} WHERE id = ?", [$post_id]);
if (!$exists) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'post_not_found']); exit; }

// 5. ตรวจสอบรีพอร์ตซ้ำ
$dup = $db->fetchColumn(
  "SELECT COUNT(*) FROM post_reports
   WHERE post_type=? AND post_id=? AND reporter_id=? AND status IN ('pending','reviewing')",
   [$post_type, $post_id, $current_user_id]
);
if ($dup) { http_response_code(409); echo json_encode(['ok'=>false,'error'=>'duplicate_open_report']); exit; }

// 6. จัดการ Evidence (ถ้ามี)
$evidence_json = null;
if (is_array($evidence) && count($evidence) > 0) {
  $clean = array_values(array_filter(array_map('strval',$evidence)));
  if (count($clean)>0) $evidence_json = json_encode($clean, JSON_UNESCAPED_UNICODE);
}
$ip_bin = @inet_pton($_SERVER['REMOTE_ADDR'] ?? '');

// 7. บันทึกรายงาน
$report_id = $db->insert('post_reports', [
  'post_type' => $post_type,
  'post_id' => $post_id,
  'reporter_id' => $current_user_id,
  'reason_id' => $reason_id ?: null,
  'custom_reason' => $custom_reason !== '' ? $custom_reason : null,
  'evidence_json' => $evidence_json,
  'status' => 'pending',
  'severity' => 0,
  'reporter_ip' => $ip_bin
]);

echo json_encode(['ok'=>true,'report_id'=>$report_id]);
?>