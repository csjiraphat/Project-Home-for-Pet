<?php
// /db_fhomepet/report/api_get_notifications.php - Endpoint สำหรับดึงรายการแจ้งเตือนของผู้ใช้

// สมมติว่าไฟล์ db.php อยู่ในโครงสร้างที่เข้าถึงได้ (เช่น /db_fhomepet/db.php หรือปรับ path ตามจริง)
// ถ้า db.php อยู่ใน root ของ db_fhomepet
require_once __DIR__ . '/../db.php'; 

header('Content-Type: application/json');

// ตั้งค่า CORS เพื่อให้ React Native สามารถเรียกใช้ได้ (ถ้าจำเป็น)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// สมมติว่ามีการส่ง user_id ผ่าน GET parameter
$current_user_id = intval($_GET['user_id'] ?? 0); 

// ในระบบจริง: ควรมีการตรวจสอบ Token หรือ Session เพื่อยืนยันตัวตน
// if (!is_authenticated($current_user_id)) { 
//     http_response_code(401);
//     echo json_encode(['error' => 'Unauthorized or missing authentication.']);
//     exit;
// }

if (!$current_user_id) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing user ID parameter.']);
    exit;
}

// SQL Query: ดึงข้อมูลแจ้งเตือนทั้งหมดของผู้ใช้ เรียงจากใหม่ไปเก่า
$sql = "
    SELECT id, type, title, message, related_post_type, related_post_id, is_read, created_at
    FROM user_notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
    LIMIT 100"; 

$stmt = $db->prepare($sql);
if ($stmt === false) {
    http_response_code(500);
    echo json_encode(['error' => 'Database prepare failed: ' . $db->error]);
    exit;
}

$stmt->bind_param('i', $current_user_id);
$stmt->execute();
$result = $stmt->get_result();

$notifications = [];
while ($row = $result->fetch_assoc()) {
    $notifications[] = $row;
}

$stmt->close();

echo json_encode(['notifications' => $notifications]);
?>