# FHomePet Report API (drop-in)
Endpoints (base: /api):
- POST /api/report_post.php
  Headers: Authorization: Bearer <user-id or username>
  Body (multipart/form-data):
    post_type=fh|fp
    post_id=<int>
    reason_id=<int> (optional)
    custom_reason=<string> (optional)
    evidence[]=<url> (repeatable)

- GET /api/report_reasons.php

Admin (require header: X-Admin-Token: changeme):
- GET /api/admin/reports/list.php?page=1&per=20&status=pending&q=keyword
- POST /api/admin/reports/update_status.php
  Body: report_id=<int>, to_status=<enum>, resolution_notes=<text>

Config DB:
  export DB_HOST, DB_NAME, DB_USER, DB_PASS (or edit api/_inc/db.php)
