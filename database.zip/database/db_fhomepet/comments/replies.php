<?php
/**
 * replies.php — Minimal reply list for a parent comment (mysqli)
 * Usage: GET replies.php?comment_id=123&username=<optional>&post_type=fh|fp&post_id=9
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/connect.php'; // must define $conn (mysqli)
mysqli_set_charset($conn, "utf8mb4");

$parentId = 0;
if (isset($_GET['comment_id'])) $parentId = intval($_GET['comment_id']);
if (!$parentId && isset($_GET['parentId'])) $parentId = intval($_GET['parentId']); // alias
$username = isset($_GET['username']) ? trim($_GET['username']) : '';
$post_type = isset($_GET['post_type']) ? trim($_GET['post_type']) : null;
$post_id = isset($_GET['post_id']) ? intval($_GET['post_id']) : null;

if ($parentId <= 0) {
  echo json_encode(['replies'=>[], 'message'=>'invalid parent id'], JSON_UNESCAPED_UNICODE);
  exit;
}

$whereExtra = "";
$types = "si"; // username (s), parentId (i)
$params = [$username, $parentId];

if (($post_type === 'fh' || $post_type === 'fp') && $post_id && $post_id > 0) {
  $whereExtra = " AND c.post_type = ? AND c.post_id = ? ";
  $types .= "si";
  $params[] = $post_type;
  $params[] = $post_id;
}

$sql = "
SELECT
  c.id, c.post_id, c.post_type, c.parent_id, c.user, c.content, c.created_at,
  COALESCE(l.cnt, 0) AS like_count,
  CASE WHEN lm.username IS NULL THEN 0 ELSE 1 END AS liked_by_me,
  u.profilePicture
FROM comments c
LEFT JOIN (
  SELECT comment_id, COUNT(*) AS cnt
  FROM comment_likes
  GROUP BY comment_id
) l ON l.comment_id = c.id
LEFT JOIN comment_likes lm
  ON lm.comment_id = c.id AND lm.username = ?
LEFT JOIN users u
  ON CONVERT(u.username USING utf8mb4) = CONVERT(c.user USING utf8mb4)
WHERE c.parent_id = ?
{$whereExtra}
ORDER BY c.created_at ASC, c.id ASC
";

$stmt = $conn->prepare($sql);
if (!$stmt) {
  echo json_encode(['replies'=>[], 'message'=>"prepare failed: ".$conn->error], JSON_UNESCAPED_UNICODE);
  exit;
}

// bind params dynamically
$stmt->bind_param($types, ...$params);
$stmt->execute();
$res = $stmt->get_result();

$out = [];
while ($row = $res->fetch_assoc()) {
  $out[] = [
    'id' => intval($row['id']),
    'post_id' => intval($row['post_id']),
    'post_type' => $row['post_type'],
    'parent_id' => $row['parent_id'] !== null ? intval($row['parent_id']) : null,
    'user' => $row['user'],
    'content' => $row['content'],
    'created_at' => $row['created_at'],
    'like_count' => intval($row['like_count']),
    'liked_by_me' => (bool)$row['liked_by_me'],
    'profilePicture' => $row['profilePicture'] ?: null
  ];
}

echo json_encode(['replies' => $out], JSON_UNESCAPED_UNICODE);
