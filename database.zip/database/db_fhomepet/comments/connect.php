
<?php
$host = 'localhost';
$user = 'root';
$password = ''; // ✅ ตรวจสอบว่าใส่รหัสผ่าน root ถูกหรือยัง
$database = 'fhomepet';

$conn = @new mysqli($host, $user, $password, $database);
mysqli_set_charset($conn, "utf8mb4");
if ($conn->connect_error) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => 'ไม่สามารถเชื่อมต่อฐานข้อมูลได้',
        'error' => $conn->connect_error
    ]);
    exit;
}
?>
