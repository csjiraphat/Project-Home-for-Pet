<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/connect.php';

$post_type = $_GET['post_type'] ?? '';
$post_id = intval($_GET['post_id'] ?? 0);
$current_user = $_GET['username'] ?? '';

$sql = "
  SELECT 
    c.id,
    c.post_id,
    c.post_type,
    c.parent_id,
    c.user,
    c.content,
    c.created_at,
    COALESCE(l.like_count, 0) AS like_count,
    (CASE WHEN ul.username IS NULL THEN FALSE ELSE TRUE END) AS liked_by_me,
    u.profilePicture
  FROM comments c
  LEFT JOIN users u 
    ON CONVERT(u.username USING utf8mb4) = CONVERT(c.user USING utf8mb4)
  LEFT JOIN (
    SELECT comment_id, COUNT(*) as like_count
    FROM comment_likes
    GROUP BY comment_id
  ) l ON l.comment_id = c.id
  LEFT JOIN comment_likes ul 
    ON ul.comment_id = c.id 
   AND CONVERT(ul.username USING utf8mb4) = CONVERT(? USING utf8mb4)
  WHERE c.post_type = ? AND c.post_id = ?
  ORDER BY c.created_at ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $current_user, $post_type, $post_id);
$stmt->execute();
$result = $stmt->get_result();

$comments = [];
while ($row = $result->fetch_assoc()) {
    $comments[] = [
        "id" => intval($row['id']),
        "post_id" => intval($row['post_id']),
        "post_type" => $row['post_type'],
        "parent_id" => $row['parent_id'] ? intval($row['parent_id']) : null,
        "user" => $row['user'],
        "content" => $row['content'],
        "created_at" => $row['created_at'],
        "like_count" => intval($row['like_count']),
        "liked_by_me" => (bool)$row['liked_by_me'],
        "profilePicture" => $row['profilePicture'] ? $row['profilePicture'] : null
    ];
}

echo json_encode(["comments" => $comments], JSON_UNESCAPED_UNICODE);
?>