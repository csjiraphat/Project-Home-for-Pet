<?php
include 'connect.php';

cors();

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') fail('Method not allowed', 405);

    $comment_id = param('id', param('comment_id'));
    $username = current_username();
    if (!$comment_id || !is_numeric($comment_id)) fail('Missing or invalid comment id');
    if (!$username) fail('Missing username');

    $comment_id = (int)$comment_id;
    $pdo = db();

    // Ensure comment exists
    $chk = $pdo->prepare("SELECT id FROM comments WHERE id = :id");
    $chk->execute([':id' => $comment_id]);
    if (!$chk->fetch()) fail('Comment not found', 404);

    $pdo->beginTransaction();
    try {
        $exists = $pdo->prepare("SELECT id FROM comment_likes WHERE comment_id = :cid AND username = :u FOR UPDATE");
        $exists->execute([':cid' => $comment_id, ':u' => $username]);
        $row = $exists->fetch();

        if ($row) {
            $del = $pdo->prepare("DELETE FROM comment_likes WHERE id = :id");
            $del->execute([':id' => $row['id']]);
            $liked = false;
        } else {
            $ins = $pdo->prepare("INSERT INTO comment_likes (comment_id, username, created_at) VALUES (:cid, :u, NOW())");
            $ins->execute([':cid' => $comment_id, ':u' => $username]);
            $liked = true;
        }

        $cnt = $pdo->prepare("SELECT COUNT(*) AS c FROM comment_likes WHERE comment_id = :cid");
        $cnt->execute([':cid' => $comment_id]);
        $like_count = (int)$cnt->fetch()['c'];

        $pdo->commit();
        ok(['liked' => $liked, 'like_count' => $like_count]);
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }
} catch (Throwable $e) {
    fail('Server error: '.$e->getMessage(), 500);
}
