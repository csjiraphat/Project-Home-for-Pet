<?php
/**
 * create.php — Comment creation logic with NEW Notification feature
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/connect.php'; // must define $conn (mysqli)

// Force UTF-8
mysqli_set_charset($conn, "utf8mb4");


// ====================================================================
// 💡 HELPER FUNCTIONS 
// ====================================================================

// NEW: ฟังก์ชันสำหรับหา ID ผู้ใช้จาก Username (ใช้ $conn แบบ mysqli)
function get_user_id_by_username($conn, $username) {
    if (!$username) return null;
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
    if (!$stmt) return null;
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row ? intval($row['id']) : null;
}

// NEW: ฟังก์ชันสำหรับบันทึกการแจ้งเตือน (ใช้ $conn แบบ mysqli)
function create_notification($conn, $user_id, $type, $title, $message, $post_type = null, $post_id = null) {
  if (!$user_id) return;
  
  $stmt = $conn->prepare("
    INSERT INTO user_notifications 
    (user_id, type, title, message, related_post_type, related_post_id, created_at) 
    VALUES (?, ?, ?, ?, ?, ?, NOW())
  ");
  
  if (!$stmt) {
    error_log("Notification prepare failed: " . $conn->error);
    return;
  }
  
  $post_type_val = $post_type; 
  $post_id_val = $post_id;     

  $stmt->bind_param('issssi', 
    $user_id, 
    $type, 
    $title, 
    $message, 
    $post_type_val, 
    $post_id_val
  );

  $stmt->execute();
  $stmt->close();
}
// ====================================================================


$post_id   = isset($_POST['post_id'])   ? intval($_POST['post_id']) : 0;
$post_type = isset($_POST['post_type']) ? trim($_POST['post_type']) : '';
$username  = isset($_POST['username'])  ? trim($_POST['username'])  : ''; // ผู้คอมเมนต์
$content   = isset($_POST['content'])   ? trim($_POST['content'])   : '';
$parent_id = isset($_POST['parent_id']) && $_POST['parent_id'] !== '' ? intval($_POST['parent_id']) : null; // สำหรับ Reply

// 1. ตรวจสอบพารามิเตอร์พื้นฐาน
if ($post_id <= 0 || ($post_type !== 'fh' && $post_type !== 'fp') || $username === '' || $content === '') {
  http_response_code(400);
  echo json_encode(['status' => 'error', 'message' => 'missing/invalid params'], JSON_UNESCAPED_UNICODE);
  exit;
}

// 2. ตรวจสอบ Parent ID (สำหรับ Reply)
if (!is_null($parent_id)) {
  $chk = $conn->prepare("SELECT id, post_id, post_type FROM comments WHERE id = ?");
  $chk->bind_param("i", $parent_id);
  $chk->execute();
  $pr = $chk->get_result();
  $parent = $pr->fetch_assoc();
  $chk->close();
  
  if (!$parent) {
    http_response_code(404);
    echo json_encode(['status'=>'error','message'=>'Parent not found'], JSON_UNESCAPED_UNICODE);
    exit;
  }
  if (intval($parent['post_id']) !== $post_id || $parent['post_type'] !== $post_type) {
    http_response_code(409);
    echo json_encode(['status'=>'error','message'=>'Parent post mismatch'], JSON_UNESCAPED_UNICODE);
    exit;
  }
}

// 3. บันทึกคอมเมนต์
$sql = "INSERT INTO comments (post_id, post_type, parent_id, `user`, content, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isiss", $post_id, $post_type, $parent_id, $username, $content); 
$ok = $stmt->execute();
$new_comment_id = $conn->insert_id;
$stmt->close();

if (!$ok) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'insert failed','error'=>$conn->error], JSON_UNESCAPED_UNICODE);
  exit;
}


// ====================================================================
// 4. 💡 LOGIC การแจ้งเตือน (Notification Logic)
// ====================================================================

$tbl_post = $post_type === 'fh' ? 'fhome' : 'fpet';
$stmt_owner = $conn->prepare("SELECT `user` FROM {$tbl_post} WHERE id = ?");
$stmt_owner->bind_param("i", $post_id);
$stmt_owner->execute();
$post_owner_username = $stmt_owner->get_result()->fetch_row()[0] ?? null;
$stmt_owner->close();

$post_owner_id = get_user_id_by_username($conn, $post_owner_username);
$commenter_id = get_user_id_by_username($conn, $username);
$snippet = mb_substr($content, 0, 30) . (mb_strlen($content) > 30 ? '...' : '');


// 4.1 สร้างแจ้งเตือน "คอมเมนต์ใหม่" ไปยังเจ้าของโพสต์ (ถ้าเป็นการคอมเมนต์หลัก และผู้คอมเมนต์ไม่ใช่เจ้าของโพสต์)
if (!$parent_id && $post_owner_id && $commenter_id && $post_owner_id !== $commenter_id) {
    create_notification(
        $conn,
        $post_owner_id, // ผู้รับ: เจ้าของโพสต์
        'new_comment',
        "💬 มีคอมเมนต์ใหม่ในโพสต์ของคุณ",
        "{$username} ได้แสดงความคิดเห็นว่า: \"{$snippet}\"",
        $post_type,
        $post_id
    );
}

// 4.2 ✨ NEW: สร้างแจ้งเตือน "ตอบกลับคอมเมนต์" ไปยังเจ้าของคอมเมนต์หลัก (หากมี parent_id)
if ($parent_id) {
    // 1. หาเจ้าของคอมเมนต์หลัก (parent comment)
    $stmt_parent = $conn->prepare("SELECT `user` FROM comments WHERE id = ?");
    $stmt_parent->bind_param("i", $parent_id);
    $stmt_parent->execute();
    $parent_comment_owner_username = $stmt_parent->get_result()->fetch_row()[0] ?? null;
    $stmt_parent->close();

    $parent_comment_owner_id = get_user_id_by_username($conn, $parent_comment_owner_username);

    // 2. เงื่อนไขการส่งแจ้งเตือนตอบกลับ: 
    //    A) เจ้าของคอมเมนต์หลักต้องมีตัวตน (ID > 0)
    //    B) ผู้ตอบกลับ (commenter_id) ต้องไม่เป็นเจ้าของคอมเมนต์หลัก
    //    C) ผู้ตอบกลับต้องไม่เป็นเจ้าของโพสต์ (เพื่อไม่ให้เกิดแจ้งเตือนซ้ำซ้อน)
    //    D) เจ้าของคอมเมนต์หลักต้องไม่เป็นเจ้าของโพสต์ (เพื่อไม่ให้แจ้งเตือนซ้ำซ้อนกับ 4.1)
    if ($parent_comment_owner_id && $commenter_id && 
        $parent_comment_owner_id !== $commenter_id && 
        $parent_comment_owner_id !== $post_owner_id) 
    {
        create_notification(
            $conn,
            $parent_comment_owner_id, // ผู้รับ: เจ้าของคอมเมนต์หลัก
            'new_reply', // ใช้ type: new_reply
            "📬 มีคนตอบกลับความคิดเห็นของคุณ",
            "{$username} ได้ตอบกลับความคิดเห็นของคุณว่า: \"{$snippet}\"",
            $post_type,
            $post_id
        );
    }
}
// ====================================================================


echo json_encode([
  'status' => 'success',
  'id' => intval($new_comment_id)
], JSON_UNESCAPED_UNICODE);
?>