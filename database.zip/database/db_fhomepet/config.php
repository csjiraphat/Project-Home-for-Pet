<?php
// C:\xampp\htdocs\db_fhomepet\config.php
// หมายเหตุ: ต้องมั่นใจว่าไฟล์นี้ไม่มีช่องว่างหรืออักขระใดๆ ก่อน <?php

return [
  'db' => ['host'=>'127.0.0.1','port'=>3306,'name'=>'fhomepet','user'=>'root','pass'=>'','charset'=>'utf8mb4'],
  'auth' => ['username'=>'admin','password'=>'admin123'],
  'app' => ['base_path'=>'']
];
