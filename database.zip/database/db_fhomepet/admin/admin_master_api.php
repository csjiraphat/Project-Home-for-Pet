<?php
/******************************************************
 * admin_master_api.php
 * CRUD API สำหรับ Admin จัดการ master tables:
 * - pet_species, vaccines, breeds, housing_types,
 *   personalities, rehome_reasons, adoption_terms
 *
 * วิธีเรียก (ตัวอย่าง):
 *   GET    ?entity=vaccines&action=list&page=1&per_page=20&q=หัด
 *   GET    ?entity=breeds&action=get&id=5
 *   POST   ?entity=breeds&action=create
 *          JSON: {"name_th":"ชิสุ","name_en":"Shih Tzu","species_id":1}
 *   PUT    ?entity=vaccines&action=update&id=3
 *          JSON: {"name_th":"โรคพิษสุนัขบ้า","species_id":1,"is_active":1}
 *   DELETE ?entity=adoption_terms&action=delete&id=7
 ******************************************************/

// ------------------------
// CORS + JSON headers
// ------------------------
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ------------------------
// DB CONFIG (แก้ให้ตรงของคุณ)
// ------------------------
$DB_HOST = '127.0.0.1';
$DB_NAME = 'fhomepet';
$DB_USER = 'root';
$DB_PASS = '';
$DB_CHARSET = 'utf8mb4';

// ------------------------
// Helpers
// ------------------------
function json_ok($data = [], $extra = []) {
  echo json_encode(array_merge(['status'=>'success','data'=>$data], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}
function json_err($message, $code = 400, $extra = []) {
  http_response_code($code);
  echo json_encode(array_merge(['status'=>'error','message'=>$message], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}
function get_json_body() {
  $raw = file_get_contents('php://input');
  if (!$raw) return [];
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

// ------------------------
// Connect PDO
// ------------------------
try {
  $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
  $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Exception $e) {
  json_err('เชื่อมต่อฐานข้อมูลไม่ได้: '.$e->getMessage(), 500);
}

// ------------------------
// Entity definitions (whitelist)
// ------------------------
// กำหนด primary key, ฟิลด์ที่อนุญาตให้แก้ไข/เพิ่ม และ search fields
$ENTITIES = [
  'pet_species' => [
    'table' => 'pet_species',
    'pk' => 'species_id',
    'fields' => ['code','name_th','name_en'],      // auto inc PK, ห้าม client ส่งเอง
    'searchable' => ['code','name_th','name_en'],
    'has_is_active' => false,
  ],
  'vaccines' => [
    'table' => 'vaccines',
    'pk' => 'vaccine_id',
    'fields' => ['name_th','name_en','description','species_id','dose_recommend','is_active'],
    'searchable' => ['name_th','name_en','description'],
    'has_is_active' => true,
  ],
  'breeds' => [
    'table' => 'breeds',
    'pk' => 'breed_id',
    'fields' => ['name_th','name_en','species_id','is_active'],
    'searchable' => ['name_th','name_en'],
    'has_is_active' => true,
  ],
  'housing_types' => [
    'table' => 'housing_types',
    'pk' => 'housing_id',
    'fields' => ['name_th','name_en','description','is_active'],
    'searchable' => ['name_th','name_en','description'],
    'has_is_active' => true,
  ],
  'personalities' => [
    'table' => 'personalities',
    'pk' => 'personality_id',
    'fields' => ['name_th','name_en','description','species_id','is_active'],
    'searchable' => ['name_th','name_en','description'],
    'has_is_active' => true,
  ],
  'rehome_reasons' => [
    'table' => 'rehome_reasons',
    'pk' => 'reason_id',
    'fields' => ['name_th','name_en','description','is_active'],
    'searchable' => ['name_th','name_en','description'],
    'has_is_active' => true,
  ],
  'adoption_terms' => [
    'table' => 'adoption_terms',
    'pk' => 'term_id',
    'fields' => ['name_th','name_en','description','required','default_checked','order_index','is_active'],
    'searchable' => ['name_th','name_en','description'],
    'has_is_active' => true,
  ],
];

// ------------------------
// Parse request
// ------------------------
$entity = $_GET['entity'] ?? '';
$action = $_GET['action'] ?? '';
$id = isset($_GET['id']) ? intval($_GET['id']) : null;

if (!isset($ENTITIES[$entity])) {
  json_err('ไม่พบ entity ที่ขอ: '.$entity, 404, ['allow'=>array_keys($ENTITIES)]);
}
$E = $ENTITIES[$entity];
$table = $E['table'];
$pk = $E['pk'];

// ------------------------
// Action handlers
// ------------------------
switch (strtolower($action)) {
  case 'list':
    $page = max(1, intval($_GET['page'] ?? 1));
    $per = max(1, min(200, intval($_GET['per_page'] ?? 20)));
    $offset = ($page - 1) * $per;
    $q = trim($_GET['q'] ?? '');

    $where = [];
    $params = [];

    if ($q !== '') {
      $likeParts = [];
      foreach ($E['searchable'] as $col) {
        $likeParts[] = "{$col} LIKE :q";
      }
      if ($likeParts) {
        $where[] = '(' . implode(' OR ', $likeParts) . ')';
        $params[':q'] = '%'.$q.'%';
      }
    }

    // ถ้ามี is_active ให้ default แสดงทั้งหมด; หากอยากแสดงเฉพาะที่ active ให้เปิดบรรทัดล่าง
    // if ($E['has_is_active']) { $where[] = 'is_active = 1'; }

    $whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';
    $sqlCount = "SELECT COUNT(*) AS cnt FROM {$table} {$whereSql}";
    $stmt = $pdo->prepare($sqlCount);
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    $sql = "SELECT * FROM {$table} {$whereSql} ORDER BY {$pk} DESC LIMIT :per OFFSET :offset";
    $stmt = $pdo->prepare($sql);
    foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
    $stmt->bindValue(':per', $per, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();

    json_ok($rows, ['page'=>$page,'per_page'=>$per,'total'=>$total,'total_pages'=>ceil($total/$per)]);
    break;

  case 'get':
    if (!$id) json_err('กรุณาระบุ id', 422);
    $stmt = $pdo->prepare("SELECT * FROM {$table} WHERE {$pk} = :id");
    $stmt->execute([':id'=>$id]);
    $row = $stmt->fetch();
    if (!$row) json_err('ไม่พบข้อมูล', 404);
    json_ok($row);
    break;

  case 'create':
    $body = get_json_body();
    if (!is_array($body)) $body = [];

    // keep only allowed fields
    $data = [];
    foreach ($E['fields'] as $f) {
      if (array_key_exists($f, $body)) $data[$f] = $body[$f];
    }
    if (empty($data)) json_err('ไม่มีฟิลด์สำหรับบันทึก', 422);

    // defaults
    if ($E['has_is_active'] && !isset($data['is_active'])) $data['is_active'] = 1;

    // build SQL
    $cols = array_keys($data);
    $ph = array_map(fn($c)=>":$c", $cols);
    $sql = "INSERT INTO {$table} (".implode(',',$cols).") VALUES (".implode(',',$ph).")";
    try {
      $stmt = $pdo->prepare($sql);
      foreach ($data as $k=>$v) {
        // แปลงค่าว่างเป็น NULL สำหรับคอลัมน์ *_id หรือ description
        if ($v === '' && (str_ends_with($k,'_id') || $k==='description' || $k==='name_en')) $v = null;
        $stmt->bindValue(":$k", $v);
      }
      $stmt->execute();
      $newId = (int)$pdo->lastInsertId();
      json_ok(['id'=>$newId]);
    } catch (PDOException $e) {
      json_err('บันทึกไม่สำเร็จ: '.$e->getMessage(), 400);
    }
    break;

  case 'update':
    if (!$id) json_err('กรุณาระบุ id', 422);
    $body = get_json_body();
    if (!is_array($body)) $body = [];
    $data = [];
    foreach ($E['fields'] as $f) {
      if (array_key_exists($f, $body)) $data[$f] = $body[$f];
    }
    if (empty($data)) json_err('ไม่มีฟิลด์สำหรับอัปเดต', 422);

    $sets = [];
    foreach ($data as $k=>$v) $sets[] = "{$k} = :$k";
    $sql = "UPDATE {$table} SET ".implode(',', $sets)." WHERE {$pk} = :id";
    try {
      $stmt = $pdo->prepare($sql);
      foreach ($data as $k=>$v) {
        if ($v === '' && (str_ends_with($k,'_id') || $k==='description' || $k==='name_en')) $v = null;
        $stmt->bindValue(":$k", $v);
      }
      $stmt->bindValue(':id', $id, PDO::PARAM_INT);
      $stmt->execute();
      json_ok(['updated'=>true,'id'=>$id]);
    } catch (PDOException $e) {
      json_err('อัปเดตไม่สำเร็จ: '.$e->getMessage(), 400);
    }
    break;

  case 'delete':
    if (!$id) json_err('กรุณาระบุ id', 422);

    // ถ้ามี is_active => soft delete, มิฉะนั้น hard delete
    if ($E['has_is_active']) {
      $sql = "UPDATE {$table} SET is_active = 0 WHERE {$pk} = :id";
    } else {
      $sql = "DELETE FROM {$table} WHERE {$pk} = :id";
    }
    try {
      $stmt = $pdo->prepare($sql);
      $stmt->execute([':id'=>$id]);
      json_ok(['deleted'=>true,'id'=>$id,'soft'=>$E['has_is_active'] ? true : false]);
    } catch (PDOException $e) {
      json_err('ลบไม่สำเร็จ: '.$e->getMessage(), 400);
    }
    break;

  default:
    json_err('action ไม่ถูกต้อง (list|get|create|update|delete)', 400);
}

// ------------------------
// PHP < 8 polyfill (ถ้าเครื่องคุณต่ำกว่า PHP 8 ลบส่วนนี้ทิ้งได้)
// ------------------------
if (!function_exists('str_ends_with')) {
  function str_ends_with($haystack, $needle) {
    $len = strlen($needle);
    if ($len === 0) return true;
    return (substr($haystack, -$len) === $needle);
  }
}
