<?php
// post/match_posts.php
// คำนวณแมตช์ (Top N) + เซฟลง post_matches และคืนเปอร์เซ็นต์หลายคีย์ให้ FE ใช้ได้แน่นอน

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

// ถ้ามีไฟล์เชื่อมต่อฐานข้อมูลของคุณอยู่แล้ว ให้ require แทนบล็อค fallback นี้
// require_once __DIR__ . '/../_lib/pdo.php';
include './_lib/matching.php';

// ---- DB (PDO fallback) ----
if (!isset($pdo) || !($pdo instanceof PDO)) {
  $DB_HOST = getenv('DB_HOST') ?: 'localhost';
  $DB_NAME = getenv('DB_NAME') ?: 'fhomepet';
  $DB_USER = getenv('DB_USER') ?: 'root';
  $DB_PASS = getenv('DB_PASSWORD') ?: '';
  try {
    $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
      PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
    ]);
  } catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['status'=>'error','message'=>'DB connect failed: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
  }
}

// ---- Helpers ----
function db_fetch_one(PDO $pdo, string $table, int $id): ?array {
  $st = $pdo->prepare("SELECT * FROM {$table} WHERE id = :id LIMIT 1");
  $st->execute([':id'=>$id]);
  $row = $st->fetch();
  return $row ?: null;
}

// ✅ แก้ไขฟังก์ชัน `db_fetch_many` ให้รับเงื่อนไข WHERE เพิ่มได้
function db_fetch_many(PDO $pdo, string $table, int $limit = 400, ?string $where_clause = null, array $params = []): array {
  $limit = max(1, min(1000, (int)$limit));
  $sql = "SELECT * FROM {$table}";
  if ($where_clause) {
    $sql .= " WHERE {$where_clause}";
  }
  $sql .= " ORDER BY id DESC LIMIT {$limit}";
  $st = $pdo->prepare($sql);
  $st->execute($params);
  return $st->fetchAll();
}


// ---- Input ----
$mode  = $_GET['mode']  ?? '';           // from_fh | from_fp
$id    = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 3;
$save  = isset($_GET['save']) ? (int)$_GET['save'] : 1; // 1=บันทึกประวัติ, 0=ไม่บันทึก
$overwrite = isset($_GET['overwrite']) ? (int)$_GET['overwrite'] : 0; // 1 = ลบของเก่าก่อน

if (!in_array($mode, ['from_fh','from_fp'], true) || $id <= 0) {
  echo json_encode(['status'=>'error','message'=>'mode หรือ id ไม่ถูกต้อง'], JSON_UNESCAPED_UNICODE);
  exit;
}

try {
  if ($mode === 'from_fh') {
    $src = db_fetch_one($pdo, 'fhome', $id);
    if (!$src) { echo json_encode(['status'=>'error','message'=>'ไม่พบโพสต์ FH id ที่ระบุ'], JSON_UNESCAPED_UNICODE); exit; }

    // ✅ เพิ่มเงื่อนไขการค้นหา `cands` ให้มี type เดียวกันกับ `$src`
    $cands = db_fetch_many($pdo, 'fpet', 400, 'type = :type', [':type' => $src['type']]);

    $items = [];
    foreach ($cands as $row) {
      $reasons = [];
      $score = function_exists('calc_score_fh_to_fp')
        ? calc_score_fh_to_fp($src, $row, $reasons)
        : scoreFHvsFP($src, $row, $reasons);
      $p = (int)max(0, min(100, round($score)));
      $items[] = [
        'id' => (int)$row['id'],
        'title' => $row['title'] ?? '',
        'type' => $row['type'] ?? '',
        'breed' => $row['breed'] ?? '',
        'sex' => $row['sex'] ?? '',
        'color' => $row['color'] ?? '',
        'match_percent' => $p, 'percent' => $p, 'percentage' => $p, 'score' => $p, 'percent_text' => $p.'%',
        'reasons' => $reasons,
      ];
    }
    $left_type = 'fh'; $right_type = 'fp';
  } else { // from_fp
    $src = db_fetch_one($pdo, 'fpet', $id);
    if (!$src) { echo json_encode(['status'=>'error','message'=>'ไม่พบโพสต์ FP id ที่ระบุ'], JSON_UNESCAPED_UNICODE); exit; }

    // ✅ เพิ่มเงื่อนไขการค้นหา `cands` ให้มี type เดียวกันกับ `$src`
    $cands = db_fetch_many($pdo, 'fhome', 400, 'type = :type', [':type' => $src['type']]);

    $items = [];
    foreach ($cands as $row) {
      $reasons = [];
      $score = function_exists('calc_score_fp_to_fh')
        ? calc_score_fp_to_fh($src, $row, $reasons)
        : scoreFPvsFH($src, $row, $reasons);
      $p = (int)max(0, min(100, round($score)));
      $items[] = [
        'id' => (int)$row['id'],
        'title' => $row['title'] ?? '',
        'type' => $row['type'] ?? '',
        'breed' => $row['breed'] ?? '',
        'sex' => $row['sex'] ?? '',
        'color' => $row['color'] ?? '',
        'match_percent' => $p, 'percent' => $p, 'percentage' => $p, 'score' => $p, 'percent_text' => $p.'%',
        'reasons' => $reasons,
      ];
    }
    $left_type = 'fp'; $right_type = 'fh';
  }

  // sort & slice
  usort($items, fn($a,$b) => $b['match_percent'] <=> $a['match_percent']);
  $top = array_slice($items, 0, max(1,$limit));

  // save to history
  $saved = 0;
  if ($save) {
    $pdo->beginTransaction();
    try {
      if ((int)$overwrite === 1) {
        $del = $pdo->prepare("DELETE FROM post_matches WHERE left_type = :lt AND left_id = :lid");
        $del->execute([':lt' => $left_type, ':lid' => $id]);
      }
      
      // ======================= จุดที่แก้ไข =======================
      // เพิ่ม IGNORE เพื่อป้องกัน Error จาก Race Condition ตอนสร้างโพสต์ใหม่
      $ins = $pdo->prepare("INSERT IGNORE INTO post_matches (left_type,left_id,right_type,right_id,score) VALUES (:lt,:lid,:rt,:rid,:score)");
      // ==========================================================

      foreach ($top as $t) {
        $ins->execute([
          ':lt' => $left_type,
          ':lid'=> $id,
          ':rt' => $right_type,
          ':rid'=> (int)$t['id'],
          ':score'=> (float)$t['match_percent'],
        ]);
        $saved++;
      }

      $pdo->commit();
    } catch (Throwable $e) {
      $pdo->rollBack();
      throw $e;
    }
  }

  echo json_encode(['status'=>'success','source'=>['mode'=>$mode,'id'=>$id],'saved'=>$saved,'data'=>$top], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}