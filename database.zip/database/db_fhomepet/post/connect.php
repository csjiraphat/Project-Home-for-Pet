<?php
$host = "localhost";   // ปรับตาม config ของคุณ
$user = "root";
$pass = "";
$db   = "fhomepet";  // <-- เปลี่ยนเป็นชื่อฐานข้อมูลจริง

// --- MySQLi (ของเดิม) ---
$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connection failed (mysqli): " . mysqli_connect_error());
}

// --- PDO (เพิ่มใหม่สำหรับไฟล์ที่ต้องการใช้ $pdo) ---
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed (PDO): " . $e->getMessage());
}
