<?php
// upload.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); // ถ้าทดสอบบนมือถือให้เปิดไว้

$uploadDir = 'uploads/';
$allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'video/mp4'];
$maxSize = 10 * 1024 * 1024; // 10MB
$response = [];

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Method ไม่รองรับ']);
    exit;
}

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if (isset($_FILES['media']['name']) && is_array($_FILES['media']['name']) && !empty($_FILES['media']['name'][0])) {
    foreach ($_FILES['media']['name'] as $index => $filename) {
        $tmpName = $_FILES['media']['tmp_name'][$index];
        $type = $_FILES['media']['type'][$index];
        $size = $_FILES['media']['size'][$index];

        if (!in_array($type, $allowedTypes)) {
            continue;
        }
        if ($size > $maxSize) {
            continue;
        }

        $ext = pathinfo($filename, PATHINFO_EXTENSION);
        $newName = uniqid('media_') . '.' . $ext;

        if (move_uploaded_file($tmpName, $uploadDir . $newName)) {
            $response[] = $uploadDir . $newName;
        }
    }

    echo json_encode(['status' => 'success', 'files' => $response], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'ไม่พบไฟล์ที่ส่งมา']);
exit;
?>
