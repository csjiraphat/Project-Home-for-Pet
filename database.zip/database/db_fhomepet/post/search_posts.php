<?php
// search_posts.php
header('Content-Type: application/json; charset=utf-8');
mb_internal_encoding('UTF-8');

/**
 * CONFIG: ตั้งค่าการเชื่อมต่อ DB ของคุณเอง
 */
$DB_HOST = '127.0.0.1';
$DB_NAME = 'fhomepet';
$DB_USER = 'root';
$DB_PASS = '';
$DB_CHARSET = 'utf8mb4';

$qRaw = isset($_REQUEST['q']) ? trim($_REQUEST['q']) : '';
$postTypeFilter = isset($_REQUEST['postType']) ? strtolower(trim($_REQUEST['postType'])) : 'all';
$limit = isset($_REQUEST['limit']) ? max(1, intval($_REQUEST['limit'])) : 200;

try {
  $pdo = new PDO(
    "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=$DB_CHARSET",
    $DB_USER,
    $DB_PASS,
    [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
      PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]
  );
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['error' => 'DB connection failed', 'details' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
  exit;
}

// ---------- helpers ----------
function th_lower($s) { return mb_strtolower($s ?? '', 'UTF-8'); }
function str_contains_ci($haystack, $needle) {
  if ($needle === '' || $haystack === '') return false;
  return mb_stripos($haystack, $needle, 0, 'UTF-8') !== false;
}
function parse_age_months($s) {
  $s = th_lower(trim((string)$s));
  $years = null; $months = null;
  if (preg_match('/(\d+)\s*ปี/u', $s, $m)) { $years = intval($m[1]); }
  if (preg_match('/(\d+)\s*เดือน/u', $s, $m)) { $months = intval($m[1]); }
  if ($years === null && $months === null) return null;
  return ($years ?: 0) * 12 + ($months ?: 0);
}

$COLOR_WORDS = ['ดำ','ขาว','เทา','น้ำตาล','ส้ม','ครีม','ทอง','ลายเสือ','ขาวดำ','ดำขาว'];

function extract_colors($query, $COLOR_WORDS) {
  $s = th_lower($query);
  $hits = [];
  foreach ($COLOR_WORDS as $c) { if (mb_strpos($s, th_lower($c)) !== false) $hits[] = $c; }
  return array_values(array_unique($hits));
}
function extract_query_terms($s) {
  $s = th_lower($s);
  $s = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $s);
  $parts = preg_split('/\s+/u', $s, -1, PREG_SPLIT_NO_EMPTY);
  return $parts ?: [];
}

// ---------- fetch breeds จาก DB ----------
$breedsDict = [];
try {
  $stmt = $pdo->query("SELECT breed_id, name_th, name_en, species_id FROM breeds WHERE is_active=1");
  while ($row = $stmt->fetch()) {
    $breedsDict[th_lower($row['name_th'])] = $row;
    if (!empty($row['name_en'])) $breedsDict[th_lower($row['name_en'])] = $row;
  }
} catch (Throwable $e) {}

function extract_breeds_from_query($q, $dict) {
  $s = th_lower($q);
  $hits = [];
  foreach ($dict as $k => $row) {
    if ($k !== '' && mb_strpos($s, $k) !== false) {
      $hits[$k] = $row;
    }
  }
  return array_values($hits);
}

// ---------- parse query ----------
$q = th_lower($qRaw);
$speciesQ = null;
if (preg_match('/(หมา|สุนัข|dog)/u', $q)) $speciesQ = 'dog';
if (preg_match('/(แมว|cat)/u', $q)) $speciesQ = ($speciesQ ?: 'cat');

$sexQ = null;
if (preg_match('/(ผู้|ตัวผู้|male)/u', $q)) $sexQ = 'male';
if (preg_match('/(เมีย|ตัวเมีย|female)/u', $q)) $sexQ = ($sexQ ?: 'female');

$sterilizQ = null;
if (preg_match('/(ทำหมันแล้ว|ทำหมัน|yes)/u', $q)) $sterilizQ = 'yes';
if (preg_match('/(ยังไม่ได้ทำหมัน|no)/u', $q)) $sterilizQ = ($sterilizQ ?: 'no');

$ageQ = parse_age_months($q);
$colorsQ = extract_colors($q, $COLOR_WORDS);
$breedHits = extract_breeds_from_query($q, $breedsDict);
$terms = extract_query_terms($q);

// ---------- query posts ----------
$sqlFH = "SELECT id, title, type, breed, sex, age, color, steriliz, image, user, 'fh' AS postType, post_date FROM fhome ORDER BY post_date DESC LIMIT :lim";
$sqlFP = "SELECT id, title, type, breed, sex, min_age, max_age, color, steriliz, '' AS image, user, 'fp' AS postType, post_date FROM fpet ORDER BY post_date DESC LIMIT :lim";

$candidates = [];
$stmt = $pdo->prepare($sqlFH);
$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
$stmt->execute();
$candidates = array_merge($candidates, $stmt->fetchAll());

$stmt = $pdo->prepare($sqlFP);
$stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
$stmt->execute();
$candidates = array_merge($candidates, $stmt->fetchAll());

// ---------- simple scoring ----------
function score_row($row, $qRaw, $speciesQ, $sexQ, $sterilizQ, $colorsQ, $breedHits, $terms) {
  $score = 0;
  $title = th_lower($row['title'] ?? '');
  $breed = th_lower($row['breed'] ?? '');
  $type  = th_lower($row['type'] ?? '');
  $sex   = th_lower($row['sex'] ?? '');
  $ster  = th_lower($row['steriliz'] ?? '');
  $color = th_lower($row['color'] ?? '');

  foreach ($terms as $t) { if ($t !== '' && mb_strpos($title, $t) !== false) $score += 6; }
  if ($speciesQ && $type === $speciesQ) $score += 4;
  if (!empty($breedHits)) {
    foreach ($breedHits as $b) {
      if (str_contains_ci($breed, $b['name_th']) || str_contains_ci($title, $b['name_th'])) { $score += 3; break; }
    }
  }
  if ($sexQ && $sexQ === $sex) $score += 3;
  if ($sterilizQ && $sterilizQ === $ster) $score += 2;
  if (!empty($colorsQ)) {
    foreach ($colorsQ as $c) {
      if (str_contains_ci($color, $c) || str_contains_ci($breed, $c) || str_contains_ci($title, $c)) { $score += 2; break; }
    }
  }
  return $score;
}

foreach ($candidates as &$row) {
  $row['_score'] = score_row($row, $qRaw, $speciesQ, $sexQ, $sterilizQ, $colorsQ, $breedHits, $terms);
}
unset($row);

usort($candidates, function($a, $b) {
  if ($a['_score'] === $b['_score']) return strcmp($b['post_date'], $a['post_date']);
  return $b['_score'] <=> $a['_score'];
});

$topN = array_slice($candidates, 0, $limit);

echo json_encode([
  'query' => $qRaw,
  'parsed' => [
    'species' => $speciesQ,
    'sex' => $sexQ,
    'steriliz' => $sterilizQ,
    'ageMonths' => $ageQ,
    'colors' => $colorsQ,
    'breeds' => $breedHits,
    'terms' => $terms,
  ],
  'count' => count($topN),
  'results' => $topN
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
