<?php
date_default_timezone_set('Asia/Bangkok');
include 'connect.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *'); // ✅ อนุญาตให้เรียกข้าม domain

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents("php://input"), true);

$id = $_GET['id'] ?? null;
$username = $_GET['username'] ?? null; // <<< [เพิ่ม] รับ username จาก parameter

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $conn->prepare("SELECT * FROM fpet WHERE id = ?");
            $stmt->bind_param("s", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($username) { // <<< [เพิ่ม] เงื่อนไขสำหรับดึงโพสต์ทั้งหมดของผู้ใช้
            $stmt = $conn->prepare("SELECT * FROM fpet WHERE user = ? ORDER BY post_date DESC");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $posts = [];
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
            echo json_encode($posts, JSON_UNESCAPED_UNICODE);
        } else {
            // ✅ **แก้ไขบรรทัดนี้: เพิ่ม WHERE status = 'active'**
            $result = $conn->query("SELECT * FROM fpet WHERE status = 'active' ORDER BY post_date DESC");
            $posts = [];
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
            echo json_encode($posts, JSON_UNESCAPED_UNICODE);
        }
        break;

    // ... ส่วนที่เหลือของไฟล์เหมือนเดิม ...
    case 'POST':
    $contentType = $_SERVER["CONTENT_TYPE"] ?? '';

    // ---- multipart upload branch ----
    if (strpos($contentType, 'multipart/form-data') !== false) {
      $uploadDir = __DIR__ . "/../uploads/";
      if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0775, true); }
      $uploadedFiles = [];

      if (isset($_FILES['media'])) {
        if (is_array($_FILES['media']['tmp_name'])) {
          foreach ($_FILES['media']['tmp_name'] as $index => $tmpName) {
            if (!is_uploaded_file($tmpName)) continue;
            $name = basename($_FILES['media']['name'][$index]);
            $targetFile = $uploadDir . uniqid('', true) . '_' . $name;
            if (move_uploaded_file($tmpName, $targetFile)) {
              $uploadedFiles[] = "uploads/" . basename($targetFile);
            }
          }
        } else {
          $tmpName = $_FILES['media']['tmp_name'];
          if (is_uploaded_file($tmpName)) {
            $name = basename($_FILES['media']['name']);
            $targetFile = $uploadDir . uniqid('', true) . '_' . $name;
            if (move_uploaded_file($tmpName, $targetFile)) {
              $uploadedFiles[] = "uploads/" . basename($targetFile);
            }
          }
        }
      }

      echo json_encode([
        'status'  => 'success',
        'message' => 'อัปโหลดไฟล์สำเร็จ',
        'files'   => $uploadedFiles,
      ], JSON_UNESCAPED_UNICODE);
      exit;
    }

    // ---- JSON post branch ----
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) {
      echo json_encode(['status'=>'error','message'=>'ไม่ได้รับข้อมูล JSON'], JSON_UNESCAPED_UNICODE);
      exit;
    }

    $title     = $data['title'] ?? '';
    $type      = $data['type'] ?? '';
    $breed     = $data['breed'] ?? '';
    $sex       = $data['sex'] ?? '';
    $min_age   = $data['min_age'] ?? '';
    $max_age   = $data['max_age'] ?? '';
    $color     = $data['color'] ?? '';
    $steriliz  = $data['steriliz'] ?? '';
    $vaccine   = $data['vaccine'] ?? '';
    $environment = $data['environment'] ?? '';
    $user      = $data['user'] ?? '';
    $postType  = $data['postType'] ?? '';
    $post_date = date('Y-m-d H:i:s');

    // === numeric id with gap filling (no LOCK TABLES) ===
$conn->begin_transaction();

try {
    // ถ้าไม่มี id=1 ให้เริ่มที่ 1, ถ้ามีแล้วให้หาช่องว่างถัดไป
    // ใช้ FOR UPDATE เพื่อกัน race condition ระหว่างหาช่องว่าง
    $rs = $conn->query("SELECT 1 FROM fpet WHERE id = 1 LIMIT 1 FOR UPDATE");

    if ($rs && $rs->num_rows === 0) {
        $next_id = 1;
    } else {
        $q = "
            SELECT COALESCE(MIN(t1.id) + 1, 1) AS next_id
            FROM fpet t1
            LEFT JOIN fpet t2 ON t2.id = t1.id + 1
            WHERE t2.id IS NULL
            FOR UPDATE
        ";
        $res = $conn->query($q);
        $row = $res ? $res->fetch_assoc() : null;
        $next_id = (int)($row['next_id'] ?? 1);
        if ($next_id <= 0) { $next_id = 1; }
    }

    $stmt = $conn->prepare("
        INSERT INTO fpet (
            id, title, type, breed, sex, min_age, max_age, color, steriliz,
            vaccine, environment, user, postType, post_date
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    // id เป็น INT: ใช้ 'i' ตัวแรก ที่เหลือเป็น 's'
    $stmt->bind_param(
        "isssssssssssss",
        $next_id, $title, $type, $breed, $sex, $min_age, $max_age, $color,
        $steriliz, $vaccine, $environment, $user, $postType, $post_date
    );

    $ok = $stmt->execute();
    $stmt->close();

    $conn->commit();

} catch (Exception $e) {
    $conn->rollback();
    throw $e; // ให้ try/catch ด้านนอกจัดการรูปแบบ JSON ต่อ
}

    echo $ok
      ? json_encode(['status'=>'success','message'=>'เพิ่มโพสต์เรียบร้อย','id'=>$next_id,'insert_id'=>$next_id], JSON_UNESCAPED_UNICODE)
      : json_encode(['status'=>'error','message'=>'เพิ่มโพสต์ล้มเหลว: '.$conn->error], JSON_UNESCAPED_UNICODE);
    break;

    case 'PUT':
        if (strpos($_SERVER["CONTENT_TYPE"] ?? '', 'application/json') !== false) {
            $input = json_decode(file_get_contents("php://input"), true);
        } else {
            parse_str(file_get_contents("php://input"), $input);
        }

        if (!$input || !is_array($input)) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'ไม่สามารถอ่านข้อมูล JSON']);
            break;
        }

        $id = $_GET['id'] ?? null;
        if (!$id) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ id ที่ต้องการแก้ไข']);
            break;
        }

        $title       = $input['title'] ?? '';
        $type        = $input['type'] ?? '';
        $breed       = $input['breed'] ?? '';
        $sex         = $input['sex'] ?? '';
        $min_age     = $input['min_age'] ?? '';
        $max_age     = $input['max_age'] ?? '';
        $color       = $input['color'] ?? '';
        $steriliz    = $input['steriliz'] ?? '';
        $vaccine     = $input['vaccine'] ?? '';
        $environment = $input['environment'] ?? '-';
        $user        = $input['user'] ?? '';
        $postType    = $input['postType'] ?? '';

        $stmt = $conn->prepare("UPDATE fpet SET 
            title=?, type=?, breed=?, sex=?, min_age=?, max_age=?, color=?, steriliz=?, 
            vaccine=?, environment=?, user=?, postType=? WHERE id=?");

        $stmt->bind_param("sssssssssssss", $title, $type, $breed, $sex, $min_age, $max_age, $color,
            $steriliz, $vaccine, $environment, $user, $postType, $id); // ✅ ใส่ครบ 13 ตัว

        if ($stmt->execute()) {
            http_response_code(200);
            echo json_encode(['status' => 'success', 'message' => 'อัปเดตโพสต์เรียบร้อย']);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'อัปเดตโพสต์ล้มเหลว', 'debug' => $stmt->error]);
        }

        $stmt->close();
        break;

    case 'DELETE':
        if (!$id) {
            http_response_code(400);
            echo json_encode(['error' => 'กรุณาระบุ id ที่จะลบ']);
            break;
        }

        $stmt = $conn->prepare("DELETE FROM fpet WHERE id = ?");
        $stmt->bind_param("s", $id);

        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'message' => 'ลบโพสต์เรียบร้อย']);
        } else {
            http_response_code(500);
            echo json_encode(['status' => 'error', 'message' => 'ลบโพสต์ล้มเหลว']);
        }

        $stmt->close();
        break;

    default:
        http_response_code(405);
        echo json_encode(['error' => 'Method ไม่รองรับ']);
        break;
}

$conn->close();

?>