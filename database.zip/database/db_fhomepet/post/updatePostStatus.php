<?php
header('Content-Type: application/json; charset=utf-8');
include 'connect.php';

// Allow from any origin
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight request for CORS
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit;
}

// Read JSON input
$input = json_decode(file_get_contents("php://input"), true);

// Validate parameters
if (!isset($input['id']) || !isset($input['postType']) || !isset($input['status'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Missing required parameters: id, postType, status']);
    exit;
}

$id = $input['id'];
$postType = $input['postType'];
$newStatus = $input['status'];

// Validate status value to prevent potential issues
$allowed_statuses = ['active', 'hidden']; // Define allowed statuses
if (!in_array($newStatus, $allowed_statuses)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid status value']);
    exit;
}

// Determine the table based on postType
$table = '';
if ($postType === 'fh') {
    $table = 'fhome';
} elseif ($postType === 'fp') {
    $table = 'fpet';
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid postType']);
    exit;
}

// Prepare and execute the update query
$query = "UPDATE `$table` SET `status` = ? WHERE `id` = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to prepare statement: ' . $conn->error]);
    exit;
}

$stmt->bind_param("si", $newStatus, $id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        echo json_encode(['status' => 'success', 'message' => 'Post status updated successfully.']);
    } else {
        // This can happen if the post is not found or the status is already set
        echo json_encode(['status' => 'warning', 'message' => 'Post not found or status was already set.']);
    }
} else {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Failed to update post status: ' . $stmt->error]);
}

$stmt->close();
$conn->close();
?>