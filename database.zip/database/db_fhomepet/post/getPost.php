<?php
header('Content-Type: application/json; charset=utf-8');
include 'connect.php';

// ตรวจสอบ parameter
if (!isset($_GET['id']) || !isset($_GET['postType'])) {
    echo json_encode(['status' => 'error', 'message' => 'Missing parameters']);
    exit;
}

$id = $_GET['id'];
$postType = $_GET['postType'];

$table = $postType === 'fh' ? 'find_home_posts' : 'find_pet_posts';

// เตรียม query
$query = "SELECT * FROM $table WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$post = $result->fetch_assoc();

// ตรวจสอบผลลัพธ์
if ($post) {
    echo json_encode(['status' => 'success', 'post' => $post]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Post not found']);
}
?>
