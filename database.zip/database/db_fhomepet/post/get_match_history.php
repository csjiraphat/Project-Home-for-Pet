<?php
// post/get_match_history.php
// คืนประวัติการจับคู่ โดยอนุญาตเฉพาะ "เจ้าของโพสต์ (viewer)" เท่านั้น
// required: type=fh|fp, viewer=<username>
// optional: id=<left_id ของโพสต์เรา> (0 หรือไม่ส่ง = ทุกโพสต์ของผู้ใช้), limit

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

$type   = $_GET['type']   ?? '';
$viewer = trim($_GET['viewer'] ?? '');
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
// $limit ถูกจัดการใน SQL แล้ว ไม่จำเป็นต้องใช้ตัวแปรนี้
// $limit  = isset($_GET['limit']) ? (int)$_GET['limit'] : 200;
// $limit  = max(1, min(300, $limit));

if (!in_array($type, ['fh','fp'], true)) {
  echo json_encode(['status'=>'error','message'=>'type ไม่ถูกต้อง (fh หรือ fp)'], JSON_UNESCAPED_UNICODE); exit;
}
if ($viewer === '') {
  echo json_encode(['status'=>'error','message'=>'ต้องระบุ viewer (username)'], JSON_UNESCAPED_UNICODE); exit;
}

// ---- DB ----
$DB_HOST = getenv('DB_HOST') ?: 'localhost';
$DB_NAME = getenv('DB_NAME') ?: 'fhomepet';
$DB_USER = getenv('DB_USER') ?: 'root';
$DB_PASS = getenv('DB_PASSWORD') ?: '';
try {
  $pdo = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4", $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
  ]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>'DB connect failed: '.$e->getMessage()], JSON_UNESCAPED_UNICODE);
  exit;
}

try {
  // ======================= จุดที่แก้ไข =======================
  // เราจะใช้ Common Table Expression (CTE) และ ROW_NUMBER()
  // เพื่อจัดอันดับผลลัพธ์ในแต่ละกลุ่มของโพสต์หลัก และเลือกมาแค่ 3 อันดับแรก
  $base_sql = "
    WITH RankedMatches AS (
      SELECT
        pm.id,
        pm.left_type, pm.left_id, pm.right_type, pm.right_id, pm.score, pm.created_at,
        -- จัดอันดับผลลัพธ์ โดยแบ่งกลุ่มตามโพสต์หลัก (left_id) และเรียงตามคะแนน (score)
        ROW_NUMBER() OVER(PARTITION BY pm.left_id ORDER BY pm.score DESC) as rn,
        -- ข้อมูลของโพสต์หลัก (ของเรา)
        l.title AS left_title, l.user AS left_user,
        l.type  AS left_type_detail, l.breed AS left_breed, l.sex AS left_sex,
        %s, -- ส่วนนี้จะถูกแทนที่สำหรับ fh หรือ fp
        -- ข้อมูลของโพสต์ที่ถูกจับคู่ (ฝั่งตรงข้าม)
        r.user  AS right_user,
        r.title AS right_title, r.type AS right_pet_type, r.breed AS right_breed,
        r.sex AS right_sex, r.color AS right_color
      FROM post_matches pm
      JOIN %s l ON l.id = pm.left_id AND pm.left_type = :left_type
      JOIN %s r ON r.id = pm.right_id
      WHERE l.user = :viewer %s
    )
    SELECT * FROM RankedMatches
    WHERE rn <= 3 -- เลือกเฉพาะ 3 อันดับแรกของแต่ละโพสต์
    ORDER BY left_id DESC, score DESC
  ";

  $id_clause = ($id > 0) ? " AND pm.left_id = :lid" : "";

  if ($type === 'fh') {
    $left_table_cols = "l.age AS left_age, l.image AS left_image, l.post_date AS left_post_date";
    $sql = sprintf($base_sql, $left_table_cols, 'fhome', 'fpet', $id_clause);
    $params = [':left_type' => 'fh', ':viewer' => $viewer];
  } else { // fp
    $left_table_cols = "CONCAT(l.min_age,' - ',l.max_age) AS left_age, NULL AS left_image, l.post_date AS left_post_date";
    $sql = sprintf($base_sql, $left_table_cols, 'fpet', 'fhome', $id_clause);
    $params = [':left_type' => 'fp', ':viewer' => $viewer];
  }

  if ($id > 0) $params[':lid'] = $id;

  $st = $pdo->prepare($sql);
  $st->execute($params);
  $rows = $st->fetchAll();

  if ($id > 0 && count($rows) === 0) {
    http_response_code(403);
    echo json_encode(['status'=>'error','message'=>'Forbidden: คุณไม่มีสิทธิ์ดูประวัติของโพสต์นี้'], JSON_UNESCAPED_UNICODE);
    exit;
  }

  foreach ($rows as &$r) {
    $p = (int)round((float)$r['score']);
    $r['match_percent'] = $r['percent'] = $r['percentage'] = $p;
    $r['percent_text'] = $p.'%';
  }

  echo json_encode([
    'status' => 'success',
    'type'   => $type,
    'viewer' => $viewer,
    'id'     => $id,
    'data'   => $rows
  ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(['status'=>'error','message'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}