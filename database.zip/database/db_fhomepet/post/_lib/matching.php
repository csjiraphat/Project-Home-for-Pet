<?php
// post/matching.php — helper ให้คะแนน + รองรับชื่อฟังก์ชันเดิม

function norm($v){ return trim(mb_strtolower((string)$v, 'UTF-8')); }
function listify($v){
  if (is_array($v)) return array_values(array_filter(array_map('norm',$v)));
  $parts = preg_split('/[,|]/u', (string)$v);
  return array_values(array_filter(array_map('norm',$parts)));
}
function colorOverlap($a, $b){
  $la = listify($a); $lb = listify($b);
  foreach ($la as $x) { if ($x !== '' && in_array($x, $lb, true)) return true; }
  return false;
}

function scoreFHvsFP(array $fh, array $fp, &$explain = []) : int {
  $score = 0; $explain = [];
  if (norm($fh['type'] ?? '') === norm($fp['type'] ?? '') && norm($fh['type'] ?? '')!=='') { $score += 30; $explain[]='ชนิดตรงกัน'; }
  if (norm($fh['breed'] ?? '') === norm($fp['breed'] ?? '') && norm($fh['breed'] ?? '')!=='') { $score += 20; $explain[]='สายพันธุ์ตรงกัน'; }
  if (norm($fp['sex'] ?? '') === '' || norm($fp['sex'] ?? '') === norm($fh['sex'] ?? '')) { $score += 10; $explain[]='เพศเข้ากัน'; }
  if (colorOverlap($fh['color'] ?? '', $fp['color'] ?? '')) { $score += 10; $explain[]='สีใกล้เคียง'; }
  $wantSter = norm($fp['steriliz'] ?? ''); $haveSter = norm($fh['steriliz'] ?? '');
  if ($wantSter === '' || $wantSter === 'ไม่ระบุ' || $wantSter === $haveSter) { $score += 10; $explain[]='ทำหมันตามต้องการ'; }
  $wantVac = norm($fp['vaccine'] ?? ''); $haveVac = norm($fh['vaccine'] ?? '');
  if ($wantVac === '' || $wantVac === 'ไม่ระบุ' || $wantVac === $haveVac || ($wantVac==='ฉีดวัคซีนแล้ว' && mb_strpos((string)$haveVac,'ฉีด')!==false)) {
    $score += 10; $explain[]='วัคซีนตามต้องการ';
  }
  if (mb_stripos((string)($fh['adoptionTerms'] ?? ''), (string)($fp['environment'] ?? '')) !== false && ($fp['environment'] ?? '') !== '') { $score += 5; $explain[]='เงื่อนไขสอดคล้อง'; }
  if (($fp['personality'] ?? '') !== '' && mb_stripos((string)($fh['personality'] ?? ''), (string)$fp['personality']) !== false) { $score += 5; $explain[]='นิสัยเข้ากัน'; }
  return max(0, min(100, $score));
}
function scoreFPvsFH(array $fp, array $fh, &$explain = []) : int {
  return scoreFHvsFP($fh, $fp, $explain);
}
// รองรับชื่อเก่า
function calc_score_fh_to_fp(array $fh, array $fp, &$explain = []) : int { return scoreFHvsFP($fh, $fp, $explain); }
function calc_score_fp_to_fh(array $fp, array $fh, &$explain = []) : int { return scoreFPvsFH($fp, $fh, $explain); }

// ไม่มีปีกกาปิดเกินมาแล้ว