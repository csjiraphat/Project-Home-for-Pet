<?php
include 'connect.php';
date_default_timezone_set('Asia/Bangkok'); // ✅ ตั้งเวลาเป็นไทย
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents("php://input"), true);
$id = $_GET['id'] ?? null;
$username = $_GET['username'] ?? null; // <<< [เพิ่ม] รับ username จาก parameter

function sanitizeMedia($media) {
    if (is_array($media)) {
        return json_encode($media, JSON_UNESCAPED_UNICODE);
    } elseif (is_string($media)) {
        return $media;
    } else {
        return json_encode([]);
    }
}

switch ($method) {
    case 'GET':
        if ($id) {
            $stmt = $conn->prepare("SELECT * FROM fhome WHERE id = ?");
            $stmt->bind_param("s", $id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            echo json_encode($result, JSON_UNESCAPED_UNICODE);
        } elseif ($username) { // <<< [เพิ่ม] เงื่อนไขสำหรับดึงโพสต์ทั้งหมดของผู้ใช้
            $stmt = $conn->prepare("SELECT * FROM fhome WHERE user = ? ORDER BY post_date DESC");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            $posts = [];
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
            echo json_encode($posts, JSON_UNESCAPED_UNICODE);
        } else {
            // ✅ **แก้ไขบรรทัดนี้: เพิ่ม WHERE status = 'active'**
            $result = $conn->query("SELECT * FROM fhome WHERE status = 'active' ORDER BY post_date DESC");
            $posts = [];
            while ($row = $result->fetch_assoc()) {
                $posts[] = $row;
            }
            echo json_encode($posts, JSON_UNESCAPED_UNICODE);
        }
        break;

    // ... ส่วนที่เหลือของไฟล์เหมือนเดิม ...
    case 'POST':
    $contentType = $_SERVER["CONTENT_TYPE"] ?? '';

    // ---- multipart upload branch (unchanged behavior) ----
   if (strpos($contentType, 'multipart/form-data') !== false) {
  $uploadDir = __DIR__ . "/../uploads/";
  if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0775, true); }
  $uploadedFiles = [];

  if (isset($_FILES['media'])) {
    if (is_array($_FILES['media']['tmp_name'])) {
      foreach ($_FILES['media']['tmp_name'] as $index => $tmpName) {
        if (!is_uploaded_file($tmpName)) continue;
        $name = basename($_FILES['media']['name'][$index]);
        $targetFile = $uploadDir . uniqid('', true) . '_' . $name;
        if (move_uploaded_file($tmpName, $targetFile)) {
          // เก็บเฉพาะชื่อไฟล์
          $uploadedFiles[] = basename($targetFile);
        }
      }
    } else {
      // single file case
      $tmpName = $_FILES['media']['tmp_name'];
      if (is_uploaded_file($tmpName)) {
        $name = basename($_FILES['media']['name']);
        $targetFile = $uploadDir . uniqid('', true) . '_' . $name;
        if (move_uploaded_file($tmpName, $targetFile)) {
          // เก็บเฉพาะชื่อไฟล์
          $uploadedFiles[] = basename($targetFile);
        }
      }
    }
  }

  echo json_encode([
    'status'  => 'success',
    'message' => 'อัปโหลดไฟล์สำเร็จ',
    'files'   => $uploadedFiles,
  ], JSON_UNESCAPED_UNICODE);
  exit;
}


    // ---- JSON post branch ----
    $data = json_decode(file_get_contents("php://input"), true);
    if (!$data) {
      echo json_encode(['status'=>'error','message'=>'ไม่ได้รับข้อมูล JSON'], JSON_UNESCAPED_UNICODE);
      exit;
    }

    $title         = $data['title'] ?? '';
    $type          = $data['type'] ?? '';
    $breed         = $data['breed'] ?? '';
    $sex           = $data['sex'] ?? '';
    $age           = $data['age'] ?? '';
    $color         = $data['color'] ?? '';
    $steriliz      = $data['steriliz'] ?? '';
    $vaccine       = $data['vaccine'] ?? '';
    $personality   = $data['personality'] ?? '';
    $reason        = $data['reason'] ?? '';
    $adoptionTerms = $data['adoptionTerms'] ?? '';
    $image         = sanitizeMedia($data['image'] ?? []);
    $user          = $data['user'] ?? '';
    $postType      = $data['postType'] ?? '';
    $post_date     = date('Y-m-d H:i:s');

    // === NEW: numeric id with gap filling (no LOCK TABLES) ===
$conn->begin_transaction();

try {
    // ถ้า table ว่าง หรือ id=1 ไม่มี → เริ่มที่ 1
    $rs = $conn->query("SELECT 1 FROM fhome WHERE id = 1 LIMIT 1 FOR UPDATE");
    if ($rs && $rs->num_rows === 0) {
        $next_id = 1;
    } else {
        $q = "SELECT MIN(t1.id) + 1 AS next_id
              FROM fhome t1
              LEFT JOIN fhome t2 ON t2.id = t1.id + 1
              WHERE t2.id IS NULL
              FOR UPDATE";
        $res = $conn->query($q);
        $row = $res ? $res->fetch_assoc() : null;
        $next_id = (int)($row['next_id'] ?? 1);
        if ($next_id <= 0) { $next_id = 1; }
    }

    // insert (keep original fields/order)
    $stmt = $conn->prepare("INSERT INTO fhome (
      id, title, type, breed, sex, age, color, steriliz, vaccine,
      personality, reason, adoptionTerms, image, user, postType, post_date
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // ถ้า id เป็น INT ให้ใช้ 'i' ตรงตัวแรก
    $stmt->bind_param(
        "isssssssssssssss",
        $next_id, $title, $type, $breed, $sex, $age, $color, $steriliz,
        $vaccine, $personality, $reason, $adoptionTerms, $image, $user, $postType, $post_date
    );

    $ok = $stmt->execute();
    $stmt->close();

    $conn->commit();

} catch (Exception $e) {
    $conn->rollback();
    throw $e;
}

    echo $ok
      ? json_encode(['status'=>'success','message'=>'เพิ่มโพสต์เรียบร้อย','id'=>$next_id,'insert_id'=>$next_id], JSON_UNESCAPED_UNICODE)
      : json_encode(['status'=>'error','message'=>'เพิ่มโพสต์ล้มเหลว: '.$conn->error], JSON_UNESCAPED_UNICODE);
    break;

    case 'PUT':
    // รับข้อมูล JSON
    $input = json_decode(file_get_contents("php://input"), true);

    if (!$id) {
        echo json_encode(['status' => 'error', 'message' => 'กรุณาระบุ id']);
        break;
    }

    // ดึงไฟล์เดิมของโพสต์นี้
    $stmtOld = $conn->prepare("SELECT image FROM fhome WHERE id = ?");
    $stmtOld->bind_param("s", $id);
    $stmtOld->execute();
    $resultOld = $stmtOld->get_result()->fetch_assoc();

    $oldImages = [];
    if ($resultOld && $resultOld['image']) {
        $oldImages = json_decode($resultOld['image'], true);
    }

    // รายการไฟล์ใหม่ที่ client ส่งมา
    $newImages = $input['image'] ?? [];

    // ✅ ลบเฉพาะไฟล์ที่ไม่มีใน $newImages
    foreach ($oldImages as $oldFile) {
        if (!in_array($oldFile, $newImages)) {
            $fileName = basename($oldFile);
            if (preg_match('/^[\w\-]+\.(jpg|jpeg|png|mp4)$/i', $fileName)) {
                $filePath = __DIR__ . '/uploads/' . $fileName;
                if (file_exists($filePath)) {
                    unlink($filePath);
                }
            }
        }
    }

    // อัปเดตโพสต์ตามปกติ
    $title         = $input['title'] ?? '';
    $type          = $input['type'] ?? '';
    $breed         = $input['breed'] ?? '';
    $sex           = $input['sex'] ?? '';
    $age           = $input['age'] ?? '';
    $color         = $input['color'] ?? '';
    $steriliz      = $input['steriliz'] ?? '';
    $vaccine       = $input['vaccine'] ?? '';
    $personality   = $input['personality'] ?? '';
    $reason        = $input['reason'] ?? '';
    $adoptionTerms = $input['adoptionTerms'] ?? '';
    $image         = json_encode($newImages, JSON_UNESCAPED_UNICODE);
    $user          = $input['user'] ?? '';
    $postType      = $input['postType'] ?? '';

    $stmt = $conn->prepare("UPDATE fhome SET 
        title=?, type=?, breed=?, sex=?, age=?, color=?, steriliz=?, vaccine=?,
        personality=?, reason=?, adoptionTerms=?, image=?, user=?, postType=?
        WHERE id=?");

    $stmt->bind_param("sssssssssssssss",
        $title, $type, $breed, $sex, $age, $color, $steriliz, $vaccine,
        $personality, $reason, $adoptionTerms, $image, $user, $postType, $id
    );

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'อัปเดตโพสต์เรียบร้อย']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'อัปเดตโพสต์ล้มเหลว: ' . $stmt->error]);
    }

    $stmt->close();
    break;

    case 'DELETE':
        if (!$id) {
            echo json_encode(['error' => 'กรุณาระบุ id ที่จะลบ']);
            break;
        }

        $stmt = $conn->prepare("DELETE FROM fhome WHERE id = ?");
        $stmt->bind_param("s", $id);

        echo $stmt->execute()
            ? json_encode(['status' => 'success', 'message' => 'ลบโพสต์เรียบร้อย'])
            : json_encode(['status' => 'error', 'message' => 'ลบโพสต์ล้มเหลว: ' . $stmt->error]);

        $stmt->close();
        break;

    default:
        echo json_encode(['error' => 'Method ไม่รองรับ']);
        break;
}

$conn->close();
?>