<?php
/******************************************************
 * master_read_api.php
 * Read-only API: fetch master data for posting/editing forms
 * Entities supported:
 *   - pet_species
 *   - vaccines        (?species=dog|cat|1|2, &active=1)
 *   - breeds          (?species=dog|cat|1|2, &active=1)
 *   - housing_types   (?active=1)
 *   - personalities   (?species=dog|cat|1|2, &active=1)
 *   - rehome_reasons  (?active=1)
 *   - adoption_terms  (?active=1, &order=asc|desc)
 *
 * Examples:
 *   GET ?entity=vaccines&species=dog&active=1
 *   GET ?entity=breeds&species=2&page=1&per_page=200
 *   GET ?entity=personalities&species=cat
 *   GET ?entity=housing_types
 ******************************************************/

header('Content-Type: application/json; charset=utf-8');
ini_set('display_errors', 0);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ------------ DB CONFIG (adjust for your environment) ------------
$DB_HOST = '127.0.0.1';
$DB_NAME = 'fhomepet';
$DB_USER = 'root';
$DB_PASS = '';
$DB_CHARSET = 'utf8mb4';

// ------------ Helpers ------------
function out_ok($data, $extra = []) {
  echo json_encode(array_merge(['status'=>'success','data'=>$data], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}
function out_err($msg, $code = 400, $extra = []) {
  http_response_code($code);
  echo json_encode(array_merge(['status'=>'error','message'=>$msg], $extra), JSON_UNESCAPED_UNICODE);
  exit;
}
function species_to_id($s) {
  if ($s === null || $s === '') return null;
  $s = strtolower(trim((string)$s));
  if ($s === 'dog' || $s === 'หมา' || $s === '1') return 1;
  if ($s === 'cat' || $s === 'แมว' || $s === '2') return 2;
  if (ctype_digit($s)) return (int)$s;
  return null;
}

try {
  $dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset={$DB_CHARSET}";
  $pdo = new PDO($dsn, $DB_USER, $DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Exception $e) {
  out_err('DB connect failed: '.$e->getMessage(), 500);
}

// ------------ Entity whitelist ------------
$entities = [
  'pet_species'     => ['table'=>'pet_species',     'pk'=>'species_id',     'fields'=>['species_id','code','name_th','name_en'], 'filter_species'=>false, 'has_is_active'=>false, 'orderBy'=>'species_id'],
  'vaccines'        => ['table'=>'vaccines',        'pk'=>'vaccine_id',     'fields'=>['vaccine_id','name_th','name_en','description','species_id','dose_recommend','is_active'], 'filter_species'=>true,  'has_is_active'=>true,  'orderBy'=>'name_th'],
  'breeds'          => ['table'=>'breeds',          'pk'=>'breed_id',       'fields'=>['breed_id','name_th','name_en','species_id','is_active'], 'filter_species'=>true,  'has_is_active'=>true,  'orderBy'=>'name_th'],
  'housing_types'   => ['table'=>'housing_types',   'pk'=>'housing_id',     'fields'=>['housing_id','name_th','name_en','description','is_active'], 'filter_species'=>false, 'has_is_active'=>true,  'orderBy'=>'name_th'],
  'personalities'   => ['table'=>'personalities',   'pk'=>'personality_id', 'fields'=>['personality_id','name_th','name_en','description','species_id','is_active'], 'filter_species'=>true,  'has_is_active'=>true,  'orderBy'=>'name_th'],
  'rehome_reasons'  => ['table'=>'rehome_reasons',  'pk'=>'reason_id',      'fields'=>['reason_id','name_th','name_en','description','is_active'], 'filter_species'=>false, 'has_is_active'=>true,  'orderBy'=>'name_th'],
  'adoption_terms'  => ['table'=>'adoption_terms',  'pk'=>'term_id',        'fields'=>['term_id','name_th','name_en','description','required','default_checked','order_index','is_active'], 'filter_species'=>false, 'has_is_active'=>true,  'orderBy'=>'order_index'],
];

$entity = $_GET['entity'] ?? '';
if (!isset($entities[$entity])) {
  out_err('Unknown entity: '.$entity, 404, ['allow'=>array_keys($entities)]);
}
$E = $entities[$entity];

// Pagination & filters
$page = max(1, intval($_GET['page'] ?? 1));
$per  = max(1, min(500, intval($_GET['per_page'] ?? 200)));
$offset = ($page - 1) * $per;

$active = isset($_GET['active']) ? intval($_GET['active']) : null;
$species = $E['filter_species'] ? species_to_id($_GET['species'] ?? null) : null;
$q = trim($_GET['q'] ?? '');
$order = strtolower($_GET['order'] ?? '');
$orderBy = $E['orderBy'];
$orderSql = $order === 'desc' ? "$orderBy DESC" : "$orderBy ASC";

$where = [];
$params = [];

if ($E['has_is_active'] && $active !== null) {
  $where[] = "is_active = :active";
  $params[':active'] = $active;
}

if ($E['filter_species'] && $species !== null) {
  // species_id = X OR species_id IS NULL (allow generic rows)
  $where[] = "(species_id = :species OR species_id IS NULL)";
  $params[':species'] = $species;
}

if ($q !== '') {
  // simple multi-column LIKE across text fields
  $likeCols = array_values(array_filter($E['fields'], function($c){
    return !preg_match('/_id$|^is_active$|^required$|^default_checked$|^order_index$/', $c);
  }));
  if ($likeCols) {
    $likes = [];
    foreach ($likeCols as $c) $likes[] = "$c LIKE :q";
    $where[] = '('.implode(' OR ', $likes).')';
    $params[':q'] = '%'.$q.'%';
  }
}

$whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

// count
$sqlCount = "SELECT COUNT(*) FROM {$E['table']} {$whereSql}";
$stmt = $pdo->prepare($sqlCount);
$stmt->execute($params);
$total = (int)$stmt->fetchColumn();

// query
$cols = implode(',', $E['fields']);
$sql = "SELECT {$cols} FROM {$E['table']} {$whereSql} ORDER BY {$orderSql} LIMIT :per OFFSET :off";
$stmt = $pdo->prepare($sql);
foreach ($params as $k=>$v) $stmt->bindValue($k, $v);
$stmt->bindValue(':per', $per, PDO::PARAM_INT);
$stmt->bindValue(':off', $offset, PDO::PARAM_INT);
$stmt->execute();
$rows = $stmt->fetchAll();

out_ok($rows, ['page'=>$page,'per_page'=>$per,'total'=>$total,'total_pages'=>ceil($total/$per)]);
