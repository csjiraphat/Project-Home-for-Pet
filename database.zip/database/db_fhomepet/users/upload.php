<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$uploadDir = 'uploads/profile/';
$uploadBaseUrl = 'http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . '/' . $uploadDir;

$allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
$maxSize = 5 * 1024 * 1024;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method ไม่รองรับ']);
    exit;
}

if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['status' => 'error', 'message' => 'ไม่พบไฟล์']);
    exit;
}

$file = $_FILES['file'];
$type = $file['type'];
$size = $file['size'];
$tmp = $file['tmp_name'];

if (!in_array($type, $allowedTypes)) {
    echo json_encode(['status' => 'error', 'message' => 'ประเภทไฟล์ไม่รองรับ']);
    exit;
}

if ($size > $maxSize) {
    echo json_encode(['status' => 'error', 'message' => 'ไฟล์ใหญ่เกินไป']);
    exit;
}

// สร้างชื่อไฟล์ใหม่
$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$newName = uniqid('profile_', true) . '.' . $ext;
$fullPath = $uploadDir . $newName;

if (move_uploaded_file($tmp, $fullPath)) {
    $relativePath = $uploadDir . $newName;
    $url = $relativePath; // ✅ แก้ไขตรงนี้ เพิ่มตัวแปร $url

    require 'connect.php';

    if (isset($_POST['username'])) {
        $username = trim($_POST['username']);
        $stmt = $conn->prepare("UPDATE users SET profilePicture = ? WHERE username = ?");
            $stmt->bind_param("ss", $newName, $username);
        if ($stmt->execute()) {
            echo json_encode(['status' => 'success', 'url' => $relativePath]); 
            exit;
        } else {
            echo json_encode(['status' => 'error', 'message' => 'DB Update failed']);
            exit;
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'ไม่พบ username']);
        exit;
    }
}


echo json_encode(['status' => 'error', 'message' => 'อัปโหลดล้มเหลว']);
exit;
?>
