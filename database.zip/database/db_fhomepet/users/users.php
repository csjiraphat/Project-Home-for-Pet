<?php
include 'connect.php';
header('Content-Type: application/json');

// ฟังก์ชันสำหรับตรวจสอบอีเมลซ้ำ
function isEmailExists($conn, $email) {
    $sql = "SELECT email FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->num_rows > 0;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // ✅ อัปเดตรูปโปรไฟล์
    if (isset($_POST['username']) && isset($_POST['profilePicture']) && !isset($_POST['action'])) {
        $username = $_POST['username'];
        $profilePicture = $_POST['profilePicture'];

        $sql = "UPDATE users SET profilePicture = ? WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $profilePicture, $username);

        if ($stmt->execute()) {
            echo json_encode([
                "status" => "success",
                "message" => "อัปเดตรูปโปรไฟล์สำเร็จ"
            ]);
        } else {
            echo json_encode([
                "status" => "error",
                "message" => "ไม่สามารถอัปเดตรูปได้: " . $stmt->error
            ]);
        }
        exit;
    }

    // ฟีเจอร์: ลงทะเบียน และ ล็อกอิน
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'register') {
            if (isset($_POST['username']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['userType'])) {
                $username = $_POST['username'];
                $email = $_POST['email'];
                $password = $_POST['password'];
                $userType = $_POST['userType'];

                if (isEmailExists($conn, $email)) {
                    echo json_encode(["error" => "อีเมลนี้ถูกใช้งานแล้ว"]);
                    exit;
                }
                
                $sql = "SELECT MAX(id) AS max_id FROM users";
                $result = $conn->query($sql);
                $row = $result->fetch_assoc();
                $max_id = $row['max_id'];

                $sql = "SELECT id + 1 FROM users WHERE id + 1 NOT IN (SELECT id FROM users) ORDER BY id LIMIT 1";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    $row = $result->fetch_assoc();
                    $id = $row['id + 1'];
                } else {
                    $id = $max_id + 1;
                }

                $id_length = 4;
                $id_padded = str_pad($id, $id_length, '0', STR_PAD_LEFT);
                $initial_status = 'active'; 

                $sql = "INSERT INTO users (id, username, email, password, userType, profilePicture, status) VALUES (?, ?, ?, ?, ?, NULL, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss", $id_padded, $username, $email, $password, $userType, $initial_status);

                if ($stmt->execute()) {
                    echo json_encode(["message" => "New record created successfully"]);
                } else {
                    echo json_encode(["error" => "Error: " . $stmt->error]);
                }

            } else {
                echo json_encode(["error" => "กรุณาส่งข้อมูลให้ครบถ้วน"]);
            }

        } else if ($action === 'login') {
            if (isset($_POST['email']) && isset($_POST['password'])) {
                $email = $_POST['email'];
                $password = $_POST['password'];

                $sql = "SELECT * FROM users WHERE email = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($result->num_rows > 0) {
                    $user = $result->fetch_assoc();

                    if (isset($user['status']) && $user['status'] === 'suspended') {
                        echo json_encode([
                            "error" => "บัญชีของคุณถูกระงับการใช้งาน กรุณาติดต่อผู้ดูแลระบบ",
                            "errorCode" => "ACCOUNT_SUSPENDED"
                        ]);
                        exit;
                    }
                    
                    if ($password === $user['password']) {
                        echo json_encode($user);
                    } else {
                        echo json_encode(["error" => "อีเมลหรือรหัสผ่านไม่ถูกต้อง"]);
                    }

                } else {
                    echo json_encode(["error" => "อีเมลหรือรหัสผ่านไม่ถูกต้อง"]);
                }
            } else {
                echo json_encode(["error" => "กรุณาส่งข้อมูลให้ครบถ้วน"]);
            }

        } else {
            echo json_encode(["error" => "Invalid action"]);
        }

    } else {
        echo json_encode(["error" => "กรุณาระบุ action"]);
    }

} else {
    // GET: แสดง users ทั้งหมด
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        echo json_encode($users, JSON_UNESCAPED_UNICODE);
    } else {
        echo json_encode(["message" => "ไม่มีข้อมูล กรุณาเพิ่มข้อมูล"], JSON_UNESCAPED_UNICODE);
    }
}

$conn->close();
?>